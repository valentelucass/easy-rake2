<?php
/**
 * API para Listar Histórico de Aprovações de Acesso - Easy Rake 2.0
 */
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../../../utils/auth.php';
require_once __DIR__ . '/../../../utils/response.php';
require_once '../../../../api/db_connect.php';

if (!isAuthenticated()) sendUnauthorized();
if (!canManageUsers()) sendForbidden('Apenas gestores podem ver histórico de aprovações de acesso');

try {
    $sql = "
        SELECT aa.*, f.nome as funcionario_solicitante, u.nome as unidade_nome
        FROM aprovacoes_acesso aa
        JOIN funcionarios f ON aa.funcionario_solicitante_id = f.id
        JOIN unidades u ON f.unidade_id = u.id
        WHERE aa.status IN ('Aprovado', 'Rejeitado')
        ORDER BY aa.data_solicitacao DESC
    ";
    
    $result = $conn->query($sql);
    $aprovacoes = [];
    while ($row = $result->fetch_assoc()) {
        $aprovacoes[] = $row;
    }
    
    sendResponse(true, 'Histórico de aprovações de acesso listado com sucesso', 200, $aprovacoes);
    
} catch (Exception $e) {
    sendInternalError('Erro ao listar histórico de aprovações de acesso: ' . $e->getMessage());
}
$conn->close(); 