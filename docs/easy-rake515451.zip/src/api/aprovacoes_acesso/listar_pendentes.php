<?php
/**
 * API para Listar Aprovações de Acesso Pendentes - Easy Rake 2.0
 */
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../../../testes-diagnosticos/utils/auth.php';
require_once __DIR__ . '/../../../testes-diagnosticos/utils/response.php';
require_once '../../../../api/db_connect.php';

if (!isAuthenticated()) sendUnauthorized();
if (!canApprove()) sendForbidden('Apenas gestores podem ver aprovações de acesso pendentes');

try {
    $sql = "
        SELECT aa.*, f.nome as funcionario_solicitante, u.nome as unidade_nome
        FROM aprovacoes_acesso aa
        JOIN funcionarios f ON aa.funcionario_solicitante_id = f.id
        JOIN unidades u ON f.unidade_id = u.id
        WHERE aa.status = 'Pendente'
        ORDER BY aa.data_solicitacao DESC
    ";
    
    $result = $conn->query($sql);
    $aprovacoes = [];
    while ($row = $result->fetch_assoc()) {
        $aprovacoes[] = $row;
    }
    
    sendList($aprovacoes, count($aprovacoes));
    
} catch (Exception $e) {
    sendInternalError('Erro ao listar aprovações de acesso: ' . $e->getMessage());
}
$conn->close();
?> 