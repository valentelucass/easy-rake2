-- ==========================================================================
-- BANCO DE DADOS EASY RAKE 2.0 - MODELO 100% NORMALIZADO
-- ==========================================================================

CREATE DATABASE IF NOT EXISTS easy_rake DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE easy_rake;

-- 1. ENTIDADES PRINCIPAIS
-- ==========================================================================

-- Usuários do sistema (entidade central)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    email VARCHAR(100) UNIQUE,
    senha VARCHAR(255) NOT NULL,
    status ENUM('Ativo','Inativo') DEFAULT 'Ativo',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_ultimo_acesso TIMESTAMP NULL
);

-- Unidades (clubes/estabelecimentos)
CREATE TABLE unidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    codigo_acesso VARCHAR(8) UNIQUE NOT NULL,
    status ENUM('Ativa','Inativa') DEFAULT 'Ativa',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. VÍNCULOS E PERMISSÕES
-- ==========================================================================

-- Vínculo usuário-unidade-cargo (funcionários)
CREATE TABLE funcionarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    unidade_id INT NOT NULL,
    cargo ENUM('Gestor','Caixa','Sanger') NOT NULL,
    status ENUM('Pendente','Ativo','Inativo','Rejeitado') DEFAULT 'Pendente',
    data_vinculo TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_aprovacao TIMESTAMP NULL,
    data_demissao TIMESTAMP NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (unidade_id) REFERENCES unidades(id) ON DELETE CASCADE,
    UNIQUE KEY unique_usuario_unidade_cargo (usuario_id, unidade_id, cargo)
);

-- 3. SISTEMA DE APROVAÇÕES
-- ==========================================================================

-- Aprovações de acesso (funcionários)
CREATE TABLE aprovacoes_acesso (
    id INT AUTO_INCREMENT PRIMARY KEY,
    funcionario_id INT NOT NULL,
    tipo ENUM('Sanger', 'Caixa') NOT NULL,
    status ENUM('Pendente', 'Aprovado', 'Rejeitado') NOT NULL DEFAULT 'Pendente',
    data_solicitacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_decisao TIMESTAMP NULL,
    gestor_id INT NULL,
    observacoes TEXT,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE CASCADE,
    FOREIGN KEY (gestor_id) REFERENCES funcionarios(id) ON DELETE SET NULL
);

-- Aprovações operacionais (gastos, inclusões, etc)
CREATE TABLE aprovacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('Gasto', 'Inclusao_Caixinha', 'Movimentacao_Alta', 'Jogador_Limite_Alto') NOT NULL,
    referencia_id INT NOT NULL,
    funcionario_id INT NOT NULL,
    status ENUM('Pendente', 'Aprovado', 'Rejeitado') NOT NULL DEFAULT 'Pendente',
    data_solicitacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_decisao TIMESTAMP NULL,
    gestor_id INT NULL,
    observacoes TEXT,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE CASCADE,
    FOREIGN KEY (gestor_id) REFERENCES funcionarios(id) ON DELETE SET NULL
);

-- 4. GESTÃO DE JOGADORES
-- ==========================================================================

-- Jogadores (por unidade)
CREATE TABLE jogadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    unidade_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100),
    status ENUM('Ativo','Inativo') DEFAULT 'Ativo',
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    limite_credito DECIMAL(10,2) DEFAULT 0.00,
    saldo_atual DECIMAL(10,2) DEFAULT 0.00,
    funcionario_cadastro_id INT NOT NULL,
    FOREIGN KEY (unidade_id) REFERENCES unidades(id) ON DELETE CASCADE,
    FOREIGN KEY (funcionario_cadastro_id) REFERENCES funcionarios(id) ON DELETE RESTRICT
);

-- 5. GESTÃO DE CAIXAS
-- ==========================================================================

-- Sessões de caixa
CREATE TABLE caixas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    unidade_id INT NOT NULL,
    funcionario_abertura_id INT NOT NULL,
    funcionario_fechamento_id INT NULL,
    status ENUM('Aberto','Fechado','Cancelado') DEFAULT 'Aberto',
    data_abertura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_fechamento TIMESTAMP NULL,
    inventario_inicial DECIMAL(10,2) NOT NULL,
    inventario_final DECIMAL(10,2) NULL,
    observacoes TEXT,
    FOREIGN KEY (unidade_id) REFERENCES unidades(id) ON DELETE CASCADE,
    FOREIGN KEY (funcionario_abertura_id) REFERENCES funcionarios(id) ON DELETE RESTRICT,
    FOREIGN KEY (funcionario_fechamento_id) REFERENCES funcionarios(id) ON DELETE SET NULL
);

-- 6. GESTÃO DE FICHAS
-- ==========================================================================

-- Denominações de fichas (configurável por unidade)
CREATE TABLE fichas_denom (
    id INT AUTO_INCREMENT PRIMARY KEY,
    unidade_id INT NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    descricao VARCHAR(20),
    status ENUM('Ativo','Inativo') DEFAULT 'Ativo',
    FOREIGN KEY (unidade_id) REFERENCES unidades(id) ON DELETE CASCADE
);

-- Inventário de fichas por caixa
CREATE TABLE inventario_fichas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    ficha_denom_id INT NOT NULL,
    quantidade_inicial INT NOT NULL DEFAULT 0,
    quantidade_final INT NULL,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id) ON DELETE CASCADE,
    FOREIGN KEY (ficha_denom_id) REFERENCES fichas_denom(id) ON DELETE RESTRICT
);

-- Movimentações de fichas (compra, devolução, rake, caixinha)
CREATE TABLE movimentacoes_fichas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    jogador_id INT NULL,
    funcionario_id INT NOT NULL,
    tipo ENUM('COMPRA','DEVOLUCAO','RAKE','CAIXINHA','TRANSFERENCIA') NOT NULL,
    ficha_denom_id INT NOT NULL,
    quantidade INT NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    observacoes TEXT,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id) ON DELETE CASCADE,
    FOREIGN KEY (jogador_id) REFERENCES jogadores(id) ON DELETE SET NULL,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE RESTRICT,
    FOREIGN KEY (ficha_denom_id) REFERENCES fichas_denom(id) ON DELETE RESTRICT
);

-- 7. GESTÃO DE CAIXINHAS
-- ==========================================================================

-- Caixinhas (subdivisões do caixa)
CREATE TABLE caixinhas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    funcionario_criacao_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    valor_meta DECIMAL(10,2) DEFAULT 0.00,
    valor_atual DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('Ativo','Inativo','Concluido') DEFAULT 'Ativo',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_conclusao TIMESTAMP NULL,
    observacoes TEXT,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id) ON DELETE CASCADE,
    FOREIGN KEY (funcionario_criacao_id) REFERENCES funcionarios(id) ON DELETE RESTRICT
);

-- Inclusões em caixinhas
CREATE TABLE caixinhas_inclusoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixinha_id INT NOT NULL,
    funcionario_id INT NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    data_inclusao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    observacoes TEXT,
    FOREIGN KEY (caixinha_id) REFERENCES caixinhas(id) ON DELETE CASCADE,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE RESTRICT
);

-- 8. GESTÃO FINANCEIRA
-- ==========================================================================

-- Gastos do caixa
CREATE TABLE gastos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    funcionario_id INT NOT NULL,
    categoria ENUM('Alimentacao','Limpeza','Manutencao','Outros') DEFAULT 'Outros',
    descricao VARCHAR(255) NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    observacoes TEXT,
    data_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Registrado','Aprovado','Rejeitado') DEFAULT 'Registrado',
    FOREIGN KEY (caixa_id) REFERENCES caixas(id) ON DELETE CASCADE,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE RESTRICT
);

-- Rake (taxa da casa)
CREATE TABLE rake (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    funcionario_id INT NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    observacoes TEXT,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id) ON DELETE CASCADE,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE RESTRICT
);

-- 9. GESTÃO DE RELATÓRIOS
-- ==========================================================================

-- Histórico de relatórios
CREATE TABLE relatorios_historico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    funcionario_id INT NOT NULL,
    unidade_id INT NOT NULL,
    tipo ENUM('Caixa','Gastos','Movimentacoes','Jogadores','Rake','Caixinhas') NOT NULL,
    status ENUM('Gerado','Erro','Processando') DEFAULT 'Processando',
    data_geracao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_conclusao TIMESTAMP NULL,
    arquivo VARCHAR(255),
    mensagem_erro TEXT,
    parametros JSON,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE RESTRICT,
    FOREIGN KEY (unidade_id) REFERENCES unidades(id) ON DELETE CASCADE
);

-- 10. GESTÃO DE TRANSAÇÕES
-- ==========================================================================

-- Transações financeiras dos jogadores
CREATE TABLE transacoes_jogadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jogador_id INT NOT NULL,
    caixa_id INT NOT NULL,
    funcionario_id INT NOT NULL,
    tipo ENUM('CREDITO','DEBITO','ACERTO_POSITIVO','ACERTO_NEGATIVO','QUITACAO') NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    observacao TEXT,
    data_transacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    quitado BOOLEAN DEFAULT 0,
    data_quitacao TIMESTAMP NULL,
    FOREIGN KEY (jogador_id) REFERENCES jogadores(id) ON DELETE CASCADE,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id) ON DELETE CASCADE,
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id) ON DELETE RESTRICT
);

-- ==========================================================================
-- FIM DO SCRIPT DE CRIAÇÃO DO BANCO DE DADOS
-- ==========================================================================