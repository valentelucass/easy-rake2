<?php
// Proxy para src/api/caixas/listar_abertos.php
require_once __DIR__ . '/../../../src/api/caixas/listar_abertos.php'; 