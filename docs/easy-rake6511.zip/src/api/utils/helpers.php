<?php
/**
 * Funções auxiliares para o sistema Easy Rake
 */

require_once __DIR__ . '/../db_connect.php';

/**
 * Obtém o ID do funcionário do usuário logado
 * @return int|null ID do funcionário ou null se não encontrado
 */
function getCurrentFuncionarioId() {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    
    $conn = getConnection();
    if (!$conn) {
        return null;
    }
    
    try {
        // Buscar funcionário ativo do usuário logado
        $sql = "SELECT f.id FROM funcionarios f 
                WHERE f.usuario_id = ? AND f.status = 'Ativo' 
                ORDER BY f.data_vinculo DESC LIMIT 1";
        
        $stmt = executePreparedQuery($conn, $sql, "i", [$_SESSION['user_id']]);
        
        if ($stmt === false) {
            return null;
        }
        
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            $stmt->close();
            return null;
        }
        
        $row = $result->fetch_assoc();
        $stmt->close();
        
        return $row['id'];
        
    } catch (Exception $e) {
        error_log("Erro ao obter funcionario_id: " . $e->getMessage());
        return null;
    } finally {
        closeConnection($conn);
    }
}

/**
 * Verifica se o usuário logado tem permissão para gerenciar usuários
 * @return bool True se tem permissão, false caso contrário
 */
function canManageUsers() {
    $funcionario_id = getCurrentFuncionarioId();
    if (!$funcionario_id) {
        return false;
    }
    
    $conn = getConnection();
    if (!$conn) {
        return false;
    }
    
    try {
        $sql = "SELECT cargo FROM funcionarios WHERE id = ? AND status = 'Ativo'";
        $stmt = executePreparedQuery($conn, $sql, "i", [$funcionario_id]);
        
        if ($stmt === false) {
            return false;
        }
        
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            $stmt->close();
            return false;
        }
        
        $row = $result->fetch_assoc();
        $stmt->close();
        
        return $row['cargo'] === 'Gestor';
        
    } catch (Exception $e) {
        error_log("Erro ao verificar permissão: " . $e->getMessage());
        return false;
    } finally {
        closeConnection($conn);
    }
}

/**
 * Obtém informações completas do funcionário logado
 * @return array|null Array com dados do funcionário ou null se não encontrado
 */
function getCurrentFuncionario() {
    $funcionario_id = getCurrentFuncionarioId();
    if (!$funcionario_id) {
        return null;
    }
    
    $conn = getConnection();
    if (!$conn) {
        return null;
    }
    
    try {
        $sql = "SELECT f.*, u.nome as usuario_nome, u.email, un.nome as unidade_nome 
                FROM funcionarios f 
                JOIN usuarios u ON f.usuario_id = u.id 
                JOIN unidades un ON f.unidade_id = un.id 
                WHERE f.id = ? AND f.status = 'Ativo'";
        
        $stmt = executePreparedQuery($conn, $sql, "i", [$funcionario_id]);
        
        if ($stmt === false) {
            return null;
        }
        
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            $stmt->close();
            return null;
        }
        
        $row = $result->fetch_assoc();
        $stmt->close();
        
        return $row;
        
    } catch (Exception $e) {
        error_log("Erro ao obter dados do funcionário: " . $e->getMessage());
        return null;
    } finally {
        closeConnection($conn);
    }
}
?> 