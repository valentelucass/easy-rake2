<?php
/**
 * API para Listar Histórico de Aprovações de Acesso - Easy Rake 2.0
 */
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../utils/auth.php';
require_once __DIR__ . '/../utils/response.php';
require_once __DIR__ . '/../db_connect.php';
$conn = getConnection();

if (!isAuthenticated()) sendUnauthorized();
if (!canManageUsers()) sendForbidden('Apenas gestores podem ver histórico de aprovações de acesso');

try {
    error_log('[DEBUG][listar_historico] INICIO SQL');
    $sql = "SELECT aa.*, f.id as funcionario_id, u.nome as unidade_nome, us.nome as funcionario_nome, us.cpf as funcionario_cpf FROM aprovacoes_acesso aa JOIN funcionarios f ON aa.funcionario_id = f.id JOIN usuarios us ON f.usuario_id = us.id JOIN unidades u ON f.unidade_id = u.id WHERE aa.status IN ('Aprovado', 'Rejeitado') ORDER BY aa.data_solicitacao DESC";
    error_log('[DEBUG][listar_historico] SQL: ' . $sql);
    $result = $conn->query($sql);
    if ($result === false) error_log('[DEBUG][listar_historico] SQL ERROR: ' . $conn->error);
    $aprovacoes = [];
    while ($row = $result && $result->fetch_assoc()) {
        $aprovacoes[] = $row;
    }
    sendResponse(true, 'Histórico de aprovações de acesso listado com sucesso', 200, $aprovacoes);
} catch (Exception $e) {
    error_log('[DEBUG][listar_historico] EXCEPTION: ' . $e->getMessage());
    sendInternalError('Erro ao listar histórico de aprovações de acesso: ' . $e->getMessage());
}
$conn->close(); 