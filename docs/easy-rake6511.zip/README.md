# Easy Rake

## Visão Geral
Sistema de gestão de clubes, caixas, jogadores e operações financeiras.

---

## Configuração do Projeto

- **Banco de dados:**
  - Porta: **3307** (XAMPP padrão)
  - Usuário: **root**
  - Senha: **36140888**
  - Banco: **easy_rake**
- Para criar o banco e as tabelas, execute:
  ```bash
  php tests/setup_database.php
  ```

---

## Conta Padrão de Testes

> **Sempre utilize esta conta para testes automáticos e manuais:**
- **CPF:** `12924554466`
- **Senha:** `123456`
- **Nome:** Lucas Andrade
- **E-mail:** teste@teste.com

A IA deve SEMPRE testar e validar fluxos usando esta conta antes de sugerir qualquer alteração!

---

## Testes Automatizados

- Para rodar todos os testes automáticos:
  ```bash
  php tests/teste_cadastros_login.php
  ```
- Para limpar dados de teste:
  ```bash
  php tests/limpar_dados_teste.php
  ```

---

## Scripts e Utilitários para Desenvolvedores e IA

- **Ler README automaticamente:**
  ```bash
  cat README.md
  ```
- **Atualizar changelog automaticamente (exemplo IA):**
  ```php
  // Exemplo de função PHP para IA
  function atualizarChangelog($mensagem) {
      $readme = file_get_contents('README.md');
      $readme = preg_replace('/(## Changelog \/ Relat[óo]rio de Atualiza[cç][ãa]oes\n)([\s\S]*?)(---)/', "$1- ".date('Y-m-d')." - IA - $mensagem\n$2$3", $readme);
      file_put_contents('README.md', $readme);
  }
  ```
- **Script para forçar leitura do README antes de qualquer alteração:**
  ```bash
  #!/bin/bash
  echo "Leia o README.md antes de continuar!"
  cat README.md | less
  ```
- **Script para validar se README foi atualizado após mudanças:**
  ```bash
  git diff --name-only HEAD~1 | grep README.md && echo "README.md foi alterado." || echo "Atenção: README.md não foi alterado!"
  ```

---

## Checklist da IA (e dos Devs)

- [ ] Ler o README.md antes de sugerir/aplicar qualquer mudança
- [ ] Validar a conta padrão de testes (CPF: 12924554466)
- [ ] Rodar todos os testes automáticos
- [ ] Atualizar o changelog/relatório após qualquer alteração relevante
- [ ] Documentar decisões, aprendizados e padrões no README
- [ ] Sugerir scripts ou hooks para facilitar a automação
- [ ] Validar se README.md foi alterado após mudanças importantes

---

## Hooks e Integração Contínua (CI)

- **Exemplo de hook de pré-commit (Git):**
  ```bash
  # .git/hooks/pre-commit
  if ! grep -q "CPF: 12924554466" README.md; then
    echo "Atenção: README.md deve conter a conta padrão de testes!"; exit 1;
  fi
  echo "Checklist: Lembre-se de atualizar o changelog no README.md!"
  ```
- **Sugestão de CI (GitHub Actions, GitLab CI, etc):**
  - Sempre rode os testes automáticos após cada push/merge
  - Valide se README.md foi alterado em PRs que mudam APIs, banco ou regras de negócio
  - Gere um alerta se o changelog não for atualizado

---

## Como a IA deve agir neste projeto

1. **Leia o README.md antes de qualquer ação.**
2. **Sempre valide a conta padrão de testes após mudanças em login, cadastro ou permissões.**
3. **Rode os testes automáticos e limpe dados de teste se necessário.**
4. **Atualize o changelog/relatório no README.md após qualquer alteração relevante.**
5. **Documente decisões, padrões e aprendizados no README.md.**
6. **Sugira scripts, hooks e automações para facilitar a vida dos devs e da IA.**
7. **Se possível, automatize a leitura e atualização do README.md.**

---

## Changelog / Relatório de Atualizações

> **IMPORTANTE:**
> Sempre que a IA ou um desenvolvedor fizer uma alteração relevante, registre aqui:

- **[DATA]** [AUTOR] - [RESUMO DA MUDANÇA]
- 2024-04-XX - IA - Removido campo endereço da unidade do banco, backend e frontend.
- 2024-04-XX - IA - Corrigido fluxo de cadastro e login para usar conta padrão de testes.
- ...

---

## Dicas para Evolução da IA

- A IA deve SEMPRE ler este README antes de sugerir mudanças.
- A IA deve SEMPRE testar a conta padrão antes de finalizar qualquer alteração.
- A IA deve SEMPRE atualizar o changelog/relatório após qualquer mudança relevante.
- A IA deve SEMPRE sugerir testes automáticos para validar fluxos críticos.
- A IA deve sugerir scripts, hooks e automações para facilitar a evolução do projeto.

---

## Contato e Suporte

Dúvidas? Fale com o responsável pelo projeto ou registre uma issue. 