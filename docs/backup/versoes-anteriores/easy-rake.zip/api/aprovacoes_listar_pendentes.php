<?php
header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['perfil']) || $_SESSION['perfil'] !== 'Gestor') {
    echo json_encode(['success' => false, 'message' => 'Acesso restrito ao gestor.']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Descobrir a unidade do gestor
$stmt = $conn->prepare("SELECT u.id FROM unidades u INNER JOIN associacoes_usuario_unidade aau ON u.id = aau.id_unidade WHERE aau.id_usuario = ? AND aau.perfil = 'Gestor' AND aau.status_aprovacao = 'Aprovado' LIMIT 1");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Gestor não associado a nenhuma unidade.']);
    exit;
}
$unidade = $result->fetch_assoc();
$id_unidade = $unidade['id'];

// Buscar aprovações pendentes
$aprovacoes = [];

// 1. Aprovações de Caixa (tabela aprovacoes)
$sql = "SELECT a.id, a.tipo, a.referencia_id, a.solicitante_id, a.status, a.data_solicitacao, a.observacoes,
               u.nome AS solicitante_nome, u.tipo_usuario,
               c.valor_inicial, c.observacoes as caixa_observacoes
        FROM aprovacoes a 
        INNER JOIN usuarios u ON a.solicitante_id = u.id 
        LEFT JOIN caixas c ON a.referencia_id = c.id
        WHERE a.status = 'Pendente' 
        AND a.tipo IN ('Caixa', 'Jogador', 'Relatorio')
        AND a.referencia_id IN (
            SELECT c.id FROM caixas c 
            WHERE c.operador_id IN (
                SELECT id_usuario FROM associacoes_usuario_unidade 
                WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'
            )
        )
        ORDER BY a.data_solicitacao DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_unidade);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    // Adicionar informações específicas por tipo
    if ($row['tipo'] === 'Caixa') {
        $row['descricao'] = "Abertura de caixa - R$ " . number_format($row['valor_inicial'], 2, ',', '.');
        $row['detalhes'] = $row['caixa_observacoes'] ?: 'Sem observações';
    } elseif ($row['tipo'] === 'Jogador') {
        // Buscar dados do jogador
        $jogador_stmt = $conn->prepare("SELECT nome, cpf, limite_credito FROM jogadores WHERE id = ?");
        $jogador_stmt->bind_param('i', $row['referencia_id']);
        $jogador_stmt->execute();
        $jogador_result = $jogador_stmt->get_result();
        if ($jogador = $jogador_result->fetch_assoc()) {
            $row['descricao'] = "Cadastro de jogador - " . $jogador['nome'];
            $row['detalhes'] = "CPF: " . $jogador['cpf'] . " | Limite: R$ " . number_format($jogador['limite_credito'], 2, ',', '.');
        }
        $jogador_stmt->close();
    } elseif ($row['tipo'] === 'Relatorio') {
        $row['descricao'] = "Geração de relatório";
        $row['detalhes'] = $row['observacoes'] ?: 'Relatório solicitado';
    }
    
    $aprovacoes[] = $row;
}
$stmt->close();

// 2. Aprovações de Funcionários (Sanger/Caixa) - associacoes_usuario_unidade
$sql2 = "SELECT aau.id, 'Funcionario' as tipo, aau.id_usuario as solicitante_id, 
                u.nome as solicitante_nome, u.cpf, u.tipo_usuario,
                aau.data_criacao as data_solicitacao, aau.status_aprovacao as status,
                aau.perfil as perfil_solicitado
         FROM associacoes_usuario_unidade aau 
         INNER JOIN usuarios u ON aau.id_usuario = u.id 
         WHERE aau.status_aprovacao = 'Pendente' 
         AND aau.id_unidade = ? 
         AND aau.perfil != 'Gestor' 
         ORDER BY aau.data_criacao DESC";

$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param('i', $id_unidade);
$stmt2->execute();
$result2 = $stmt2->get_result();
while ($row = $result2->fetch_assoc()) {
    $row['descricao'] = "Cadastro de " . ucfirst($row['tipo_usuario']) . " - " . $row['solicitante_nome'];
    $row['detalhes'] = "CPF: " . $row['cpf'] . " | Perfil solicitado: " . $row['perfil_solicitado'];
    $aprovacoes[] = $row;
}
$stmt2->close();

// Ordenar por data de solicitação (mais recentes primeiro)
usort($aprovacoes, function($a, $b) { 
    return strtotime($b['data_solicitacao']) - strtotime($a['data_solicitacao']); 
});

echo json_encode(['success' => true, 'aprovacoes' => $aprovacoes]);
$conn->close();
?> 