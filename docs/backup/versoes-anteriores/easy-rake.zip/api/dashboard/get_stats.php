<?php
// Inicia a sessão
session_start();

// Define o cabeçalho de resposta para JSON
header('Content-Type: application/json');

// Verifica se o usuário está logado
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit;
}

// Inclui a conexão com o banco de dados
require_once '../db_connect.php';
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]));
}

try {
    // Busca estatísticas do dashboard
    $user_id = $_SESSION['user_id'] ?? null;
    $perfil = $_SESSION['perfil'] ?? null;
    $aprovacoes_pendentes = 0;

    if ($perfil === 'Gestor' && $user_id) {
        // Descobrir a unidade do gestor
        $stmt = $conn->prepare("SELECT u.id FROM unidades u INNER JOIN associacoes_usuario_unidade aau ON u.id = aau.id_unidade WHERE aau.id_usuario = ? AND aau.perfil = 'Gestor' AND aau.status_aprovacao = 'Aprovado' LIMIT 1");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $unidade = $result->fetch_assoc();
            $id_unidade = $unidade['id'];

            // 1. Aprovações de Caixa/Jogador/Relatorio
            $sql = "SELECT COUNT(*) as total FROM aprovacoes a WHERE a.status = 'Pendente' AND a.tipo IN ('Caixa', 'Jogador', 'Relatorio') AND a.referencia_id IN (SELECT c.id FROM caixas c WHERE c.operador_id IN (SELECT id_usuario FROM associacoes_usuario_unidade WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'))";
            $stmt2 = $conn->prepare($sql);
            $stmt2->bind_param('i', $id_unidade);
            $stmt2->execute();
            $res2 = $stmt2->get_result();
            $row2 = $res2->fetch_assoc();
            $aprovacoes_pendentes += (int)($row2['total'] ?? 0);
            $stmt2->close();

            // 2. Aprovações de Funcionários
            $sql2 = "SELECT COUNT(*) as total FROM associacoes_usuario_unidade WHERE status_aprovacao = 'Pendente' AND id_unidade = ? AND perfil != 'Gestor'";
            $stmt3 = $conn->prepare($sql2);
            $stmt3->bind_param('i', $id_unidade);
            $stmt3->execute();
            $res3 = $stmt3->get_result();
            $row3 = $res3->fetch_assoc();
            $aprovacoes_pendentes += (int)($row3['total'] ?? 0);
            $stmt3->close();
        }
        $stmt->close();
    } else {
        // Para não gestores, mostra 0 aprovações pendentes
        $aprovacoes_pendentes = 0;
    }

    $stats_query = "SELECT 
        (SELECT COUNT(*) FROM caixas WHERE status = 'Aberto') as caixas_abertos,
        (SELECT COUNT(*) FROM jogadores WHERE status = 'Ativo') as jogadores_ativos,
        0 as aprovacoes_pendentes, -- será sobrescrito abaixo
        (SELECT COUNT(*) FROM caixas WHERE DATE(data_abertura) = CURDATE()) as caixas_hoje,
        (SELECT COUNT(*) FROM jogadores WHERE DATE(data_cadastro) = CURDATE()) as jogadores_hoje,
        (SELECT SUM(valor_inicial) FROM caixas WHERE status = 'Aberto') as valor_total_caixas";

    $stats_result = $conn->query($stats_query);
    $stats = $stats_result->fetch_assoc();
    $stats['aprovacoes_pendentes'] = $aprovacoes_pendentes;
    
    // Busca últimas atividades
    $atividades_query = "SELECT 'caixa' as tipo, c.id, c.valor_inicial, c.data_abertura as data, u.nome as operador, u.tipo_usuario FROM caixas c LEFT JOIN usuarios u ON c.operador_id = u.id WHERE c.data_abertura >= DATE_SUB(NOW(), INTERVAL 7 DAY) ORDER BY c.data_abertura DESC LIMIT 5";
    
    $atividades_result = $conn->query($atividades_query);
    $atividades = [];
    
    while ($row = $atividades_result->fetch_assoc()) {
        $row['operador'] = $row['operador'] . ' (' . ucfirst($row['tipo_usuario']) . ')';
        $atividades[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'stats' => $stats,
        'atividades' => $atividades,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Erro ao buscar estatísticas.',
        'error' => $e->getMessage()
    ]);
}

$conn->close();
?> 