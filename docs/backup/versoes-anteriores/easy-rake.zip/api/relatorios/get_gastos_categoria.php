<?php
require_once __DIR__ . '/../db_connect.php';
header('Content-Type: application/json');

try {
    $sql = "SELECT descricao, SUM(valor) as total
            FROM gastos
            GROUP BY descricao
            ORDER BY total DESC";
    $result = $conn->query($sql);
    $categorias = [];
    while ($row = $result->fetch_assoc()) {
        $categorias[] = [
            'descricao' => $row['descricao'],
            'total' => (float)$row['total']
        ];
    }
    echo json_encode([
        'success' => true,
        'categorias' => $categorias
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar gastos por categoria: ' . $e->getMessage()
    ]);
}
$conn->close(); 