<?php
/**
 * 🔍 DIAGNÓSTICO SIMPLES - Easy Rake
 * 
 * Versão simplificada do diagnóstico que verifica os pontos críticos
 * do sistema de forma rápida e eficaz.
 */

require_once __DIR__ . '/../api/db_connect.php';

echo "🔍 DIAGNÓSTICO SIMPLES - EASY RAKE\n";
echo "==================================\n\n";

// Verificar conexão
if (!isset($conn) || $conn->connect_error) {
    echo "❌ ERRO: Não foi possível conectar ao banco de dados\n";
    exit;
}

echo "✅ Conexão MySQL OK (Porta 3307)\n\n";

// 1. Verificar tabelas críticas
echo "1. 🗄️ VERIFICANDO TABELAS CRÍTICAS...\n";
$tabelas = ['usuarios', 'unidades', 'associacoes_usuario_unidade', 'aprovacoes', 'caixas'];
$tabelas_ok = 0;

foreach ($tabelas as $tabela) {
    $result = $conn->query("SHOW TABLES LIKE '$tabela'");
    if ($result && $result->num_rows > 0) {
        echo "   ✅ $tabela\n";
        $tabelas_ok++;
    } else {
        echo "   ❌ $tabela (NÃO EXISTE)\n";
    }
}

echo "   📊 $tabelas_ok de " . count($tabelas) . " tabelas encontradas\n\n";

// 2. Verificar usuários e gestores
echo "2. 👥 VERIFICANDO USUÁRIOS E GESTORES...\n";

$result = $conn->query("SELECT COUNT(*) as total FROM usuarios");
$total_usuarios = $result ? $result->fetch_assoc()['total'] : 0;
echo "   👤 Total de usuários: $total_usuarios\n";

$result = $conn->query("SELECT COUNT(*) as total FROM associacoes_usuario_unidade WHERE perfil = 'Gestor' AND status_aprovacao = 'Aprovado'");
$gestores_aprovados = $result ? $result->fetch_assoc()['total'] : 0;
echo "   👑 Gestores aprovados: $gestores_aprovados\n";

$result = $conn->query("SELECT COUNT(*) as total FROM associacoes_usuario_unidade WHERE perfil != 'Gestor' AND status_aprovacao = 'Pendente'");
$operadores_pendentes = $result ? $result->fetch_assoc()['total'] : 0;
echo "   ⏳ Operadores pendentes: $operadores_pendentes\n\n";

// 3. Verificar aprovações
echo "3. ✅ VERIFICANDO APROVAÇÕES...\n";

$result = $conn->query("SELECT COUNT(*) as total FROM aprovacoes WHERE status = 'Pendente'");
$aprovacoes_pendentes = $result ? $result->fetch_assoc()['total'] : 0;
echo "   📋 Aprovações pendentes: $aprovacoes_pendentes\n";

$result = $conn->query("SELECT tipo, COUNT(*) as total FROM aprovacoes WHERE status = 'Pendente' GROUP BY tipo");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo "      • {$row['tipo']}: {$row['total']}\n";
    }
}
echo "\n";

// 4. Verificar caixas
echo "4. 📦 VERIFICANDO CAIXAS...\n";

$result = $conn->query("SELECT COUNT(*) as total FROM caixas WHERE status = 'Aberto'");
$caixas_abertos = $result ? $result->fetch_assoc()['total'] : 0;
echo "   📦 Caixas abertos: $caixas_abertos\n";

$result = $conn->query("SELECT COUNT(*) as total FROM caixas WHERE status = 'Fechado'");
$caixas_fechados = $result ? $result->fetch_assoc()['total'] : 0;
echo "   📦 Caixas fechados: $caixas_fechados\n\n";

// 5. Verificar consistência dashboard
echo "5. 📊 VERIFICANDO CONSISTÊNCIA DO DASHBOARD...\n";

if ($gestores_aprovados > 0) {
    // Buscar primeiro gestor aprovado
    $result = $conn->query("SELECT u.id, u.nome, aau.id_unidade FROM usuarios u 
                           INNER JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario 
                           WHERE aau.perfil = 'Gestor' AND aau.status_aprovacao = 'Aprovado' 
                           LIMIT 1");
    
    if ($result && $result->num_rows > 0) {
        $gestor = $result->fetch_assoc();
        $unidade_id = $gestor['id_unidade'];
        
        // Contar aprovações da unidade (query do dashboard)
        $sql_dash = "SELECT COUNT(*) as total FROM aprovacoes a 
                    WHERE a.status = 'Pendente' 
                    AND a.tipo IN ('Caixa', 'Jogador', 'Relatorio') 
                    AND a.referencia_id IN (
                        SELECT c.id FROM caixas c 
                        WHERE c.operador_id IN (
                            SELECT id_usuario FROM associacoes_usuario_unidade 
                            WHERE id_unidade = $unidade_id AND status_aprovacao = 'Aprovado'
                        )
                    )";
        $result_dash = $conn->query($sql_dash);
        $aprovacoes_dash = $result_dash ? $result_dash->fetch_assoc()['total'] : 0;
        
        // Contar funcionários pendentes da unidade
        $sql_func = "SELECT COUNT(*) as total FROM associacoes_usuario_unidade 
                    WHERE status_aprovacao = 'Pendente' 
                    AND id_unidade = $unidade_id AND perfil != 'Gestor'";
        $result_func = $conn->query($sql_func);
        $funcionarios_pendentes = $result_func ? $result_func->fetch_assoc()['total'] : 0;
        
        $total_esperado = $aprovacoes_dash + $funcionarios_pendentes;
        
        echo "   👤 {$gestor['nome']} (Unidade $unidade_id):\n";
        echo "      📋 Aprovações: $aprovacoes_dash\n";
        echo "      👥 Funcionários pendentes: $funcionarios_pendentes\n";
        echo "      📊 Total esperado no dashboard: $total_esperado\n";
    } else {
        echo "   ⚠️  Nenhum gestor aprovado encontrado\n";
    }
} else {
    echo "   ⚠️  Nenhum gestor aprovado para verificar consistência\n";
}
echo "\n";

// 6. Verificar segurança
echo "6. 🔒 VERIFICANDO SEGURANÇA...\n";

$result = $conn->query("SELECT COUNT(*) as total FROM usuarios WHERE LENGTH(senha) < 60 OR senha NOT LIKE '$2y$%'");
$senhas_inseguras = $result ? $result->fetch_assoc()['total'] : 0;

if ($senhas_inseguras > 0) {
    echo "   ⚠️  $senhas_inseguras senhas não estão hasheadas corretamente\n";
} else {
    echo "   ✅ Todas as senhas estão hasheadas\n";
}

$result = $conn->query("SELECT COUNT(*) as total FROM usuarios WHERE status = 'Inativo'");
$usuarios_inativos = $result ? $result->fetch_assoc()['total'] : 0;
echo "   🚫 Usuários inativos: $usuarios_inativos\n\n";

// 7. Relatório final
echo str_repeat("=", 50) . "\n";
echo "📋 RELATÓRIO FINAL\n";
echo str_repeat("=", 50) . "\n\n";

echo "📊 RESUMO:\n";
echo "   • Tabelas críticas: $tabelas_ok/" . count($tabelas) . "\n";
echo "   • Usuários: $total_usuarios\n";
echo "   • Gestores aprovados: $gestores_aprovados\n";
echo "   • Operadores pendentes: $operadores_pendentes\n";
echo "   • Aprovações pendentes: $aprovacoes_pendentes\n";
echo "   • Caixas abertos: $caixas_abertos\n";
echo "   • Senhas inseguras: $senhas_inseguras\n";
echo "   • Usuários inativos: $usuarios_inativos\n\n";

// Status geral
$problemas = 0;
if ($tabelas_ok < count($tabelas)) $problemas++;
if ($gestores_aprovados == 0) $problemas++;
if ($senhas_inseguras > 0) $problemas++;

if ($problemas == 0) {
    echo "🎯 STATUS: ✅ SISTEMA SAUDÁVEL\n";
} else {
    echo "🎯 STATUS: ⚠️  ATENÇÃO NECESSÁRIA ($problemas problema(s))\n";
}

echo "\n🧠 INSTRUÇÕES PARA IA:\n";
echo "1. Se problemas foram detectados, use o corretor automático\n";
echo "2. Execute testes específicos para validar funcionalidades\n";
echo "3. Consulte o README.md para padrões de correção\n\n";

echo str_repeat("=", 50) . "\n";
echo "✅ DIAGNÓSTICO CONCLUÍDO\n";
echo str_repeat("=", 50) . "\n";

$conn->close();
?> 