<?php
require_once 'api/db_connect.php';

function checkTable($conn, $table) {
    $res = $conn->query("SHOW TABLES LIKE '$table'");
    return $res && $res->num_rows > 0;
}

function checkColumn($conn, $table, $column) {
    $res = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $res && $res->num_rows > 0;
}

function checkFK($conn, $table, $fk) {
    $res = $conn->query("SELECT * FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_NAME = '$table' AND CONSTRAINT_NAME != 'PRIMARY' AND REFERENCED_TABLE_NAME IS NOT NULL AND COLUMN_NAME = '$fk'");
    return $res && $res->num_rows > 0;
}

function checkData($conn, $table) {
    $res = $conn->query("SELECT COUNT(*) as total FROM `$table`");
    $row = $res ? $res->fetch_assoc() : ['total'=>0];
    return intval($row['total']);
}

$ok = true;
$checks = [];

$tables = [
    'usuarios', 'caixas', 'jogadores', 'transacoes_jogadores', 'movimentacoes', 'gastos', 'aprovacoes', 'relatorios_historico'
];

$columns = [
    'usuarios' => ['id','nome','cpf','perfil','status'],
    'caixas' => ['id','operador_id','valor_inicial','status','data_abertura'],
    'jogadores' => ['id','nome','cpf','limite_credito','status'],
    'transacoes_jogadores' => ['id','jogador_id','operador_id','tipo','valor','data_transacao'],
    'movimentacoes' => ['id','caixa_id','tipo','valor','descricao','operador_id','data_movimentacao'],
    'gastos' => ['id','caixa_id','descricao','valor','operador_id','data_registro'],
    'aprovacoes' => ['id','tipo','referencia_id','solicitante_id','status','data_solicitacao'],
    'relatorios_historico' => ['id','id_usuario','tipo','status','data_geracao','arquivo']
];

$fks = [
    ['caixas','operador_id'],
    ['movimentacoes','caixa_id'],
    ['movimentacoes','operador_id'],
    ['gastos','caixa_id'],
    ['gastos','operador_id'],
    ['aprovacoes','solicitante_id'],
    ['relatorios_historico','id_usuario']
];

// 1. Tabelas
foreach ($tables as $t) {
    $exists = checkTable($conn, $t);
    $checks[] = ["Tabela $t", $exists ? 'OK' : 'FALTA'];
    if (!$exists) $ok = false;
}

// 2. Colunas
foreach ($columns as $t => $cols) {
    foreach ($cols as $c) {
        $exists = checkColumn($conn, $t, $c);
        $checks[] = ["Coluna $t.$c", $exists ? 'OK' : 'FALTA'];
        if (!$exists) $ok = false;
    }
}

// 3. FKs
foreach ($fks as $fk) {
    $exists = checkFK($conn, $fk[0], $fk[1]);
    $checks[] = ["FK {$fk[0]}.{$fk[1]}", $exists ? 'OK' : 'FALTA'];
    if (!$exists) $ok = false;
}

// 4. Dados mínimos
foreach ($tables as $t) {
    $total = checkData($conn, $t);
    $checks[] = ["Dados em $t", $total > 0 ? "$total registros" : 'VAZIO'];
}

// 5. Teste de inserção/consulta no histórico de relatórios
$test_ok = false;
try {
    $conn->query("INSERT INTO relatorios_historico (id_usuario, tipo, status) VALUES (1, 'teste_diagnostico', 'Gerado')");
    $id = $conn->insert_id;
    $res = $conn->query("SELECT * FROM relatorios_historico WHERE id = $id");
    $test_ok = $res && $res->num_rows > 0;
    $conn->query("DELETE FROM relatorios_historico WHERE id = $id");
} catch (Exception $e) {}
$checks[] = ["Teste de inserção/consulta em relatorios_historico", $test_ok ? 'OK' : 'ERRO'];
if (!$test_ok) $ok = false;

$conn->close();

?><!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Diagnóstico Banco de Dados - Relatórios</title>
    <style>
        body { font-family: Arial, sans-serif; background: #181b23; color: #fff; padding: 2rem; }
        h1 { color: #e11d48; }
        table { width: 100%; border-collapse: collapse; margin-top: 2rem; }
        th, td { padding: 0.7rem 1rem; border-bottom: 1px solid #333; }
        th { background: #23272f; color: #fff; }
        tr.ok td { color: #10b981; }
        tr.falta td, tr.erro td { color: #ef4444; font-weight: bold; }
        tr.vazio td { color: #f59e0b; }
        .ok { color: #10b981; }
        .falta, .erro { color: #ef4444; font-weight: bold; }
        .vazio { color: #f59e0b; }
        .resumo { margin-top: 2rem; font-size: 1.2rem; }
    </style>
</head>
<body>
    <h1>Diagnóstico do Banco de Dados - Relatórios</h1>
    <table>
        <tr><th>Item</th><th>Status</th></tr>
        <?php foreach ($checks as $c):
            $cls = strpos($c[1],'OK')!==false?'ok':(strpos($c[1],'FALTA')!==false?'falta':(strpos($c[1],'ERRO')!==false?'erro':'vazio')); ?>
            <tr class="<?= $cls ?>"><td><?= htmlspecialchars($c[0]) ?></td><td><?= htmlspecialchars($c[1]) ?></td></tr>
        <?php endforeach; ?>
    </table>
    <div class="resumo">
        <?php if ($ok): ?>
            ✅ <b>Tudo pronto!</b> O banco de dados está OK para relatórios.<br>
        <?php else: ?>
            ⚠️ <b>Problemas encontrados!</b> Corrija os itens em vermelho/laranja antes de prosseguir.<br>
        <?php endif; ?>
    </div>
</body>
</html> 