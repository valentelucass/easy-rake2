// js/features/caixa-dashboard/inventario.js

document.addEventListener('DOMContentLoaded', function () {
  // Mock: valor atual
  const valorAtual = 23456.78;
  document.getElementById('inventario-valor-atual').textContent =
    'R$ ' + valorAtual.toLocaleString('pt-BR', { minimumFractionDigits: 2 });

  // Mock: histórico de conferências
  const historico = [
    { horario: '2024-06-01 18:00', valor: 23000.00, responsavel: 'João' },
    { horario: '2024-06-01 22:00', valor: 23456.78, responsavel: 'Maria' },
  ];
  const tbody = document.getElementById('inventario-historico-tbody');
  tbody.innerHTML = '';
  historico.forEach(item => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${item.horario}</td>
      <td>R$ ${item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
      <td>${item.responsavel}</td>
    `;
    tbody.appendChild(tr);
  });

  // Botão de conferido
  const btn = document.getElementById('btn-conferir-inventario');
  btn.addEventListener('click', function () {
    alert('Conferência registrada! (mock)');
    // Aqui você pode implementar a lógica real de conferência
  });
}); 