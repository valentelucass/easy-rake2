# 📋 Sistema de Aprovações - Easy Rake

## 🎯 Visão Geral

O sistema de aprovações do Easy Rake é um módulo completo que permite aos gestores controlar e aprovar ações importantes no sistema, garantindo segurança e controle operacional.

## 🔄 Fluxo do Sistema

### 1. **Cadastro de Funcionários (Sanger/Caixa)**
```
Usuário se cadastra → Associação criada com status 'Pendente' → Aparece na lista de aprovações → Gestor aprova/rejeita → Funcionário pode fazer login
```

### 2. **Abertura de Caixa**
```
Operador tenta abrir caixa → Se valor > R$ 5.000 → Status 'Pendente' + Cria aprovação → Gestor aprova → Caixa é aberto
```

### 3. **Cadastro de Jogadores**
```
Operador cadastra jogador → Se limite > R$ 1.000 → Status 'Pendente' + Cria aprovação → Gestor aprova → Jogador é ativado
```

## 🗄️ Estrutura do Banco de Dados

### Tabela `aprovacoes`
```sql
CREATE TABLE aprovacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipo ENUM('Jogador', 'Caixa', 'Relatorio') NOT NULL,
  referencia_id INT NOT NULL,
  solicitante_id INT NOT NULL,
  aprovador_id INT NULL,
  status ENUM('Pendente', 'Aprovado', 'Rejeitado') NOT NULL DEFAULT 'Pendente',
  observacoes TEXT,
  data_solicitacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  data_aprovacao TIMESTAMP NULL,
  FOREIGN KEY (solicitante_id) REFERENCES usuarios(id),
  FOREIGN KEY (aprovador_id) REFERENCES usuarios(id)
);
```

### Tabela `associacoes_usuario_unidade`
```sql
CREATE TABLE associacoes_usuario_unidade (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  id_unidade INT NOT NULL,
  senha_hash VARCHAR(255) NOT NULL,
  perfil ENUM('Operador', 'Gerente', 'Gestor') NOT NULL,
  status_aprovacao ENUM('Pendente', 'Aprovado', 'Rejeitado', 'Removido') NOT NULL DEFAULT 'Pendente',
  data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  data_aprovacao TIMESTAMP NULL,
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id),
  FOREIGN KEY (id_unidade) REFERENCES unidades(id)
);
```

## 🔧 APIs Implementadas

### 1. **Listar Aprovações Pendentes**
- **Arquivo:** `api/aprovacoes_listar_pendentes.php`
- **Método:** GET
- **Acesso:** Apenas Gestor
- **Retorna:** Lista de todas as aprovações pendentes da unidade

### 2. **Listar Histórico**
- **Arquivo:** `api/aprovacoes_listar_historico.php`
- **Método:** GET
- **Acesso:** Apenas Gestor
- **Retorna:** Histórico de aprovações processadas

### 3. **Ação de Aprovação**
- **Arquivo:** `api/aprovacoes_acao.php`
- **Método:** POST
- **Acesso:** Apenas Gestor
- **Parâmetros:** `tipo`, `id`, `acao` (aprovar/rejeitar)

## 🎨 Interface do Usuário

### Página de Aprovações (`aprovacoes.php`)
- **Cards de Estatísticas:** Pendentes, Aprovadas hoje, Rejeitadas hoje, Total
- **Tabela de Aprovações:** Lista detalhada com ações
- **Informações da Unidade:** Código de acesso e dados da unidade

### Componentes Visuais
- **Badges de Tipo:** Caixa (azul), Jogador (roxo), Funcionário (laranja), Relatório (verde)
- **Badges de Status:** Pendente (amarelo), Aprovado (verde), Rejeitado (vermelho)
- **Ações:** Botões de Aprovar/Rejeitar com ícones

## ⚙️ Configurações Automáticas

### Limites para Aprovação Automática
- **Caixas:** Valor inicial > R$ 5.000,00
- **Jogadores:** Limite de crédito > R$ 1.000,00
- **Funcionários:** Sempre precisam de aprovação

### Triggers Automáticos
1. **Cadastro de Jogador:** Se limite alto → Status 'Pendente' + Cria aprovação
2. **Abertura de Caixa:** Se valor alto → Status 'Pendente' + Cria aprovação
3. **Cadastro de Funcionário:** Sempre → Status 'Pendente' na associação

## 🔐 Controle de Acesso

### Perfis de Usuário
- **Gestor:** Pode aprovar/rejeitar todas as solicitações
- **Caixa:** Pode operar caixas e cadastrar jogadores (com aprovação se necessário)
- **Sanger:** Funcionário que precisa de aprovação para trabalhar

### Restrições
- Apenas gestores podem acessar a página de aprovações
- Aprovações são filtradas por unidade
- Cada gestor só vê aprovações da sua unidade

## 📊 Funcionalidades

### 1. **Dashboard de Aprovações**
- Contadores em tempo real
- Atualização automática a cada 30 segundos
- Filtros por tipo e status

### 2. **Processamento de Aprovações**
- Aprovação/rejeição com confirmação
- Ativação automática após aprovação
- Histórico completo de ações

### 3. **Notificações**
- Feedback visual para todas as ações
- Mensagens de sucesso/erro
- Confirmações antes de ações importantes

## 🧪 Teste do Sistema

### Script de Teste
- **Arquivo:** `teste_sistema_aprovacoes.php`
- **Função:** Demonstra todas as funcionalidades
- **Dados:** Cria dados de teste e limpa automaticamente

### Como Executar
1. Acesse `http://localhost/easy-rake/teste_sistema_aprovacoes.php`
2. Verifique se todos os testes passaram
3. Confirme que as funcionalidades estão operacionais

## 🚀 Como Usar

### Para Gestores
1. Acesse a página "Aprovações" no menu
2. Visualize as solicitações pendentes
3. Clique em "Aprovar" ou "Rejeitar" conforme necessário
4. Monitore o histórico de aprovações

### Para Operadores
1. Cadastre jogadores normalmente
2. Abra caixas normalmente
3. Se precisar de aprovação, aguarde a resposta do gestor
4. Receba notificação quando aprovado

## 🔧 Manutenção

### Logs
- Todas as ações são registradas no banco
- Histórico completo mantido
- Possibilidade de auditoria

### Backup
- Dados críticos nas tabelas principais
- Relacionamentos preservados
- Integridade referencial mantida

## 📈 Métricas Disponíveis

### Estatísticas em Tempo Real
- Aprovações pendentes
- Aprovadas hoje
- Rejeitadas hoje
- Total histórico

### Relatórios
- Histórico completo por período
- Filtros por tipo e status
- Informações do aprovador

## 🎯 Benefícios

1. **Controle Operacional:** Gestores têm controle total sobre ações importantes
2. **Segurança:** Prevenção de fraudes e erros
3. **Auditoria:** Histórico completo de todas as ações
4. **Flexibilidade:** Configuração de limites por unidade
5. **Usabilidade:** Interface intuitiva e responsiva

---

**Desenvolvido para o Easy Rake - Sistema de Gestão de Caixas**
*Versão 1.0 - Sistema de Aprovações Completo* 