<?php
require_once __DIR__ . '/../db_connect.php';
header('Content-Type: application/json');

try {
    $sql = "SELECT id, tipo, status, data_geracao, arquivo FROM relatorios_historico ORDER BY data_geracao DESC LIMIT 20";
    $result = $conn->query($sql);
    $historico = [];
    while ($row = $result->fetch_assoc()) {
        $historico[] = [
            'id' => (int)$row['id'],
            'tipo' => $row['tipo'],
            'status' => $row['status'],
            'data_geracao' => $row['data_geracao'],
            'arquivo' => $row['arquivo']
        ];
    }
    echo json_encode([
        'success' => true,
        'historico' => $historico
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar histórico de relatórios: ' . $e->getMessage()
    ]);
}
$conn->close(); 