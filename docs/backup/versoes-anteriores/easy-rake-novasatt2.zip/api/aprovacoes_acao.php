<?php
header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['perfil']) || $_SESSION['perfil'] !== 'Gestor') {
    echo json_encode(['success' => false, 'message' => 'Acesso restrito ao gestor.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$tipo = $input['tipo'] ?? '';
$id = $input['id'] ?? '';
$acao = $input['acao'] ?? '';

if (!in_array($tipo, ['Caixa', 'Jogador', 'Relatorio', 'Funcionario']) || !$id || !in_array($acao, ['aprovar', 'rejeitar'])) {
    echo json_encode(['success' => false, 'message' => 'Parâmetros inválidos.']);
    exit;
}

try {
    $conn->begin_transaction();
    
    if ($tipo === 'Funcionario') {
        // Aprovação de funcionário (associacoes_usuario_unidade)
        $novo_status = $acao === 'aprovar' ? 'Aprovado' : 'Rejeitado';
        $stmt = $conn->prepare("UPDATE associacoes_usuario_unidade SET status_aprovacao = ?, data_aprovacao = NOW() WHERE id = ? AND status_aprovacao = 'Pendente'");
        $stmt->bind_param('si', $novo_status, $id);
        $stmt->execute();
        
        if ($stmt->affected_rows === 0) {
            throw new Exception('Associação não encontrada ou já foi processada.');
        }
        
        // Se aprovado, ativar o usuário
        if ($acao === 'aprovar') {
            $stmt_get_user = $conn->prepare("SELECT id_usuario FROM associacoes_usuario_unidade WHERE id = ?");
            $stmt_get_user->bind_param('i', $id);
            $stmt_get_user->execute();
            $user_result = $stmt_get_user->get_result();
            if ($user = $user_result->fetch_assoc()) {
                $stmt_activate = $conn->prepare("UPDATE usuarios SET status = 'Ativo' WHERE id = ?");
                $stmt_activate->bind_param('i', $user['id_usuario']);
                $stmt_activate->execute();
            }
        }
        
        $mensagem = 'Funcionário ' . ($acao === 'aprovar' ? 'aprovado' : 'rejeitado') . ' com sucesso.';
        
    } else {
        // Aprovações de Caixa, Jogador, Relatório (tabela aprovacoes)
        $novo_status = $acao === 'aprovar' ? 'Aprovado' : 'Rejeitado';
        $stmt = $conn->prepare("UPDATE aprovacoes SET status = ?, data_aprovacao = NOW(), aprovador_id = ? WHERE id = ? AND status = 'Pendente'");
        $stmt->bind_param('sii', $novo_status, $_SESSION['user_id'], $id);
        $stmt->execute();
        
        if ($stmt->affected_rows === 0) {
            throw new Exception('Aprovação não encontrada ou já foi processada.');
        }
        
        // Se aprovado, executar ação específica
        if ($acao === 'aprovar') {
            // Buscar dados da aprovação
            $stmt_get = $conn->prepare("SELECT tipo, referencia_id FROM aprovacoes WHERE id = ?");
            $stmt_get->bind_param('i', $id);
            $stmt_get->execute();
            $aprov_result = $stmt_get->get_result();
            $aprovacao = $aprov_result->fetch_assoc();
            
            if ($aprovacao['tipo'] === 'Caixa') {
                // Ativar o caixa
                $stmt_caixa = $conn->prepare("UPDATE caixas SET status = 'Aberto' WHERE id = ? AND status = 'Pendente'");
                $stmt_caixa->bind_param('i', $aprovacao['referencia_id']);
                $stmt_caixa->execute();
                
            } elseif ($aprovacao['tipo'] === 'Jogador') {
                // Ativar o jogador
                $stmt_jogador = $conn->prepare("UPDATE jogadores SET status = 'Ativo' WHERE id = ? AND status = 'Pendente'");
                $stmt_jogador->bind_param('i', $aprovacao['referencia_id']);
                $stmt_jogador->execute();
                
            } elseif ($aprovacao['tipo'] === 'Relatorio') {
                // Processar relatório (implementar conforme necessário)
                // Por enquanto, apenas marca como aprovado
            }
        }
        
        $mensagem = ucfirst($tipo) . ' ' . ($acao === 'aprovar' ? 'aprovado' : 'rejeitado') . ' com sucesso.';
    }
    
    $conn->commit();
    echo json_encode(['success' => true, 'message' => $mensagem]);
    
} catch (Exception $e) {
    $conn->rollback();
    error_log('Erro na ação de aprovação: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
?>