<?php
header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['perfil']) || $_SESSION['perfil'] !== 'Gestor') {
    echo json_encode(['success' => false, 'message' => 'Acesso restrito ao gestor.']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Descobrir a unidade do gestor
$stmt = $conn->prepare("SELECT u.id FROM unidades u INNER JOIN associacoes_usuario_unidade aau ON u.id = aau.id_unidade WHERE aau.id_usuario = ? AND aau.perfil = 'Gestor' AND aau.status_aprovacao = 'Aprovado' LIMIT 1");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Gestor não associado a nenhuma unidade.']);
    exit;
}
$unidade = $result->fetch_assoc();
$id_unidade = $unidade['id'];

$historico = [];

// 1. Histórico de aprovações da tabela aprovacoes
$sql = "SELECT a.id, a.tipo, a.referencia_id, a.solicitante_id, a.status, a.data_solicitacao, a.data_aprovacao, a.observacoes,
               u.nome AS solicitante_nome, u.tipo_usuario,
               aprovador.nome AS aprovador_nome,
               c.valor_inicial, c.observacoes as caixa_observacoes
        FROM aprovacoes a 
        INNER JOIN usuarios u ON a.solicitante_id = u.id 
        LEFT JOIN usuarios aprovador ON a.aprovador_id = aprovador.id
        LEFT JOIN caixas c ON a.referencia_id = c.id
        WHERE a.status IN ('Aprovado','Rejeitado') 
        AND a.tipo IN ('Caixa', 'Jogador', 'Relatorio')
        AND a.referencia_id IN (
            SELECT c.id FROM caixas c 
            WHERE c.operador_id IN (
                SELECT id_usuario FROM associacoes_usuario_unidade 
                WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'
            )
        )
        ORDER BY a.data_aprovacao DESC LIMIT 100";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_unidade);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    // Adicionar informações específicas por tipo
    if ($row['tipo'] === 'Caixa') {
        $row['descricao'] = "Abertura de caixa - R$ " . number_format($row['valor_inicial'], 2, ',', '.');
        $row['detalhes'] = $row['caixa_observacoes'] ?: 'Sem observações';
    } elseif ($row['tipo'] === 'Jogador') {
        // Buscar dados do jogador
        $jogador_stmt = $conn->prepare("SELECT nome, cpf, limite_credito FROM jogadores WHERE id = ?");
        $jogador_stmt->bind_param('i', $row['referencia_id']);
        $jogador_stmt->execute();
        $jogador_result = $jogador_stmt->get_result();
        if ($jogador = $jogador_result->fetch_assoc()) {
            $row['descricao'] = "Cadastro de jogador - " . $jogador['nome'];
            $row['detalhes'] = "CPF: " . $jogador['cpf'] . " | Limite: R$ " . number_format($jogador['limite_credito'], 2, ',', '.');
        }
        $jogador_stmt->close();
    } elseif ($row['tipo'] === 'Relatorio') {
        $row['descricao'] = "Geração de relatório";
        $row['detalhes'] = $row['observacoes'] ?: 'Relatório solicitado';
    }
    
    $historico[] = $row;
}
$stmt->close();

// 2. Histórico de funcionários (associacoes_usuario_unidade)
$sql2 = "SELECT aau.id, 'Funcionario' as tipo, aau.id_usuario as solicitante_id, 
                u.nome as solicitante_nome, u.cpf, u.tipo_usuario,
                aau.data_criacao as data_solicitacao, aau.data_aprovacao, 
                aau.status_aprovacao as status, aau.perfil as perfil_solicitado
         FROM associacoes_usuario_unidade aau 
         INNER JOIN usuarios u ON aau.id_usuario = u.id 
         WHERE aau.status_aprovacao IN ('Aprovado','Rejeitado','Removido') 
         AND aau.id_unidade = ? 
         AND aau.perfil != 'Gestor' 
         ORDER BY aau.data_aprovacao DESC LIMIT 100";

$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param('i', $id_unidade);
$stmt2->execute();
$result2 = $stmt2->get_result();
while ($row = $result2->fetch_assoc()) {
    $row['descricao'] = "Cadastro de " . ucfirst($row['tipo_usuario']) . " - " . $row['solicitante_nome'];
    $row['detalhes'] = "CPF: " . $row['cpf'] . " | Perfil: " . $row['perfil_solicitado'];
    $row['aprovador_nome'] = 'Sistema'; // Funcionários são aprovados automaticamente pelo sistema
    $historico[] = $row;
}
$stmt2->close();

// Ordenar por data de aprovação (mais recentes primeiro)
usort($historico, function($a, $b) { 
    $data_a = $a['data_aprovacao'] ? strtotime($a['data_aprovacao']) : strtotime($a['data_solicitacao']);
    $data_b = $b['data_aprovacao'] ? strtotime($b['data_aprovacao']) : strtotime($b['data_solicitacao']);
    return $data_b - $data_a;
});

echo json_encode(['success' => true, 'historico' => $historico]);
$conn->close();
?> 