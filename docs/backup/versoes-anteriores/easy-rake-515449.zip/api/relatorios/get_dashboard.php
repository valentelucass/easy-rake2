<?php
require_once __DIR__ . '/../db_connect.php';
header('Content-Type: application/json');

try {
    // Saldo atual do caixa (entradas - saídas)
    $sqlSaldo = "SELECT 
        SUM(CASE WHEN tipo = 'Entrada' THEN valor ELSE 0 END) - SUM(CASE WHEN tipo = 'Saida' THEN valor ELSE 0 END) AS saldo
        FROM movimentacoes";
    $saldo = $conn->query($sqlSaldo)->fetch_assoc()['saldo'] ?? 0;

    // Total de entradas
    $sqlEntradas = "SELECT SUM(valor) as total_entradas FROM movimentacoes WHERE tipo = 'Entrada'";
    $total_entradas = $conn->query($sqlEntradas)->fetch_assoc()['total_entradas'] ?? 0;

    // Total de saídas
    $sqlSaidas = "SELECT SUM(valor) as total_saidas FROM movimentacoes WHERE tipo = 'Saida'";
    $total_saidas = $conn->query($sqlSaidas)->fetch_assoc()['total_saidas'] ?? 0;

    // Total de gastos
    $sqlGastos = "SELECT SUM(valor) as total_gastos FROM gastos";
    $total_gastos = $conn->query($sqlGastos)->fetch_assoc()['total_gastos'] ?? 0;

    // Quantidade de transações de jogadores
    $sqlTransacoes = "SELECT COUNT(*) as qtd_transacoes FROM transacoes_jogadores";
    $qtd_transacoes = $conn->query($sqlTransacoes)->fetch_assoc()['qtd_transacoes'] ?? 0;

    echo json_encode([
        'success' => true,
        'saldo_atual' => (float)$saldo,
        'total_entradas' => (float)$total_entradas,
        'total_saidas' => (float)$total_saidas,
        'total_gastos' => (float)$total_gastos,
        'qtd_transacoes_jogadores' => (int)$qtd_transacoes
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar dados do dashboard: ' . $e->getMessage()
    ]);
}
$conn->close(); 