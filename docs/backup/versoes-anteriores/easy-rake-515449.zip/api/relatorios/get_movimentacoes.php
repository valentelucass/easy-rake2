<?php
require_once __DIR__ . '/../db_connect.php';
header('Content-Type: application/json');

try {
    $sql = "SELECT m.id, m.tipo, m.valor, m.descricao, m.data_movimentacao, u.nome as operador
            FROM movimentacoes m
            JOIN usuarios u ON m.operador_id = u.id
            ORDER BY m.data_movimentacao DESC
            LIMIT 10";
    $result = $conn->query($sql);
    $movimentacoes = [];
    while ($row = $result->fetch_assoc()) {
        $movimentacoes[] = [
            'id' => (int)$row['id'],
            'tipo' => $row['tipo'],
            'valor' => (float)$row['valor'],
            'descricao' => $row['descricao'],
            'data_movimentacao' => $row['data_movimentacao'],
            'operador' => $row['operador']
        ];
    }
    echo json_encode([
        'success' => true,
        'movimentacoes' => $movimentacoes
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar movimentações: ' . $e->getMessage()
    ]);
}
$conn->close(); 