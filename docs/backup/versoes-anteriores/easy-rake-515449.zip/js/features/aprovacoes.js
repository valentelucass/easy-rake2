// Sistema de Aprovações - Easy Rake
document.addEventListener('DOMContentLoaded', function() {
    carregarAprovacoes();
    atualizarCardsEstatisticas();
    
    // Atualizar a cada 30 segundos
    setInterval(() => {
        carregarAprovacoes();
        atualizarCardsEstatisticas();
    }, 30000);
});

async function carregarAprovacoes() {
    const tabela = document.querySelector('.data-table tbody');
    if (!tabela) return;
    
    tabela.innerHTML = '<tr><td colspan="7">Carregando...</td></tr>';
    
    try {
        const resp = await fetch('api/aprovacoes_listar_pendentes.php');
        const data = await resp.json();
        
        if (!data.success) {
            tabela.innerHTML = `<tr><td colspan="7">${data.message || 'Erro ao buscar aprovações.'}</td></tr>`;
            return;
        }
        
        if (!data.aprovacoes.length) {
            tabela.innerHTML = '<tr><td colspan="7">Nenhuma aprovação pendente encontrada</td></tr>';
            return;
        }
        
        tabela.innerHTML = '';
        data.aprovacoes.forEach(aprov => {
            const tr = document.createElement('tr');
            
            // Determinar classe do status
            let statusClass = 'badge-pendente';
            if (aprov.status === 'Aprovado') statusClass = 'badge-aprovado';
            else if (aprov.status === 'Rejeitado') statusClass = 'badge-rejeitado';
            
            tr.innerHTML = `
                <td>${aprov.id}</td>
                <td>
                    <div class="tipo-aprovacao">
                        <span class="tipo-badge tipo-${aprov.tipo.toLowerCase()}">${aprov.tipo}</span>
                    </div>
                </td>
                <td>
                    <div class="solicitante-info">
                        <strong>${aprov.solicitante_nome}</strong>
                        <small>${aprov.tipo_usuario ? '(' + aprov.tipo_usuario + ')' : ''}</small>
                    </div>
                </td>
                <td>
                    <div class="descricao-aprovacao">
                        <div class="descricao-principal">${aprov.descricao || 'Solicitação de aprovação'}</div>
                        ${aprov.detalhes ? `<div class="descricao-detalhes">${aprov.detalhes}</div>` : ''}
                    </div>
                </td>
                <td>${formatarData(aprov.data_solicitacao)}</td>
                <td><span class="badge ${statusClass}">${aprov.status}</span></td>
                <td>
                    <div class="acoes-aprovacao">
                        <button class="button button--small button--success" onclick="aprovarAprovacao('${aprov.tipo}','${aprov.id}')">
                            <i class="icon-check"></i> Aprovar
                        </button>
                        <button class="button button--small button--danger" onclick="rejeitarAprovacao('${aprov.tipo}','${aprov.id}')">
                            <i class="icon-x"></i> Rejeitar
                        </button>
                    </div>
                </td>
            `;
            tabela.appendChild(tr);
        });
    } catch (e) {
        console.error('Erro ao carregar aprovações:', e);
        tabela.innerHTML = '<tr><td colspan="7">Erro ao buscar aprovações.</td></tr>';
    }
}

async function atualizarCardsEstatisticas() {
    // Seletores dos cards
    const pendentesEl = document.querySelector('.approval-card:nth-child(1) .approval-count');
    const aprovadasHojeEl = document.querySelector('.approval-card:nth-child(2) .approval-count');
    const rejeitadasHojeEl = document.querySelector('.approval-card:nth-child(3) .approval-count');
    const totalEl = document.querySelector('.approval-card:nth-child(4) .approval-count');

    // Buscar pendentes
    let pendentes = 0;
    try {
        const respPend = await fetch('api/aprovacoes_listar_pendentes.php');
        const dataPend = await respPend.json();
        if (dataPend.success) {
            pendentes = dataPend.aprovacoes.length;
        }
    } catch {}
    if (pendentesEl) pendentesEl.textContent = `${pendentes} pendentes`;

    // Buscar histórico
    let aprovadasHoje = 0, rejeitadasHoje = 0, total = 0;
    try {
        const respHist = await fetch('api/aprovacoes_listar_historico.php');
        const dataHist = await respHist.json();
        if (dataHist.success) {
            const hoje = new Date().toISOString().slice(0,10);
            dataHist.historico.forEach(item => {
                if (item.status === 'Aprovado') {
                    if (item.data_aprovacao && item.data_aprovacao.slice(0,10) === hoje) aprovadasHoje++;
                }
                if (item.status === 'Rejeitado') {
                    if (item.data_aprovacao && item.data_aprovacao.slice(0,10) === hoje) rejeitadasHoje++;
                }
            });
            total = dataHist.historico.length;
        }
    } catch {}
    if (aprovadasHojeEl) aprovadasHojeEl.textContent = `${aprovadasHoje} aprovadas hoje`;
    if (rejeitadasHojeEl) rejeitadasHojeEl.textContent = `${rejeitadasHoje} rejeitadas hoje`;
    if (totalEl) totalEl.textContent = `${total} no total`;
}

// Funções globais para aprovação/rejeição
window.aprovarAprovacao = async function(tipo, id) {
    if (!confirm('Tem certeza que deseja aprovar esta solicitação?')) return;
    await acaoAprovacao(tipo, id, 'aprovar');
}

window.rejeitarAprovacao = async function(tipo, id) {
    if (!confirm('Tem certeza que deseja rejeitar esta solicitação?')) return;
    await acaoAprovacao(tipo, id, 'rejeitar');
}

async function acaoAprovacao(tipo, id, acao) {
    const tabela = document.querySelector('.data-table tbody');
    try {
        const resp = await fetch('api/aprovacoes_acao.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tipo, id, acao })
        });
        const data = await resp.json();
        
        if (data.success) {
            showNotification('Sucesso!', data.message, 'success');
            setTimeout(() => {
                carregarAprovacoes();
                atualizarCardsEstatisticas();
            }, 1000);
        } else {
            showNotification('Erro!', data.message || 'Não foi possível realizar a ação.', 'error');
        }
    } catch (e) {
        showNotification('Erro!', 'Erro de comunicação com o servidor.', 'error');
    }
}

// Função para exibir histórico
function exibirHistorico() {
    const tabela = document.querySelector('.data-table tbody');
    if (!tabela) return;
    
    tabela.innerHTML = '<tr><td colspan="7">Carregando histórico...</td></tr>';
    
    fetch('api/aprovacoes_listar_historico.php')
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                tabela.innerHTML = `<tr><td colspan="7">${data.message || 'Erro ao buscar histórico.'}</td></tr>`;
                return;
            }
            
            if (!data.historico.length) {
                tabela.innerHTML = '<tr><td colspan="7">Nenhum histórico encontrado</td></tr>';
                return;
            }
            
            tabela.innerHTML = '';
            data.historico.forEach(item => {
                let statusClass = 'badge-pendente';
                if (item.status === 'Aprovado') statusClass = 'badge-aprovado';
                else if (item.status === 'Rejeitado') statusClass = 'badge-rejeitado';
                else if (item.status === 'Removido') statusClass = 'badge-removido';
                
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${item.id}</td>
                    <td>
                        <div class="tipo-aprovacao">
                            <span class="tipo-badge tipo-${item.tipo.toLowerCase()}">${item.tipo}</span>
                        </div>
                    </td>
                    <td>
                        <div class="solicitante-info">
                            <strong>${item.solicitante_nome}</strong>
                            <small>${item.tipo_usuario ? '(' + item.tipo_usuario + ')' : ''}</small>
                        </div>
                    </td>
                    <td>
                        <div class="descricao-aprovacao">
                            <div class="descricao-principal">${item.descricao || 'Solicitação processada'}</div>
                            ${item.detalhes ? `<div class="descricao-detalhes">${item.detalhes}</div>` : ''}
                        </div>
                    </td>
                    <td>${formatarData(item.data_aprovacao || item.data_solicitacao)}</td>
                    <td><span class="badge ${statusClass}">${item.status}</span></td>
                    <td>
                        <div class="aprovador-info">
                            <small>Aprovado por: ${item.aprovador_nome || 'Sistema'}</small>
                        </div>
                    </td>
                `;
                tabela.appendChild(tr);
            });
        })
        .catch(() => {
            tabela.innerHTML = '<tr><td colspan="7">Erro ao buscar histórico.</td></tr>';
        });
}

// Event listeners para os botões dos cards
document.addEventListener('DOMContentLoaded', function() {
    // Botão "Ver Todas" (aprovacoes pendentes)
    const btnVerTodas = document.querySelector('.approval-card:nth-child(1) .button--primary');
    if (btnVerTodas) {
        btnVerTodas.addEventListener('click', () => {
            carregarAprovacoes(); // Volta para a lista de pendentes
        });
    }
    
    // Botões "Ver Histórico"
    document.querySelectorAll('.approval-card .button--secondary').forEach(btn => {
        btn.addEventListener('click', exibirHistorico);
    });
});

// Função auxiliar para formatar data
function formatarData(dataString) {
    if (!dataString) return '-';
    const data = new Date(dataString);
    return data.toLocaleString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Função para mostrar notificações (se não existir)
function showNotification(title, message, type = 'info') {
    if (typeof window.showNotification === 'function') {
        window.showNotification(title, message, type);
    } else {
        alert(`${title}: ${message}`);
    }
} 