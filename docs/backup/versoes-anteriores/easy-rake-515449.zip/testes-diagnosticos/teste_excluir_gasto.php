<?php
require_once __DIR__ . '/../api/db_connect.php';
header('Content-Type: text/plain; charset=utf-8');
echo "TESTE: Exclusão de Gasto\n";

// Buscar o gasto mais recente de um caixa aberto
$res = $conn->query("SELECT g.id FROM gastos g INNER JOIN caixas c ON g.caixa_id = c.id WHERE c.status = 'Aberto' ORDER BY g.data_registro DESC LIMIT 1");
if ($row = $res->fetch_assoc()) {
    $gasto_id = $row['id'];
    $stmt = $conn->prepare("DELETE FROM gastos WHERE id = ?");
    $stmt->bind_param('i', $gasto_id);
    $stmt->execute();
    if ($stmt->affected_rows > 0) {
        echo "Gasto ID $gasto_id excluído com sucesso!\n";
    } else {
        echo "Falha ao excluir gasto ID $gasto_id.\n";
    }
} else {
    echo "Nenhum gasto encontrado para excluir.\n";
} 