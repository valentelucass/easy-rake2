<?php
/**
 * CRIAÇÃO DE DADOS DE TESTE SIMPLES
 * Versão simplificada para evitar problemas de dependência
 */
require_once __DIR__ . '/../api/db_connect.php';

header('Content-Type: text/html; charset=utf-8');
echo "<h2>Criação de Dados de Teste Simples</h2>";

// Limpar dados de teste anteriores
$conn->query("DELETE FROM caixinhas_inclusoes WHERE usuario_id IN (SELECT id FROM usuarios WHERE nome LIKE '%TESTE%')");
$conn->query("DELETE FROM caixinhas WHERE caixa_id IN (SELECT id FROM caixas WHERE operador_id IN (SELECT id FROM usuarios WHERE nome LIKE '%TESTE%'))");
$conn->query("DELETE FROM caixas WHERE operador_id IN (SELECT id FROM usuarios WHERE nome LIKE '%TESTE%')");
$conn->query("DELETE FROM jogadores WHERE nome LIKE '%TESTE%'");
$conn->query("DELETE FROM associacoes_usuario_unidade WHERE id_usuario IN (SELECT id FROM usuarios WHERE nome LIKE '%TESTE%')");
$conn->query("DELETE FROM usuarios WHERE nome LIKE '%TESTE%'");
$conn->query("DELETE FROM unidades WHERE nome LIKE '%TESTE%'");

echo "<p>✅ Dados de teste anteriores removidos</p>";

// 1. Criar unidades de teste
$unidades = [
    ['nome' => 'Unidade Teste A', 'telefone' => '11999999999'],
    ['nome' => 'Unidade Teste B', 'telefone' => '11888888888']
];

foreach ($unidades as $unidade) {
    $codigo = strtoupper(substr(md5($unidade['nome'] . time()), 0, 8));
    $stmt = $conn->prepare("INSERT INTO unidades (nome, telefone, codigo_acesso) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $unidade['nome'], $unidade['telefone'], $codigo);
    $stmt->execute();
    echo "<p>✅ Unidade criada: {$unidade['nome']} (Código: $codigo)</p>";
}

// 2. Criar usuários de teste
$usuarios = [
    ['nome' => 'Gestor Teste A', 'cpf' => '111.111.111-11', 'tipo' => 'gestor', 'perfil' => 'Gestor'],
    ['nome' => 'Caixa Teste A', 'cpf' => '222.222.222-22', 'tipo' => 'caixa', 'perfil' => 'Caixa'],
    ['nome' => 'Gestor Teste B', 'cpf' => '333.333.333-33', 'tipo' => 'gestor', 'perfil' => 'Gestor'],
    ['nome' => 'Caixa Teste B', 'cpf' => '444.444.444-44', 'tipo' => 'caixa', 'perfil' => 'Caixa']
];

foreach ($usuarios as $usuario) {
    $senha_hash = password_hash('123456', PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, cpf, senha, tipo_usuario, perfil, status) VALUES (?, ?, ?, ?, ?, 'Ativo')");
    $stmt->bind_param("sssss", $usuario['nome'], $usuario['cpf'], $senha_hash, $usuario['tipo'], $usuario['perfil']);
    $stmt->execute();
    echo "<p>✅ Usuário criado: {$usuario['nome']}</p>";
}

// 3. Associar usuários às unidades
$associacoes = [
    ['usuario' => 'Gestor Teste A', 'unidade' => 'Unidade Teste A'],
    ['usuario' => 'Caixa Teste A', 'unidade' => 'Unidade Teste A'],
    ['usuario' => 'Gestor Teste B', 'unidade' => 'Unidade Teste B'],
    ['usuario' => 'Caixa Teste B', 'unidade' => 'Unidade Teste B']
];

foreach ($associacoes as $assoc) {
    $stmt = $conn->prepare("
        INSERT INTO associacoes_usuario_unidade (id_usuario, id_unidade, senha_hash, perfil, status_aprovacao) 
        SELECT u.id, un.id, u.senha, ?, 'Aprovado'
        FROM usuarios u, unidades un 
        WHERE u.nome = ? AND un.nome = ?
    ");
    $perfil = strpos($assoc['usuario'], 'Gestor') !== false ? 'Gestor' : 'Caixa';
    $stmt->bind_param("sss", $perfil, $assoc['usuario'], $assoc['unidade']);
    $stmt->execute();
    echo "<p>✅ Associação criada: {$assoc['usuario']} → {$assoc['unidade']}</p>";
}

// 4. Criar jogadores para cada unidade
$jogadores_unidade_a = [
    ['nome' => 'João Silva TESTE', 'cpf' => '555.555.555-55', 'telefone' => '11555555555'],
    ['nome' => 'Maria Santos TESTE', 'cpf' => '666.666.666-66', 'telefone' => '11666666666']
];

$jogadores_unidade_b = [
    ['nome' => 'Pedro Costa TESTE', 'cpf' => '777.777.777-77', 'telefone' => '11777777777'],
    ['nome' => 'Ana Lima TESTE', 'cpf' => '888.888.888-88', 'telefone' => '11888888888']
];

// Buscar ID da unidade A
$stmt = $conn->prepare("SELECT id FROM unidades WHERE nome = 'Unidade Teste A'");
$stmt->execute();
$result = $stmt->get_result();
$unidade_a_id = $result->fetch_assoc()['id'];

// Buscar ID da unidade B
$stmt = $conn->prepare("SELECT id FROM unidades WHERE nome = 'Unidade Teste B'");
$stmt->execute();
$result = $stmt->get_result();
$unidade_b_id = $result->fetch_assoc()['id'];

// Inserir jogadores da unidade A
foreach ($jogadores_unidade_a as $jogador) {
    $stmt = $conn->prepare("INSERT INTO jogadores (nome, cpf, telefone, unidade_id, status) VALUES (?, ?, ?, ?, 'Ativo')");
    $stmt->bind_param("sssi", $jogador['nome'], $jogador['cpf'], $jogador['telefone'], $unidade_a_id);
    $stmt->execute();
    echo "<p>✅ Jogador criado (Unidade A): {$jogador['nome']}</p>";
}

// Inserir jogadores da unidade B
foreach ($jogadores_unidade_b as $jogador) {
    $stmt = $conn->prepare("INSERT INTO jogadores (nome, cpf, telefone, unidade_id, status) VALUES (?, ?, ?, ?, 'Ativo')");
    $stmt->bind_param("sssi", $jogador['nome'], $jogador['cpf'], $jogador['telefone'], $unidade_b_id);
    $stmt->execute();
    echo "<p>✅ Jogador criado (Unidade B): {$jogador['nome']}</p>";
}

// 5. Criar caixas abertos
$caixas = [
    ['operador' => 'Caixa Teste A', 'valor' => 1000.00],
    ['operador' => 'Caixa Teste B', 'valor' => 1500.00]
];

foreach ($caixas as $caixa) {
    $stmt = $conn->prepare("
        INSERT INTO caixas (operador_id, valor_inicial, status) 
        SELECT id, ?, 'Aberto' FROM usuarios WHERE nome = ?
    ");
    $stmt->bind_param("ds", $caixa['valor'], $caixa['operador']);
    $stmt->execute();
    echo "<p>✅ Caixa aberto: {$caixa['operador']} (R$ {$caixa['valor']})</p>";
}

echo "<h3>🎯 Dados de Teste Básicos Criados com Sucesso!</h3>";
echo "<p><strong>Resumo:</strong></p>";
echo "<ul>";
echo "<li>2 Unidades (A e B)</li>";
echo "<li>4 Usuários (2 gestores, 2 caixas)</li>";
echo "<li>4 Jogadores (2 por unidade)</li>";
echo "<li>2 Caixas abertos</li>";
echo "</ul>";

echo "<p><strong>Próximo passo:</strong> Executar testes de diagnóstico automático</p>";
?> 