<?php
require_once __DIR__ . '/../api/db_connect.php';

echo "=== ESTRUTURA CAIXINHAS_INCLUSOES ===\n";

$sql = "SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_KEY 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_SCHEMA = 'easy_rake' 
        AND TABLE_NAME = 'caixinhas_inclusoes' 
        ORDER BY ORDINAL_POSITION";

$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo "Campo: {$row['COLUMN_NAME']} - Tipo: {$row['DATA_TYPE']} - Null: {$row['IS_NULLABLE']} - Key: {$row['COLUMN_KEY']}\n";
    }
} else {
    echo "Erro: " . $conn->error . "\n";
}

echo "\n=== DADOS EXISTENTES ===\n";
$result = $conn->query("SELECT COUNT(*) as total FROM caixinhas_inclusoes");
if ($result) {
    $row = $result->fetch_assoc();
    echo "Total de registros: {$row['total']}\n";
    
    if ($row['total'] > 0) {
        $result = $conn->query("SELECT * FROM caixinhas_inclusoes LIMIT 3");
        while ($row = $result->fetch_assoc()) {
            echo "ID: {$row['id']} - Caixinha: {$row['caixinha_id']} - Valor: {$row['valor']} - Usuario: {$row['usuario_id']} - Operador: {$row['operador_id']}\n";
        }
    }
} else {
    echo "Erro: " . $conn->error . "\n";
}
?> 