<?php
require_once __DIR__ . '/../api/db_connect.php';

echo "Teste de conexao\n";
echo "Conexao: " . ($conn ? "OK" : "ERRO") . "\n";

$result = $conn->query("SELECT 1 as teste");
if ($result) {
    $row = $result->fetch_assoc();
    echo "Query teste: " . $row['teste'] . "\n";
} else {
    echo "Erro na query: " . $conn->error . "\n";
}

$result = $conn->query("SHOW TABLES");
if ($result) {
    echo "Tabelas encontradas: " . $result->num_rows . "\n";
} else {
    echo "Erro ao listar tabelas: " . $conn->error . "\n";
}
?> 