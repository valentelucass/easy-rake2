<?php
/**
 * TESTE AVANÇADO: Busca de jogadores por unidade
 */
require_once __DIR__ . '/../api/db_connect.php';

header('Content-Type: text/html; charset=utf-8');
echo "<h2>Teste Avançado: Busca de jogadores por unidade</h2>";

// Buscar todas as unidades
$unidades = [];
$res = $conn->query("SELECT id, nome FROM unidades");
while ($row = $res->fetch_assoc()) {
    $unidades[] = $row;
}

foreach ($unidades as $unidade) {
    echo "<h3>Unidade: {$unidade['nome']} (ID: {$unidade['id']})</h3>";
    // Buscar um usuário aprovado dessa unidade
    $res2 = $conn->query("SELECT id_usuario FROM associacoes_usuario_unidade WHERE id_unidade = {$unidade['id']} AND status_aprovacao = 'Aprovado' LIMIT 1");
    if ($row2 = $res2->fetch_assoc()) {
        $user_id = $row2['id_usuario'];
        // Simular sessão
        $_SESSION = [
            'logged_in' => true,
            'user_id' => $user_id,
            'perfil' => 'Caixa',
        ];
        // Buscar jogadores dessa unidade
        $res3 = $conn->query("SELECT * FROM jogadores WHERE unidade_id = {$unidade['id']}");
        $total = $res3->num_rows;
        echo "<p>Total de jogadores encontrados: $total</p>";
        while ($row3 = $res3->fetch_assoc()) {
            echo "ID: {$row3['id']} - {$row3['nome']}<br>";
        }
    } else {
        echo "<p style='color:orange;'>Nenhum usuário aprovado para esta unidade.</p>";
    }
}
echo "<strong>Teste concluído.</strong>"; 