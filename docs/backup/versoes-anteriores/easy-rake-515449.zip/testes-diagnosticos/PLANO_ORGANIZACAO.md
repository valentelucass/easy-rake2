# 📁 PLANO DE ORGANIZAÇÃO - TESTES-DIAGNÓSTICOS

## 🎯 OBJETIVO
Consolidar e organizar a pasta `testes-diagnosticos` removendo duplicações, agrupando funcionalidades relacionadas e criando uma estrutura mais limpa e eficiente.

## 📊 ANÁLISE ATUAL

### Arquivos Identificados (35 arquivos)
- **Documentação**: 8 arquivos (.md)
- **Scripts de Diagnóstico**: 12 arquivos (.php)
- **Scripts de Teste**: 6 arquivos (.php)
- **Scripts de Correção**: 3 arquivos (.php)
- **Scripts de Sistema IA**: 3 arquivos (.php)
- **Arquivos Temporários**: 3 arquivos (.txt)

## 🔧 PLANO DE CONSOLIDAÇÃO

### 1. **CONSOLIDAR DOCUMENTAÇÃO** (8 → 2 arquivos)

**Manter:**
- `README.md` - Documentação principal (já consolidada)
- `RELATORIO_INTEGRACAO_SISTEMA.md` - Relatório específico de integração

**Remover/Consolidar:**
- `SISTEMA_IA_COMPLETO.md` → Integrar no README.md
- `RESUMO_DOCUMENTACAO.md` → Integrar no README.md
- `RESUMO_CORRECOES_SEGURANCA.md` → Integrar no README.md
- `PROMPT_IA_CSS_EASY_RAKE.md` → Mover para pasta específica ou remover
- `exemplo_uso.php` → Integrar no README.md

### 2. **CONSOLIDAR SCRIPTS DE VERIFICAÇÃO** (6 → 1 arquivo)

**Arquivos a consolidar:**
- `verificar_estrutura.php`
- `verificar_caixa_id.php`
- `verificar_movimentacoes.php`
- `verificar_dashboard.php`
- `verificar_caixas_abertos.php`
- `verificar_caixa_27.php`

**Novo arquivo:** `verificador_estrutura.php` (consolida todos)

### 3. **CONSOLIDAR SCRIPTS DE DIAGNÓSTICO** (6 → 2 arquivos)

**Manter:**
- `diagnostico_simples.php` - Diagnóstico rápido (já consolidado)
- `diagnostico_inteligente.php` - Diagnóstico completo (já consolidado)

**Remover/Consolidar:**
- `diagnostico_usuarios_funcionarios.php` → Integrar no diagnostico_simples.php
- `diagnostico_codigos_acesso.php` → Integrar no diagnostico_simples.php
- `diagnostico_banco_relatorios.php` → Integrar no diagnostico_simples.php
- `check_db.php` → Integrar no diagnostico_simples.php

### 4. **CONSOLIDAR SCRIPTS DE TESTE** (6 → 2 arquivos)

**Manter:**
- `teste_simples_integracao.php` - Teste de integração (já consolidado)
- `teste_sistema_aprovacoes.php` - Teste específico de aprovações

**Remover/Consolidar:**
- `teste_integracao_sistema.php` → Remover (duplicado do teste_simples_integracao.php)
- `teste_conexao.php` → Integrar no diagnostico_simples.php
- `query_caixas.php` → Integrar no verificador_estrutura.php
- `simples.php` → Integrar no diagnostico_simples.php

### 5. **CONSOLIDAR SCRIPTS DE CORREÇÃO** (3 → 1 arquivo)

**Manter:**
- `corretor_automatico.php` - Corretor principal (já consolidado)

**Remover/Consolidar:**
- `corrigir_caixas_multiplos.php` → Integrar no corretor_automatico.php
- `investigar_caixas.php` → Integrar no diagnostico_simples.php

### 6. **CONSOLIDAR SCRIPTS DE SISTEMA IA** (3 → 1 arquivo)

**Manter:**
- `sistema_ia.php` - Sistema IA consolidado

**Remover/Consolidar:**
- `IA_MEMORY_HOOK.php` → Integrar no sistema_ia.php
- `IA_CONFIG.php` → Integrar no sistema_ia.php
- `ATUALIZADOR_AUTOMATICO.php` → Integrar no sistema_ia.php

### 7. **REMOVER ARQUIVOS TEMPORÁRIOS** (3 arquivos)

**Remover:**
- `test_cookies.txt`
- `cookies.txt`
- `gestor_cookie.txt`

### 8. **REMOVER ARQUIVOS ESPECÍFICOS** (3 arquivos)

**Remover:**
- `remover_operador.php` - Script específico já executado
- `teste_seguranca.php` - Teste específico já executado
- `auditoria_seguranca.php` - Auditoria específica já executada
- `seed_relatorios.php` - Seed específico já executado

## 📁 ESTRUTURA FINAL PROPOSTA

```
testes-diagnosticos/
├── 📋 DOCUMENTAÇÃO
│   ├── README.md                           # Documentação principal consolidada
│   └── RELATORIO_INTEGRACAO_SISTEMA.md     # Relatório específico
│
├── 🔍 DIAGNÓSTICOS
│   ├── diagnostico_simples.php             # Diagnóstico rápido consolidado
│   └── diagnostico_inteligente.php         # Diagnóstico completo
│
├── 🧪 TESTES
│   ├── teste_simples_integracao.php        # Teste de integração
│   └── teste_sistema_aprovacoes.php        # Teste de aprovações
│
├── 🔧 CORREÇÃO
│   └── corretor_automatico.php             # Corretor consolidado
│
├── 🤖 SISTEMA IA
│   └── sistema_ia.php                      # Sistema IA consolidado
│
├── 📊 VERIFICAÇÃO
│   └── verificador_estrutura.php           # Verificador consolidado
│
├── 🗂️ CONFIGURAÇÃO
│   ├── .gitignore                          # Git ignore
│   └── PLANO_ORGANIZACAO.md                # Este arquivo
│
└── 📝 RELATÓRIOS
    └── RELATORIO_INTEGRACAO_SISTEMA.md     # Relatório de integração
```

## 📈 BENEFÍCIOS DA ORGANIZAÇÃO

### Antes: 35 arquivos
- Muitas duplicações
- Funcionalidades espalhadas
- Difícil manutenção
- Confusão sobre qual usar

### Depois: 10 arquivos principais
- Funcionalidades consolidadas
- Fácil manutenção
- Estrutura clara
- Sem duplicações

## 🎯 PRÓXIMOS PASSOS

1. **Criar arquivos consolidados**
2. **Testar funcionalidades**
3. **Remover arquivos antigos**
4. **Atualizar documentação**
5. **Validar estrutura final**

## 📋 CHECKLIST DE EXECUÇÃO

- [ ] Consolidar documentação
- [ ] Consolidar scripts de verificação
- [ ] Consolidar scripts de diagnóstico
- [ ] Consolidar scripts de teste
- [ ] Consolidar scripts de correção
- [ ] Consolidar scripts de sistema IA
- [ ] Remover arquivos temporários
- [ ] Remover arquivos específicos
- [ ] Testar todos os scripts consolidados
- [ ] Atualizar README.md
- [ ] Validar estrutura final 