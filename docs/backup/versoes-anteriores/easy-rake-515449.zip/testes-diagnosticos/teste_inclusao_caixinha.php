<?php
/**
 * TESTE AVANÇADO: Inclusão de valor em caixinhas (segurança)
 */
require_once __DIR__ . '/../api/db_connect.php';

header('Content-Type: text/html; charset=utf-8');
echo "<h2>Teste Avançado: Inclusão de valor em caixinhas (segurança)</h2>";

// Buscar um usuário operador com caixa aberto
$res = $conn->query("SELECT u.id as user_id, c.id as caixa_id FROM usuarios u INNER JOIN caixas c ON u.id = c.operador_id WHERE c.status = 'Aberto' LIMIT 1");
if ($row = $res->fetch_assoc()) {
    $user_id = $row['user_id'];
    $caixa_id = $row['caixa_id'];
    // Buscar caixinha desse caixa
    $res2 = $conn->query("SELECT id FROM caixinhas WHERE caixa_id = $caixa_id LIMIT 1");
    if ($row2 = $res2->fetch_assoc()) {
        $caixinha_id = $row2['id'];
        // Simular sessão
        $_SESSION = [
            'logged_in' => true,
            'user_id' => $user_id,
            'perfil' => 'Caixa',
        ];
        // Tentar incluir valor (deveria funcionar)
        $ok = $conn->query("INSERT INTO caixinhas_inclusoes (caixinha_id, valor, usuario_id) VALUES ($caixinha_id, 10.00, $user_id)");
        if ($ok) {
            echo "<p style='color:green;'>✅ Inclusão de valor na própria caixinha: OK</p>";
        } else {
            echo "<p style='color:red;'>❌ Falha ao incluir valor na própria caixinha: " . $conn->error . "</p>";
        }
    } else {
        echo "<p style='color:orange;'>Nenhuma caixinha encontrada para o caixa aberto.</p>";
    }
    // Buscar caixinha de outro caixa
    $res3 = $conn->query("SELECT cx.id, c.operador_id FROM caixinhas cx INNER JOIN caixas c ON cx.caixa_id = c.id WHERE c.operador_id != $user_id LIMIT 1");
    if ($row3 = $res3->fetch_assoc()) {
        $outra_caixinha_id = $row3['id'];
        // Tentar incluir valor (deveria falhar)
        $ok2 = $conn->query("INSERT INTO caixinhas_inclusoes (caixinha_id, valor, usuario_id) VALUES ($outra_caixinha_id, 10.00, $user_id)");
        if ($ok2) {
            echo "<p style='color:red;'>❌ Inclusão de valor em caixinha de outro caixa NÃO deveria ser permitida!</p>";
        } else {
            echo "<p style='color:green;'>✅ Inclusão de valor em caixinha de outro caixa foi bloqueada: " . $conn->error . "</p>";
        }
    } else {
        echo "<p style='color:orange;'>Nenhuma caixinha de outro caixa encontrada para teste.</p>";
    }
} else {
    echo "<p style='color:orange;'>Nenhum operador com caixa aberto encontrado.</p>";
}
echo "<strong>Teste concluído.</strong>"; 