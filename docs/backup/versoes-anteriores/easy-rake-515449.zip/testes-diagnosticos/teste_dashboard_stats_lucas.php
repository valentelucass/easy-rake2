<?php
session_start();

// Simular login como Lucas Andrade (user_id 1, perfil Gestor)
$_SESSION['logged_in'] = true;
$_SESSION['user_id'] = 1;
$_SESSION['perfil'] = 'Gestor';

chdir(__DIR__ . '/../api/dashboard');
require_once 'get_stats.php';
?> 