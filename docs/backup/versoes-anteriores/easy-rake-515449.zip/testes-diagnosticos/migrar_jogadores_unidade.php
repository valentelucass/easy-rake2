<?php
/**
 * MIGRAÇÃO: Adiciona unidade_id em jogadores e associa corretamente
 */
require_once __DIR__ . '/../api/db_connect.php';

header('Content-Type: text/html; charset=utf-8');
echo "<h2>Migração: Adicionar unidade_id em jogadores</h2>";

// 1. Adicionar coluna unidade_id se não existir
$col_exists = $conn->query("SHOW COLUMNS FROM jogadores LIKE 'unidade_id'");
if ($col_exists && $col_exists->num_rows === 0) {
    $ok = $conn->query("ALTER TABLE jogadores ADD COLUMN unidade_id INT NULL AFTER id");
    if ($ok) {
        echo "✅ Coluna unidade_id adicionada em jogadores<br>";
    } else {
        echo "❌ Erro ao adicionar coluna unidade_id: " . $conn->error . "<br>";
        exit;
    }
} else {
    echo "Coluna unidade_id já existe<br>";
}

// 2. Associar jogadores existentes à unidade do operador que os cadastrou (se possível)
// (Assumindo que existe um campo operador_id ou similar, caso contrário, deixar NULL)
$col_operador = $conn->query("SHOW COLUMNS FROM jogadores LIKE 'operador_id'");
if ($col_operador && $col_operador->num_rows > 0) {
    // Para cada jogador, buscar unidade do operador
    $result = $conn->query("SELECT j.id, j.operador_id, aau.id_unidade FROM jogadores j LEFT JOIN associacoes_usuario_unidade aau ON j.operador_id = aau.id_usuario LIMIT 1000");
    $atualizados = 0;
    while ($row = $result->fetch_assoc()) {
        if ($row['id_unidade']) {
            $conn->query("UPDATE jogadores SET unidade_id = " . intval($row['id_unidade']) . " WHERE id = " . intval($row['id']));
            $atualizados++;
        }
    }
    echo "Jogadores atualizados com unidade: $atualizados<br>";
} else {
    // Não há operador_id, deixar NULL e usuário terá que corrigir manualmente
    echo "Jogadores existentes não possuem operador_id, unidade_id ficará NULL. Corrija manualmente se necessário.<br>";
}

// 3. Adicionar foreign key
$fk_exists = $conn->query("SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_NAME = 'jogadores' AND COLUMN_NAME = 'unidade_id' AND REFERENCED_TABLE_NAME = 'unidades'");
if ($fk_exists && $fk_exists->num_rows === 0) {
    $ok = $conn->query("ALTER TABLE jogadores ADD CONSTRAINT fk_jogadores_unidade FOREIGN KEY (unidade_id) REFERENCES unidades(id) ON DELETE SET NULL");
    if ($ok) {
        echo "✅ Foreign key criada<br>";
    } else {
        echo "❌ Erro ao criar foreign key: " . $conn->error . "<br>";
    }
} else {
    echo "Foreign key já existe<br>";
}

echo "<strong>Migração concluída.</strong>"; 