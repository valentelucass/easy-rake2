<?php
require_once __DIR__ . '/../api/db_connect.php';

echo "VERIFICANDO ESTRUTURA DETALHADA:\n";

try {
    $result = $conn->query('DESCRIBE caixinhas_inclusoes');
    if ($result) {
        echo "Campos na tabela caixinhas_inclusoes:\n";
        while ($row = $result->fetch_assoc()) {
            echo "- {$row['Field']}: {$row['Type']} ({$row['Null']}) {$row['Key']}\n";
        }
    } else {
        echo "Erro ao executar DESCRIBE: " . $conn->error . "\n";
    }
} catch (Exception $e) {
    echo "Exceção: " . $e->getMessage() . "\n";
}

echo "\nVERIFICANDO DADOS EXISTENTES:\n";
try {
    $result = $conn->query('SELECT COUNT(*) as total FROM caixinhas_inclusoes');
    if ($result) {
        $row = $result->fetch_assoc();
        echo "Total de registros: {$row['total']}\n";
    } else {
        echo "Erro ao contar registros: " . $conn->error . "\n";
    }
} catch (Exception $e) {
    echo "Exceção: " . $e->getMessage() . "\n";
}
?> 