<?php
require_once __DIR__ . '/../api/db_connect.php';

$result = $conn->query("SELECT COUNT(*) as total FROM caixinhas_inclusoes");
$row = $result->fetch_assoc();
echo "Total registros: " . $row['total'] . "\n";

if ($row['total'] > 0) {
    $result = $conn->query("SELECT * FROM caixinhas_inclusoes LIMIT 1");
    $row = $result->fetch_assoc();
    print_r($row);
}
?> 