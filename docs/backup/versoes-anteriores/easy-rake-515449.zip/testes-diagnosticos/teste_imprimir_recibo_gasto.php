<?php
require_once __DIR__ . '/../api/db_connect.php';
header('Content-Type: text/plain; charset=utf-8');
echo "TESTE: Impressão de Recibo de Gasto\n";

// Buscar o gasto mais recente de um caixa aberto
$res = $conn->query("SELECT g.id FROM gastos g INNER JOIN caixas c ON g.caixa_id = c.id WHERE c.status = 'Aberto' ORDER BY g.data_registro DESC LIMIT 1");
if ($row = $res->fetch_assoc()) {
    $gasto_id = $row['id'];
    // Simular chamada à API de impressão de recibo
    $url = 'http://localhost/easy-rake/api/caixas/imprimir_recibo_gasto.php?id=' . $gasto_id;
    echo "Acesse no navegador para testar: $url\n";
    // Opcional: tentar abrir via file_get_contents (se permitido)
    $output = @file_get_contents($url);
    if ($output) {
        echo "Resposta da API:\n";
        echo $output;
    } else {
        echo "Não foi possível acessar a API diretamente via CLI. Teste no navegador.\n";
    }
} else {
    echo "Nenhum gasto encontrado para imprimir recibo.\n";
} 