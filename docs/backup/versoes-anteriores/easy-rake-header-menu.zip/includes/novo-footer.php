<!-- NOVO FOOTER EASY RAKE -->
<link rel="stylesheet" href="css/components/novo-footer.css">
<footer class="novo-footer">
    <div class="novo-footer__container">
        <span>&copy; <?php echo date('Y'); ?> Easy Rake. Todos os direitos reservados.</span>
    </div>
</footer> 