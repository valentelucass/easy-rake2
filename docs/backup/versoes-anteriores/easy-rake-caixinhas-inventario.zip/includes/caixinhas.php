  <div class="card-box section caixinhas-card">
    <h3>Conferência de Fichas - Caixinhas</h3>
    <p>
      Área de conferência de caixa com relação ao inventário.<br>
      <strong>Valor Atual (Calculado pelo Sistema):</strong> <span id="caixinhas-valor-atual">R$ 0,00</span>
    </p>
    <ul class="caixinhas-legenda">
      <li>O valor diminui quando um jogador compra fichas.</li>
      <li>O valor aumenta quando fichas retornam ao caixa (devolução, entrada de rake, entrada de caixinha).</li>
    </ul>
    <button class="btn btn-primary caixinhas-btn-conferido" id="btn-conferir-caixinhas">Marcar como Conferido</button>
  </div>

  <div class="card-box section caixinhas-card">
    <h4>Histórico de Conferências</h4>
    <div class="caixinhas-tabela">
      <table>
        <thead>
          <tr>
            <th>Horário</th>
            <th>Valor Conferido</th>
            <th>Responsável</th>
          </tr>
        </thead>
        <tbody id="caixinhas-historico-tbody">
          <!-- Linhas serão preenchidas via JS -->
        </tbody>
      </table>
    </div>
  </div> 