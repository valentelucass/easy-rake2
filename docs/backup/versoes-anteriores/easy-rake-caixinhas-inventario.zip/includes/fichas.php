<?php include __DIR__ . '/fichas-aba.php'; ?>
<!-- O JS de fichas já está incluído no fichas-aba.php, junto ao CSS --> 