// js/features/caixa-dashboard/caixinhas.js

document.addEventListener('DOMContentLoaded', function () {
  // Mock: valor atual
  const valorAtual = 12345.67;
  document.getElementById('caixinhas-valor-atual').textContent =
    'R$ ' + valorAtual.toLocaleString('pt-BR', { minimumFractionDigits: 2 });

  // Mock: histórico de conferências
  const historico = [
    { horario: '2024-06-01 18:00', valor: 12000.00, responsavel: 'João' },
    { horario: '2024-06-01 22:00', valor: 12345.67, responsavel: 'Maria' },
  ];
  const tbody = document.getElementById('caixinhas-historico-tbody');
  tbody.innerHTML = '';
  historico.forEach(item => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${item.horario}</td>
      <td>R$ ${item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
      <td>${item.responsavel}</td>
    `;
    tbody.appendChild(tr);
  });

  // Botão de conferido
  const btn = document.getElementById('btn-conferir-caixinhas');
  btn.addEventListener('click', function () {
    alert('Conferência registrada! (mock)');
    // Aqui você pode implementar a lógica real de conferência
  });
}); 