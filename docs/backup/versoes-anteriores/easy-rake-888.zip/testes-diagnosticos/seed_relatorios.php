<?php
// Seed para popular tabelas de relatórios do Easy Rake
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'api/db_connect.php';

function print_status($msg) {
    echo $msg . "<br>\n";
}

try {
    echo "<h1>🧪 Seed de Dados para Relatórios - Easy Rake</h1>";
    // Limpeza prévia dos dados de teste
    $conn->query("DELETE FROM transacoes_jogadores WHERE observacao LIKE '%seed%' OR observacao IS NULL");
    $conn->query("DELETE FROM movimentacoes WHERE descricao LIKE '%seed%' OR descricao IS NULL");
    $conn->query("DELETE FROM gastos WHERE descricao LIKE '%seed%' OR descricao IS NULL");
    $conn->query("DELETE FROM relatorios_historico WHERE arquivo LIKE '%seed%' OR arquivo IS NULL");
    // Não limpar aprovacoes para não interferir em testes de aprovação

    // Buscar IDs existentes para FKs
    $result = $conn->query("SELECT id FROM jogadores LIMIT 1");
    $jogador_id = $result && $result->num_rows ? $result->fetch_assoc()['id'] : null;
    $result = $conn->query("SELECT id FROM usuarios LIMIT 1");
    $operador_id = $result && $result->num_rows ? $result->fetch_assoc()['id'] : null;
    $result = $conn->query("SELECT id FROM caixas LIMIT 1");
    $caixa_id = $result && $result->num_rows ? $result->fetch_assoc()['id'] : null;
    if (!$jogador_id || !$operador_id || !$caixa_id) {
        throw new Exception('IDs de referência não encontrados. Cadastre pelo menos 1 jogador, 1 usuário e 1 caixa.');
    }

    // Inserir transações de jogadores
    $stmt = $conn->prepare("INSERT INTO transacoes_jogadores (jogador_id, operador_id, tipo, valor, observacao, data_transacao) VALUES (?, ?, ?, ?, ?, NOW())");
    $tipo = 'CREDITO'; $valor = 500.00; $obs = 'Transação seed 1';
    $stmt->bind_param('iidss', $jogador_id, $operador_id, $tipo, $valor, $obs);
    $stmt->execute();
    $tipo = 'DEBITO'; $valor = 200.00; $obs = 'Transação seed 2';
    $stmt->bind_param('iidss', $jogador_id, $operador_id, $tipo, $valor, $obs);
    $stmt->execute();
    print_status('Transações de jogadores inseridas.');

    // Inserir movimentações
    $stmt = $conn->prepare("INSERT INTO movimentacoes (caixa_id, tipo, valor, descricao, operador_id, data_movimentacao) VALUES (?, ?, ?, ?, ?, NOW())");
    $tipo = 'Entrada'; $valor = 1000.00; $desc = 'Movimentação seed 1';
    $stmt->bind_param('isdsi', $caixa_id, $tipo, $valor, $desc, $operador_id);
    $stmt->execute();
    $tipo = 'Saída'; $valor = 300.00; $desc = 'Movimentação seed 2';
    $stmt->bind_param('isdsi', $caixa_id, $tipo, $valor, $desc, $operador_id);
    $stmt->execute();
    print_status('Movimentações inseridas.');

    // Inserir gastos
    $stmt = $conn->prepare("INSERT INTO gastos (caixa_id, descricao, valor, operador_id, data_registro) VALUES (?, ?, ?, ?, NOW())");
    $desc = 'Gasto seed 1'; $valor = 150.00;
    $stmt->bind_param('ssdi', $caixa_id, $desc, $valor, $operador_id);
    $stmt->execute();
    $desc = 'Gasto seed 2'; $valor = 80.00;
    $stmt->bind_param('ssdi', $caixa_id, $desc, $valor, $operador_id);
    $stmt->execute();
    print_status('Gastos inseridos.');

    // Inserir histórico de relatórios
    $stmt = $conn->prepare("INSERT INTO relatorios_historico (id_usuario, tipo, status, data_geracao, arquivo) VALUES (?, ?, ?, NOW(), ?)");
    $tipo = 'PDF'; $status = 'Gerado'; $arq = 'relatorio_seed_1.pdf';
    $stmt->bind_param('isss', $operador_id, $tipo, $status, $arq);
    $stmt->execute();
    $tipo = 'Excel'; $status = 'Gerado'; $arq = 'relatorio_seed_2.xlsx';
    $stmt->bind_param('isss', $operador_id, $tipo, $status, $arq);
    $stmt->execute();
    print_status('Histórico de relatórios inserido.');

    echo '<h2>✅ Seed concluído com sucesso!</h2>';
    echo '<p>As tabelas de relatórios agora possuem dados de exemplo para testes e visualização.</p>';

} catch (Exception $e) {
    echo '<span style="color:red">❌ Erro no seed: ' . $e->getMessage() . '</span>';
}

$conn->close(); 