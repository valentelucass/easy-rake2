<?php
echo "Verificando dashboard...\n";

$conn = new mysqli('localhost', 'root', '36140888', 'easy_rake', 3307);

if ($conn->connect_error) {
    echo "Erro de conexão: " . $conn->connect_error . "\n";
    exit;
}

echo "Conexão OK!\n\n";

// Query atual do dashboard
$sql_dashboard = "SELECT COUNT(*) as total FROM caixas WHERE status = 'Aberto'";
$result = $conn->query($sql_dashboard);
$dashboard_count = $result ? $result->fetch_assoc()['total'] : 0;

echo "Dashboard mostra: $dashboard_count caixas abertos\n";

// Query que deveria ser usada (com operador aprovado)
$sql_corrigida = "SELECT COUNT(*) as total FROM caixas c 
                  INNER JOIN associacoes_usuario_unidade aau ON c.operador_id = aau.id_usuario 
                  WHERE c.status = 'Aberto' AND aau.status_aprovacao = 'Aprovado'";
$result = $conn->query($sql_corrigida);
$corrigido_count = $result ? $result->fetch_assoc()['total'] : 0;

echo "Contagem corrigida: $corrigido_count caixas abertos (com operador aprovado)\n\n";

// Verificar todos os caixas abertos com detalhes
$sql_detalhes = "SELECT c.id, c.operador_id, c.valor_inicial, c.data_abertura, 
                        u.nome as operador_nome, aau.status_aprovacao, aau.perfil
                 FROM caixas c 
                 LEFT JOIN usuarios u ON c.operador_id = u.id 
                 LEFT JOIN associacoes_usuario_unidade aau ON c.operador_id = aau.id_usuario 
                 WHERE c.status = 'Aberto'
                 ORDER BY c.data_abertura DESC";
$result = $conn->query($sql_detalhes);

if ($result) {
    echo "Detalhes dos caixas abertos:\n";
    while ($caixa = $result->fetch_assoc()) {
        $status_icon = $caixa['status_aprovacao'] == 'Aprovado' ? '✅' : '❌';
        echo "  $status_icon ID: {$caixa['id']} - {$caixa['operador_nome']} - R$ " . number_format($caixa['valor_inicial'], 2, ',', '.') . " - {$caixa['data_abertura']} - {$caixa['status_aprovacao']}\n";
    }
}

echo "\nConclusão:\n";
if ($dashboard_count == $corrigido_count) {
    echo "✅ Dashboard está correto!\n";
    echo "✅ Todos os caixas abertos têm operador aprovado\n";
} else {
    echo "⚠️  Dashboard pode estar incorreto\n";
    echo "⚠️  Diferença: " . ($dashboard_count - $corrigido_count) . " caixas\n";
}

$conn->close();
?> 