<?php
echo "Verificando caixa ID 27...\n";

$conn = new mysqli('localhost', 'root', '36140888', 'easy_rake', 3307);

if ($conn->connect_error) {
    echo "Erro de conexão: " . $conn->connect_error . "\n";
    exit;
}

echo "Conexão OK!\n\n";

// Verificar detalhes do caixa 27
$sql = "SELECT c.*, u.nome as operador_nome, aau.status_aprovacao, aau.perfil
        FROM caixas c 
        LEFT JOIN usuarios u ON c.operador_id = u.id 
        LEFT JOIN associacoes_usuario_unidade aau ON c.operador_id = aau.id_usuario 
        WHERE c.id = 27";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $caixa = $result->fetch_assoc();
    echo "Caixa ID 27:\n";
    echo "  Operador: {$caixa['operador_nome']} (ID: {$caixa['operador_id']})\n";
    echo "  Status: {$caixa['status']}\n";
    echo "  Valor inicial: R$ " . number_format($caixa['valor_inicial'], 2, ',', '.') . "\n";
    echo "  Data abertura: {$caixa['data_abertura']}\n";
    echo "  Data fechamento: " . ($caixa['data_fechamento'] ?: 'N/A') . "\n";
    echo "  Status aprovação: {$caixa['status_aprovacao']}\n";
    echo "  Perfil: {$caixa['perfil']}\n";
    echo "  Observações: " . ($caixa['observacoes'] ?: 'N/A') . "\n";
} else {
    echo "Caixa ID 27 não encontrado!\n";
}

echo "\nVerificando se Lucas Andrade tem múltiplos caixas abertos:\n";
$sql2 = "SELECT c.id, c.status, c.data_abertura, c.valor_inicial 
         FROM caixas c 
         WHERE c.operador_id = 1 AND c.status = 'Aberto'
         ORDER BY c.data_abertura DESC";
$result2 = $conn->query($sql2);

if ($result2) {
    echo "Caixas abertos de Lucas Andrade:\n";
    while ($caixa = $result2->fetch_assoc()) {
        echo "  ID: {$caixa['id']} - Valor: R$ " . number_format($caixa['valor_inicial'], 2, ',', '.') . " - Data: {$caixa['data_abertura']}\n";
    }
} else {
    echo "Erro na query: " . $conn->error . "\n";
}

$conn->close();
?> 