<?php
/**
 * 🔒 TESTE DE SEGURANÇA - Easy Rake
 * 
 * Script rápido para testar se as correções de segurança funcionaram.
 */

require_once __DIR__ . '/../api/db_connect.php';

echo "🔒 TESTE DE SEGURANÇA - EASY RAKE\n";
echo "=================================\n\n";

// Verificar conexão
if (!isset($conn) || $conn->connect_error) {
    echo "❌ ERRO: Não foi possível conectar ao banco de dados\n";
    exit;
}

echo "✅ Conexão MySQL OK (Porta 3307)\n\n";

// Simular sessão de usuário
session_start();
$_SESSION['logged_in'] = true;
$_SESSION['user_id'] = 1; // Lucas Andrade

echo "👤 Usuário logado: Lucas Andrade (ID: 1)\n\n";

// Testar APIs corrigidas
$apis_testadas = [
    'api/caixas/get_caixa_info.php' => 'get_caixa_info.php?id=26',
    'api/caixas/compilar_dados.php' => 'compilar_dados.php?caixa_id=26',
    'api/caixas/rake_listar.php' => 'rake_listar.php?caixa_id=26',
    'api/caixas/historico_conferencia.php' => 'historico_conferencia.php?caixa_id=26',
    'api/caixas/get_session_stats.php' => 'get_session_stats.php?id_caixa=26',
    'api/caixas/caixinhas_listar_inclusoes.php' => 'caixinhas_listar_inclusoes.php?id_caixinha=1'
];

$vulnerabilidades_restantes = 0;

foreach ($apis_testadas as $arquivo => $endpoint) {
    echo "🔍 Testando: $arquivo\n";
    
    // Verificar se o arquivo tem a verificação de segurança
    $conteudo = file_get_contents($arquivo);
    
    if (strpos($conteudo, 'VERIFICAÇÃO DE SEGURANÇA - OBRIGATÓRIA') !== false) {
        echo "   ✅ Verificação de segurança encontrada\n";
    } else {
        echo "   ❌ Verificação de segurança NÃO encontrada\n";
        $vulnerabilidades_restantes++;
    }
    
    if (strpos($conteudo, 'operador_id != $_SESSION[\'user_id\']') !== false) {
        echo "   ✅ Verificação de propriedade encontrada\n";
    } else {
        echo "   ❌ Verificação de propriedade NÃO encontrada\n";
        $vulnerabilidades_restantes++;
    }
    
    echo "\n";
}

// Verificar APIs de relatório
$relatorios = [
    'api/caixas/relatorio_excel.php',
    'api/caixas/relatorio_pdf.php'
];

foreach ($relatorios as $arquivo) {
    echo "🔍 Testando: $arquivo\n";
    
    $conteudo = file_get_contents($arquivo);
    
    if (strpos($conteudo, 'VERIFICAÇÃO DE SEGURANÇA - OBRIGATÓRIA') !== false) {
        echo "   ✅ Verificação de segurança encontrada\n";
    } else {
        echo "   ❌ Verificação de segurança NÃO encontrada\n";
        $vulnerabilidades_restantes++;
    }
    
    if (strpos($conteudo, 'operador_id != $_SESSION[\'user_id\']') !== false) {
        echo "   ✅ Verificação de propriedade encontrada\n";
    } else {
        echo "   ❌ Verificação de propriedade NÃO encontrada\n";
        $vulnerabilidades_restantes++;
    }
    
    echo "\n";
}

// Relatório final
echo str_repeat("=", 50) . "\n";
echo "📋 RELATÓRIO DE TESTE DE SEGURANÇA\n";
echo str_repeat("=", 50) . "\n\n";

if ($vulnerabilidades_restantes == 0) {
    echo "🎯 STATUS: ✅ TODAS AS VULNERABILIDADES CORRIGIDAS\n";
    echo "   ✅ Sistema seguro para uso em produção\n";
} else {
    echo "🎯 STATUS: ⚠️  VULNERABILIDADES RESTANTES\n";
    echo "   ❌ $vulnerabilidades_restantes vulnerabilidades ainda precisam ser corrigidas\n";
}

echo "\n🧠 INSTRUÇÕES PARA IA:\n";
if ($vulnerabilidades_restantes == 0) {
    echo "1. ✅ Sistema está seguro\n";
    echo "2. ✅ Todas as APIs têm verificação de propriedade\n";
    echo "3. ✅ Usuários só acessam seus próprios dados\n";
} else {
    echo "1. ❌ Corrigir vulnerabilidades restantes\n";
    echo "2. ❌ Implementar verificação de propriedade\n";
    echo "3. ❌ Testar novamente após correções\n";
}

echo "\n" . str_repeat("=", 50) . "\n";
echo "🔒 TESTE CONCLUÍDO\n";
echo str_repeat("=", 50) . "\n";

$conn->close();
?> 