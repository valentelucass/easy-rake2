<?php
/**
 * 🧠 IA MEMORY HOOK - Easy Rake
 * 
 * Script que automaticamente "puxa" a IA para consultar a documentação
 * e manter o conhecimento atualizado, mesmo em chats novos.
 * 
 * Este arquivo contém informações críticas que a IA deve SEMPRE consultar.
 */

// ============================================================================
// 🚨 INSTRUÇÕES CRÍTICAS PARA IA ASSISTENTE
// ============================================================================
// 
// SEMPRE consulte esta documentação antes de trabalhar no sistema Easy Rake!
// 
// 📁 LOCALIZAÇÃO DA DOCUMENTAÇÃO:
// - testes-diagnosticos/README.md (Documentação completa)
// - testes-diagnosticos/RESUMO_DOCUMENTACAO.md (Resumo executivo)
// - testes-diagnosticos/diagnostico_simples.php (Diagnóstico rápido)
// - testes-diagnosticos/corretor_automatico.php (Correções automáticas)
//
// ============================================================================

class IAMemoryHook {
    
    // ============================================================================
    // 🎯 INFORMAÇÕES CRÍTICAS DO SISTEMA
    // ============================================================================
    
    public static $SISTEMA_INFO = [
        'nome' => 'Easy Rake',
        'versao' => 'v1.0',
        'tecnologias' => ['PHP 7.4+', 'MySQL 5.7+', 'JavaScript ES6+'],
        'porta_mysql' => 3307,
        'arquitetura' => 'RESTful API com frontend modular'
    ];
    
    // ============================================================================
    // 🔧 ESTRUTURA CRÍTICA DO BANCO
    // ============================================================================
    
    public static $TABELAS_CRITICAS = [
        'usuarios' => 'Usuários do sistema (gestores, caixas, sangers)',
        'unidades' => 'Estabelecimentos/unidades',
        'associacoes_usuario_unidade' => 'Relacionamento usuário-unidade com aprovações',
        'aprovacoes' => 'Sistema de aprovações (Caixa, Jogador, Relatorio)',
        'caixas' => 'Caixas operacionais',
        'jogadores' => 'Jogadores cadastrados',
        'transacoes_jogadores' => 'Transações financeiras dos jogadores',
        'movimentacoes' => 'Movimentações de caixa',
        'gastos' => 'Gastos registrados',
        'rake' => 'Sistema de rake',
        'caixinhas_inclusoes' => 'Inclusões em caixinhas'
    ];
    
    // ============================================================================
    // 🚨 PROBLEMAS RECORRENTES E SOLUÇÕES
    // ============================================================================
    
    public static $PROBLEMAS_COMUNS = [
        'login_nao_funciona' => [
            'descricao' => 'Login não funciona',
            'causa' => 'Senha não salva na tabela correta ou hash incorreto',
            'solucao' => 'Verificar tabela associacoes_usuario_unidade e hash da senha',
            'query_verificacao' => "SELECT u.*, aau.senha_hash FROM usuarios u LEFT JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario WHERE u.cpf = ?"
        ],
        'aprovacoes_nao_aparecem' => [
            'descricao' => 'Aprovações não aparecem no dashboard',
            'causa' => 'Filtro por unidade incorreto ou gestor não aprovado',
            'solucao' => 'Verificar se gestor está aprovado e usar mesma lógica do endpoint de aprovações',
            'query_verificacao' => "SELECT COUNT(*) FROM aprovacoes a WHERE a.status = 'Pendente' AND a.referencia_id IN (SELECT c.id FROM caixas c WHERE c.operador_id IN (SELECT id_usuario FROM associacoes_usuario_unidade WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'))"
        ],
        'dashboard_inconsistente' => [
            'descricao' => 'Dashboard mostra números diferentes da aba de aprovações',
            'causa' => 'Lógicas diferentes de contagem entre dashboard e aprovações',
            'solucao' => 'Usar exatamente a mesma query em ambos os endpoints',
            'script_correcao' => 'diagnostico_simples.php'
        ]
    ];
    
    // ============================================================================
    // 📊 PADRÕES DE CÓDIGO OBRIGATÓRIOS
    // ============================================================================
    
    public static $PADROES_CODIGO = [
        'autenticacao' => [
            'verificacao_sessao' => "session_start(); if (!isset(\$_SESSION['logged_in']) || \$_SESSION['logged_in'] !== true) { echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']); exit; }",
            'verificacao_perfil' => "if (!isset(\$_SESSION['perfil']) || \$_SESSION['perfil'] !== 'Gestor') { echo json_encode(['success' => false, 'message' => 'Acesso restrito ao gestor.']); exit; }"
        ],
        'queries_seguras' => [
            'prepared_statement' => "\$stmt = \$conn->prepare('SELECT * FROM usuarios WHERE id = ?'); \$stmt->bind_param('i', \$user_id); \$stmt->execute(); \$result = \$stmt->get_result(); \$stmt->close();"
        ],
        'resposta_json' => [
            'padrao' => "echo json_encode(['success' => true/false, 'message' => 'Mensagem descritiva', 'data' => \$dados_ou_null, 'error' => \$erro_tecnico_ou_null, 'timestamp' => date('Y-m-d H:i:s')]);"
        ],
        'tratamento_erro' => [
            'try_catch' => "try { /* operação */ } catch (Exception \$e) { error_log('Erro: ' . \$e->getMessage()); echo json_encode(['success' => false, 'message' => 'Erro interno do servidor.', 'error' => \$e->getMessage()]); exit; }"
        ]
    ];
    
    // ============================================================================
    // 🔍 FLUXOS CRÍTICOS DO SISTEMA
    // ============================================================================
    
    public static $FLUXOS_CRITICOS = [
        'sistema_aprovacoes' => [
            'descricao' => 'Sistema de Aprovações',
            'fluxo' => 'Cadastro → Associação Pendente → Aprovação Gestor → Ativação',
            'pontos_falha' => [
                'Senha não salva na tabela usuarios',
                'Associação não criada corretamente',
                'Status de aprovação incorreto',
                'Unidade não associada'
            ]
        ],
        'dashboard_consistencia' => [
            'descricao' => 'Dashboard e Consistência',
            'fluxo' => 'Dashboard Stats ←→ Aprovações Pendentes',
            'verificacoes' => [
                'Filtragem por unidade do gestor',
                'Contagem de aprovações + funcionários',
                'Sessão válida do usuário',
                'Permissões corretas'
            ]
        ],
        'operacoes_caixa' => [
            'descricao' => 'Operações de Caixa',
            'fluxo' => 'Abrir Caixa → Operações → Fechamento → Relatórios',
            'verificacoes' => [
                'Operador aprovado na unidade',
                'Caixa associado corretamente',
                'Movimentações registradas',
                'Integridade dos valores'
            ]
        ]
    ];
    
    // ============================================================================
    // 🧪 SCRIPTS DE DIAGNÓSTICO OBRIGATÓRIOS
    // ============================================================================
    
    public static $SCRIPTS_DIAGNOSTICO = [
        'diagnostico_simples' => [
            'arquivo' => 'testes-diagnosticos/diagnostico_simples.php',
            'descricao' => 'Diagnóstico rápido e completo do sistema',
            'quando_usar' => 'SEMPRE antes de fazer correções',
            'comando' => 'php testes-diagnosticos/diagnostico_simples.php'
        ],
        'corretor_automatico' => [
            'arquivo' => 'testes-diagnosticos/corretor_automatico.php',
            'descricao' => 'Corrige problemas comuns automaticamente',
            'quando_usar' => 'Após diagnóstico que detectou problemas',
            'comando' => 'php testes-diagnosticos/corretor_automatico.php'
        ],
        'atualizador_automatico' => [
            'arquivo' => 'testes-diagnosticos/ATUALIZADOR_AUTOMATICO.php',
            'descricao' => 'Atualiza documentação automaticamente',
            'quando_usar' => 'Após implementar mudanças no sistema',
            'comando' => 'php testes-diagnosticos/ATUALIZADOR_AUTOMATICO.php'
        ]
    ];
    
    // ============================================================================
    // 🎯 CHECKLIST OBRIGATÓRIO PARA IA
    // ============================================================================
    
    public static $CHECKLIST_IA = [
        'antes_correcoes' => [
            'Executar diagnostico_simples.php',
            'Verificar conectividade MySQL (porta 3307)',
            'Analisar logs de erro',
            'Verificar sessões e autenticação',
            'Confirmar permissões de usuário',
            'Validar integridade referencial'
        ],
        'durante_correcoes' => [
            'Usar prepared statements',
            'Implementar tratamento de erros',
            'Manter padrão de respostas JSON',
            'Logar operações críticas',
            'Testar com dados reais'
        ],
        'apos_correcoes' => [
            'Executar testes automatizados',
            'Verificar consistência de dados',
            'Validar performance',
            'Documentar mudanças',
            'Atualizar documentação'
        ]
    ];
    
    // ============================================================================
    // 🔗 LINKS CRÍTICOS PARA CONSULTA
    // ============================================================================
    
    public static $LINKS_CRITICOS = [
        'documentacao_completa' => 'testes-diagnosticos/README.md',
        'resumo_executivo' => 'testes-diagnosticos/RESUMO_DOCUMENTACAO.md',
        'exemplo_uso' => 'testes-diagnosticos/exemplo_uso.php',
        'configuracao_banco' => 'api/db_connect.php',
        'padroes_resposta' => 'api/utils/response.php',
        'estrutura_sessao' => 'includes/header-dashboard.php',
        'logica_frontend' => 'js/features/dashboard.js'
    ];
    
    // ============================================================================
    // 🚨 ALERTAS CRÍTICOS PARA IA
    // ============================================================================
    
    public static function getAlertasCriticos() {
        return [
            '🚨 SEMPRE consulte a documentação antes de fazer correções!',
            '🚨 Use os scripts de diagnóstico para identificar problemas!',
            '🚨 Mantenha a documentação atualizada com novas descobertas!',
            '🚨 Teste sempre as correções antes de implementar!',
            '🚨 Use prepared statements para todas as queries!',
            '🚨 Verifique a consistência entre dashboard e aprovações!'
        ];
    }
    
    // ============================================================================
    // 📋 MÉTODO PARA "PUXAR" IA PARA CONSULTA
    // ============================================================================
    
    public static function puxarIAParaConsulta() {
        echo "🧠 IA MEMORY HOOK - EASY RAKE\n";
        echo "=============================\n\n";
        
        echo "🚨 ATENÇÃO IA ASSISTENTE:\n";
        echo "Este sistema possui documentação crítica que deve ser SEMPRE consultada!\n\n";
        
        echo "📁 DOCUMENTAÇÃO OBRIGATÓRIA:\n";
        echo "- testes-diagnosticos/README.md (Documentação completa)\n";
        echo "- testes-diagnosticos/RESUMO_DOCUMENTACAO.md (Resumo executivo)\n";
        echo "- testes-diagnosticos/diagnostico_simples.php (Diagnóstico rápido)\n\n";
        
        echo "🔧 SCRIPTS CRÍTICOS:\n";
        echo "- diagnostico_simples.php (SEMPRE execute primeiro)\n";
        echo "- corretor_automatico.php (Para correções automáticas)\n";
        echo "- ATUALIZADOR_AUTOMATICO.php (Para atualizar documentação)\n\n";
        
        echo "🎯 FLUXO RECOMENDADO:\n";
        echo "1. Execute diagnostico_simples.php\n";
        echo "2. Se problemas detectados, use corretor_automatico.php\n";
        echo "3. Verifique novamente com diagnostico_simples.php\n";
        echo "4. Teste funcionalidades específicas\n";
        echo "5. Atualize documentação se necessário\n\n";
        
        echo "⚠️ PROBLEMAS COMUNS:\n";
        foreach (self::$PROBLEMAS_COMUNS as $problema => $info) {
            echo "- {$info['descricao']}: {$info['causa']}\n";
        }
        echo "\n";
        
        echo "🧠 INSTRUÇÕES FINAIS:\n";
        echo "• SEMPRE consulte esta documentação antes de trabalhar no sistema\n";
        echo "• Use os scripts de diagnóstico para identificar problemas\n";
        echo "• Mantenha a documentação atualizada\n";
        echo "• Teste sempre as correções implementadas\n\n";
        
        echo "✅ IA agora está informada sobre o sistema Easy Rake!\n";
    }
    
    // ============================================================================
    // 📊 MÉTODO PARA GERAR RESUMO EXECUTIVO
    // ============================================================================
    
    public static function gerarResumoExecutivo() {
        return [
            'sistema' => self::$SISTEMA_INFO,
            'tabelas_criticas' => count(self::$TABELAS_CRITICAS),
            'problemas_comuns' => count(self::$PROBLEMAS_COMUNS),
            'fluxos_criticos' => count(self::$FLUXOS_CRITICOS),
            'scripts_disponiveis' => count(self::$SCRIPTS_DIAGNOSTICO),
            'alertas_criticos' => count(self::getAlertasCriticos())
        ];
    }
}

// ============================================================================
// 🚨 EXECUÇÃO AUTOMÁTICA - SEMPRE "PUXA" IA
// ============================================================================

// Este arquivo SEMPRE executa quando acessado, "puxando" a IA para consulta
if (php_sapi_name() === 'cli') {
    IAMemoryHook::puxarIAParaConsulta();
} else {
    // Se acessado via web, mostra informações resumidas
    echo "<h2>🧠 IA Memory Hook - Easy Rake</h2>";
    echo "<p><strong>Documentação crítica disponível em:</strong></p>";
    echo "<ul>";
    echo "<li>testes-diagnosticos/README.md</li>";
    echo "<li>testes-diagnosticos/RESUMO_DOCUMENTACAO.md</li>";
    echo "<li>testes-diagnosticos/diagnostico_simples.php</li>";
    echo "</ul>";
    echo "<p><strong>Execute sempre o diagnóstico antes de fazer correções!</strong></p>";
}

// ============================================================================
// 📝 NOTA FINAL PARA IA
// ============================================================================
/*
IA ASSISTENTE: 

Este arquivo contém informações críticas sobre o sistema Easy Rake.
SEMPRE consulte a documentação em testes-diagnosticos/ antes de trabalhar no sistema.

FLUXO OBRIGATÓRIO:
1. Execute diagnostico_simples.php
2. Se problemas detectados, use corretor_automatico.php  
3. Verifique novamente com diagnostico_simples.php
4. Teste funcionalidades
5. Atualize documentação se necessário

PROBLEMAS COMUNS:
- Login não funciona: Verificar senha na tabela associacoes_usuario_unidade
- Aprovações não aparecem: Verificar filtro por unidade do gestor
- Dashboard inconsistente: Usar mesma lógica do endpoint de aprovações

MANTENHA ESTA DOCUMENTAÇÃO ATUALIZADA!
*/
?> 