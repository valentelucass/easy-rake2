<?php
/**
 * 🔧 CORRIGIR CAIXAS MÚLTIPLOS - Easy Rake
 * 
 * Script para corrigir operadores com múltiplos caixas abertos simultaneamente.
 * Mantém apenas o caixa mais recente e fecha os demais.
 */

require_once __DIR__ . '/../api/db_connect.php';

echo "🔧 CORRIGIR CAIXAS MÚLTIPLOS - EASY RAKE\n";
echo "========================================\n\n";

// Verificar conexão
if (!isset($conn) || $conn->connect_error) {
    echo "❌ ERRO: Não foi possível conectar ao banco de dados\n";
    exit;
}

echo "✅ Conexão MySQL OK (Porta 3307)\n\n";

// 1. Identificar operadores com múltiplos caixas abertos
echo "1. 🔍 IDENTIFICANDO OPERADORES COM MÚLTIPLOS CAIXAS...\n";

$sql = "SELECT operador_id, COUNT(*) as total_abertos, 
               GROUP_CONCAT(id ORDER BY data_abertura DESC) as ids_caixas,
               GROUP_CONCAT(data_abertura ORDER BY data_abertura DESC) as datas_abertura
        FROM caixas 
        WHERE status = 'Aberto' 
        GROUP BY operador_id 
        HAVING COUNT(*) > 1
        ORDER BY total_abertos DESC";

$result = $conn->query($sql);

if (!$result) {
    echo "   ❌ Erro ao consultar caixas múltiplos: " . $conn->error . "\n";
    exit;
}

$operadores_problema = [];
while ($row = $result->fetch_assoc()) {
    $operadores_problema[] = $row;
}

if (empty($operadores_problema)) {
    echo "   ✅ Nenhum operador com múltiplos caixas encontrado!\n";
    echo "   ✅ Sistema está correto.\n\n";
} else {
    echo "   ⚠️  Encontrados " . count($operadores_problema) . " operadores com múltiplos caixas:\n\n";
    
    foreach ($operadores_problema as $operador) {
        $operador_id = $operador['operador_id'];
        $total_abertos = $operador['total_abertos'];
        $ids_caixas = explode(',', $operador['ids_caixas']);
        $datas_abertura = explode(',', $operador['datas_abertura']);
        
        // Buscar nome do operador
        $stmt = $conn->prepare("SELECT nome FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $operador_id);
        $stmt->execute();
        $nome_operador = $stmt->get_result()->fetch_assoc()['nome'] ?? "ID: $operador_id";
        $stmt->close();
        
        echo "   👤 $nome_operador (ID: $operador_id):\n";
        echo "      📊 Total de caixas abertos: $total_abertos\n";
        
        for ($i = 0; $i < count($ids_caixas); $i++) {
            $status_icon = $i == 0 ? "🟢" : "🔴";
            $status_text = $i == 0 ? "MANTER" : "FECHAR";
            echo "      $status_icon Caixa ID: {$ids_caixas[$i]} - {$datas_abertura[$i]} ($status_text)\n";
        }
        echo "\n";
    }
    
    // 2. Perguntar se deve corrigir
    echo "2. 🔧 CORREÇÃO AUTOMÁTICA\n";
    echo "   Esta correção irá:\n";
    echo "   ✅ Manter apenas o caixa mais recente de cada operador\n";
    echo "   🔴 Fechar automaticamente os caixas mais antigos\n";
    echo "   📝 Registrar observação sobre a correção\n\n";
    
    echo "   🤖 Executando correção automática...\n\n";
    
    // 3. Executar correção
    $caixas_corrigidos = 0;
    $erros = 0;
    
    foreach ($operadores_problema as $operador) {
        $operador_id = $operador['operador_id'];
        $ids_caixas = explode(',', $operador['ids_caixas']);
        
        // O primeiro ID é o mais recente (será mantido)
        $caixa_manter = $ids_caixas[0];
        $caixas_fechar = array_slice($ids_caixas, 1);
        
        // Buscar nome do operador
        $stmt = $conn->prepare("SELECT nome FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $operador_id);
        $stmt->execute();
        $nome_operador = $stmt->get_result()->fetch_assoc()['nome'] ?? "ID: $operador_id";
        $stmt->close();
        
        echo "   🔧 Corrigindo $nome_operador:\n";
        echo "      ✅ Mantendo caixa ID: $caixa_manter\n";
        
        // Fechar caixas antigos
        foreach ($caixas_fechar as $caixa_id) {
            $observacoes = "Caixa fechado automaticamente pelo sistema de correção. Operador tinha múltiplos caixas abertos.";
            
            $stmt = $conn->prepare("UPDATE caixas SET status = 'Fechado', data_fechamento = NOW(), observacoes = CONCAT(COALESCE(observacoes, ''), ' | ', ?) WHERE id = ? AND status = 'Aberto'");
            $stmt->bind_param("si", $observacoes, $caixa_id);
            
            if ($stmt->execute() && $stmt->affected_rows > 0) {
                echo "      🔴 Fechado caixa ID: $caixa_id\n";
                $caixas_corrigidos++;
            } else {
                echo "      ❌ Erro ao fechar caixa ID: $caixa_id\n";
                $erros++;
            }
            $stmt->close();
        }
        echo "\n";
    }
    
    // 4. Verificar resultado
    echo "3. 📊 RESULTADO DA CORREÇÃO\n";
    echo "   ✅ Caixas corrigidos: $caixas_corrigidos\n";
    if ($erros > 0) {
        echo "   ❌ Erros: $erros\n";
    }
    echo "\n";
    
    // 5. Verificar se a correção funcionou
    echo "4. 🔍 VERIFICANDO SE A CORREÇÃO FUNCIONOU...\n";
    
    $sql_verificacao = "SELECT operador_id, COUNT(*) as total_abertos
                        FROM caixas 
                        WHERE status = 'Aberto' 
                        GROUP BY operador_id 
                        HAVING COUNT(*) > 1";
    
    $result_verificacao = $conn->query($sql_verificacao);
    
    if ($result_verificacao->num_rows == 0) {
        echo "   ✅ SUCESSO! Nenhum operador tem múltiplos caixas abertos.\n";
    } else {
        echo "   ⚠️  ATENÇÃO: Ainda existem operadores com múltiplos caixas!\n";
        while ($row = $result_verificacao->fetch_assoc()) {
            echo "      - Operador ID: {$row['operador_id']} - {$row['total_abertos']} caixas\n";
        }
    }
    echo "\n";
}

// 6. Relatório final
echo str_repeat("=", 50) . "\n";
echo "📋 RELATÓRIO FINAL\n";
echo str_repeat("=", 50) . "\n\n";

if (empty($operadores_problema)) {
    echo "🎯 STATUS: ✅ SISTEMA CORRETO\n";
    echo "   Nenhuma correção necessária.\n";
} else {
    echo "🎯 STATUS: ✅ CORREÇÃO CONCLUÍDA\n";
    echo "   Operadores corrigidos: " . count($operadores_problema) . "\n";
    echo "   Caixas fechados: $caixas_corrigidos\n";
    if ($erros > 0) {
        echo "   Erros: $erros\n";
    }
}

echo "\n🧠 INSTRUÇÕES PARA IA:\n";
echo "1. Execute este script sempre que houver inconsistências de caixas\n";
echo "2. Verifique se o dashboard agora mostra números corretos\n";
echo "3. Teste a funcionalidade de abrir caixa para confirmar validação\n";

echo "\n" . str_repeat("=", 50) . "\n";
echo "✅ CORREÇÃO CONCLUÍDA\n";
echo str_repeat("=", 50) . "\n";

$conn->close();
?> 