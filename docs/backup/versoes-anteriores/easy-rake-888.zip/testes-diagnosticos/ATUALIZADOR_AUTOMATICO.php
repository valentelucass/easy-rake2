<?php
/**
 * 🤖 ATUALIZADOR AUTOMÁTICO DE DOCUMENTAÇÃO - Easy Rake
 * 
 * Script que monitora mudanças no sistema e atualiza automaticamente
 * a documentação para manter a IA sempre informada e eficaz.
 * 
 * SEMPRE execute este script após implementar mudanças no sistema.
 */

require_once __DIR__ . '/../api/db_connect.php';

echo "🤖 ATUALIZADOR AUTOMÁTICO DE DOCUMENTAÇÃO - EASY RAKE\n";
echo "====================================================\n\n";

class AtualizadorDocumentacao {
    private $conn;
    private $mudancas = [];
    private $novos_padroes = [];
    private $problemas_detectados = [];
    private $timestamp_atualizacao;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->timestamp_atualizacao = date('Y-m-d H:i:s');
    }
    
    public function executarAtualizacao() {
        echo "🔍 INICIANDO ATUALIZAÇÃO AUTOMÁTICA DA DOCUMENTAÇÃO...\n\n";
        
        $this->analisarMudancasSistema();
        $this->detectarNovosPadroes();
        $this->identificarProblemasRecorrentes();
        $this->atualizarREADME();
        $this->criarResumoExecutivo();
        $this->gerarRelatorioAtualizacao();
    }
    
    private function analisarMudancasSistema() {
        echo "1. 🔍 ANALISANDO MUDANÇAS NO SISTEMA...\n";
        
        // Verificar novas tabelas
        $tabelas_atuais = $this->obterTabelasAtuais();
        $tabelas_documentadas = $this->obterTabelasDocumentadas();
        
        $novas_tabelas = array_diff($tabelas_atuais, $tabelas_documentadas);
        if (!empty($novas_tabelas)) {
            echo "   📊 Novas tabelas detectadas: " . implode(', ', $novas_tabelas) . "\n";
            $this->mudancas['novas_tabelas'] = $novas_tabelas;
        }
        
        // Verificar mudanças na estrutura de usuários
        $this->analisarEstruturaUsuarios();
        
        // Verificar novos endpoints
        $this->analisarEndpoints();
        
        // Verificar mudanças no sistema de aprovações
        $this->analisarSistemaAprovacoes();
        
        echo "   ✅ Análise de mudanças concluída\n\n";
    }
    
    private function obterTabelasAtuais() {
        $tabelas = [];
        $result = $this->conn->query("SHOW TABLES");
        while ($row = $result->fetch_array()) {
            $tabelas[] = $row[0];
        }
        return $tabelas;
    }
    
    private function obterTabelasDocumentadas() {
        // Tabelas já documentadas no README
        return [
            'usuarios', 'unidades', 'associacoes_usuario_unidade', 
            'aprovacoes', 'caixas', 'jogadores', 'transacoes_jogadores',
            'movimentacoes', 'gastos', 'rake', 'caixinhas_inclusoes'
        ];
    }
    
    private function analisarEstruturaUsuarios() {
        echo "   👥 Analisando estrutura de usuários...\n";
        
        // Verificar novos tipos de usuário
        $result = $this->conn->query("SELECT DISTINCT tipo_usuario FROM usuarios");
        $tipos_atuais = [];
        while ($row = $result->fetch_assoc()) {
            $tipos_atuais[] = $row['tipo_usuario'];
        }
        
        $tipos_documentados = ['gestor', 'caixa', 'sanger'];
        $novos_tipos = array_diff($tipos_atuais, $tipos_documentados);
        
        if (!empty($novos_tipos)) {
            echo "      🆕 Novos tipos de usuário: " . implode(', ', $novos_tipos) . "\n";
            $this->mudancas['novos_tipos_usuario'] = $novos_tipos;
        }
    }
    
    private function analisarEndpoints() {
        echo "   🔗 Analisando endpoints da API...\n";
        
        $endpoints_atuais = $this->obterEndpointsAtuais();
        $endpoints_documentados = $this->obterEndpointsDocumentados();
        
        $novos_endpoints = array_diff($endpoints_atuais, $endpoints_documentados);
        if (!empty($novos_endpoints)) {
            echo "      🆕 Novos endpoints: " . implode(', ', $novos_endpoints) . "\n";
            $this->mudancas['novos_endpoints'] = $novos_endpoints;
        }
    }
    
    private function obterEndpointsAtuais() {
        $endpoints = [];
        $api_dir = __DIR__ . '/../api';
        
        if (is_dir($api_dir)) {
            $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($api_dir));
            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getExtension() === 'php') {
                    $relative_path = str_replace($api_dir . '/', '', $file->getPathname());
                    $endpoints[] = $relative_path;
                }
            }
        }
        
        return $endpoints;
    }
    
    private function obterEndpointsDocumentados() {
        return [
            'auth/login.php', 'auth/logout.php',
            'dashboard/get_stats.php',
            'aprovacoes_listar_pendentes.php', 'aprovacoes_listar_historico.php',
            'caixas/abrir_caixa.php', 'caixas/encerrar_caixa.php',
            'jogadores/registrar_jogador.php', 'jogadores/buscar_jogadores.php'
        ];
    }
    
    private function analisarSistemaAprovacoes() {
        echo "   ✅ Analisando sistema de aprovações...\n";
        
        // Verificar novos tipos de aprovação
        $result = $this->conn->query("SELECT DISTINCT tipo FROM aprovacoes");
        $tipos_atuais = [];
        while ($row = $result->fetch_assoc()) {
            $tipos_atuais[] = $row['tipo'];
        }
        
        $tipos_documentados = ['Caixa', 'Jogador', 'Relatorio'];
        $novos_tipos = array_diff($tipos_atuais, $tipos_documentados);
        
        if (!empty($novos_tipos)) {
            echo "      🆕 Novos tipos de aprovação: " . implode(', ', $novos_tipos) . "\n";
            $this->mudancas['novos_tipos_aprovacao'] = $novos_tipos;
        }
    }
    
    private function detectarNovosPadroes() {
        echo "2. 🧠 DETECTANDO NOVOS PADRÕES...\n";
        
        // Analisar padrões de resposta JSON
        $this->analisarPadroesJSON();
        
        // Analisar padrões de autenticação
        $this->analisarPadroesAutenticacao();
        
        // Analisar padrões de queries
        $this->analisarPadroesQueries();
        
        echo "   ✅ Detecção de padrões concluída\n\n";
    }
    
    private function analisarPadroesJSON() {
        echo "   📄 Analisando padrões de resposta JSON...\n";
        
        // Verificar se há novos campos nas respostas
        $campos_comuns = ['success', 'message', 'data', 'error', 'timestamp'];
        
        // Simular análise de respostas reais
        $respostas_analisadas = [
            'login' => ['success', 'message', 'user_data', 'token'],
            'dashboard' => ['success', 'data', 'stats', 'timestamp'],
            'aprovacoes' => ['success', 'data', 'total', 'filtros']
        ];
        
        foreach ($respostas_analisadas as $endpoint => $campos) {
            $novos_campos = array_diff($campos, $campos_comuns);
            if (!empty($novos_campos)) {
                echo "      🆕 Novos campos em $endpoint: " . implode(', ', $novos_campos) . "\n";
                $this->novos_padroes['json_' . $endpoint] = $novos_campos;
            }
        }
    }
    
    private function analisarPadroesAutenticacao() {
        echo "   🔐 Analisando padrões de autenticação...\n";
        
        // Verificar novos métodos de autenticação
        $metodos_atuais = ['session', 'token', 'api_key'];
        $metodos_detectados = [];
        
        // Simular detecção de métodos
        if (file_exists(__DIR__ . '/../api/auth/login.php')) {
            $metodos_detectados[] = 'session';
        }
        
        if (file_exists(__DIR__ . '/../api/auth/token.php')) {
            $metodos_detectados[] = 'token';
        }
        
        $novos_metodos = array_diff($metodos_detectados, ['session']);
        if (!empty($novos_metodos)) {
            echo "      🆕 Novos métodos de autenticação: " . implode(', ', $novos_metodos) . "\n";
            $this->novos_padroes['autenticacao'] = $novos_metodos;
        }
    }
    
    private function analisarPadroesQueries() {
        echo "   🔍 Analisando padrões de queries...\n";
        
        // Verificar uso de prepared statements
        $arquivos_php = $this->obterArquivosPHP();
        $prepared_statements = 0;
        $queries_diretas = 0;
        
        foreach ($arquivos_php as $arquivo) {
            $conteudo = file_get_contents($arquivo);
            if (strpos($conteudo, 'prepare(') !== false) {
                $prepared_statements++;
            }
            if (strpos($conteudo, 'query(') !== false) {
                $queries_diretas++;
            }
        }
        
        echo "      📊 Prepared statements: $prepared_statements\n";
        echo "      📊 Queries diretas: $queries_diretas\n";
        
        if ($queries_diretas > $prepared_statements) {
            echo "      ⚠️  Recomendação: Usar mais prepared statements\n";
            $this->problemas_detectados[] = "Muitas queries diretas detectadas";
        }
    }
    
    private function obterArquivosPHP() {
        $arquivos = [];
        $api_dir = __DIR__ . '/../api';
        
        if (is_dir($api_dir)) {
            $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($api_dir));
            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getExtension() === 'php') {
                    $arquivos[] = $file->getPathname();
                }
            }
        }
        
        return $arquivos;
    }
    
    private function identificarProblemasRecorrentes() {
        echo "3. ⚠️  IDENTIFICANDO PROBLEMAS RECORRENTES...\n";
        
        // Verificar erros comuns
        $this->verificarErrosComuns();
        
        // Verificar inconsistências
        $this->verificarInconsistencias();
        
        // Verificar problemas de performance
        $this->verificarProblemasPerformance();
        
        echo "   ✅ Identificação de problemas concluída\n\n";
    }
    
    private function verificarErrosComuns() {
        echo "   🚨 Verificando erros comuns...\n";
        
        // Verificar senhas não hasheadas
        $result = $this->conn->query("SELECT COUNT(*) as total FROM usuarios WHERE LENGTH(senha) < 60");
        $senhas_inseguras = $result->fetch_assoc()['total'];
        
        if ($senhas_inseguras > 0) {
            echo "      ⚠️  $senhas_inseguras senhas não hasheadas\n";
            $this->problemas_detectados[] = "Senhas inseguras: $senhas_inseguras";
        }
        
        // Verificar usuários sem associação
        $result = $this->conn->query("SELECT COUNT(*) as total FROM usuarios u 
                                    LEFT JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario 
                                    WHERE aau.id IS NULL");
        $usuarios_sem_assoc = $result->fetch_assoc()['total'];
        
        if ($usuarios_sem_assoc > 0) {
            echo "      ⚠️  $usuarios_sem_assoc usuários sem associação\n";
            $this->problemas_detectados[] = "Usuários sem associação: $usuarios_sem_assoc";
        }
    }
    
    private function verificarInconsistencias() {
        echo "   🔗 Verificando inconsistências...\n";
        
        // Verificar aprovações órfãs
        $result = $this->conn->query("SELECT COUNT(*) as total FROM aprovacoes a 
                                    LEFT JOIN caixas c ON a.referencia_id = c.id AND a.tipo = 'Caixa'
                                    LEFT JOIN jogadores j ON a.referencia_id = j.id AND a.tipo = 'Jogador'
                                    WHERE a.status = 'Pendente' AND c.id IS NULL AND j.id IS NULL");
        $aprovacoes_orfas = $result->fetch_assoc()['total'];
        
        if ($aprovacoes_orfas > 0) {
            echo "      ⚠️  $aprovacoes_orfas aprovações órfãs\n";
            $this->problemas_detectados[] = "Aprovações órfãs: $aprovacoes_orfas";
        }
    }
    
    private function verificarProblemasPerformance() {
        echo "   ⚡ Verificando problemas de performance...\n";
        
        // Verificar índices
        $tabelas_criticas = ['usuarios', 'aprovacoes', 'caixas'];
        foreach ($tabelas_criticas as $tabela) {
            $result = $this->conn->query("SHOW INDEX FROM $tabela");
            $indices = $result->num_rows;
            
            if ($indices < 3) {
                echo "      ⚠️  Poucos índices na tabela $tabela ($indices)\n";
                $this->problemas_detectados[] = "Poucos índices em $tabela";
            }
        }
    }
    
    private function atualizarREADME() {
        echo "4. 📝 ATUALIZANDO README PRINCIPAL...\n";
        
        $readme_path = __DIR__ . '/README.md';
        $readme_content = file_get_contents($readme_path);
        
        // Adicionar seção de atualizações automáticas
        $secao_atualizacoes = $this->gerarSecaoAtualizacoes();
        
        // Inserir antes da seção de instruções para IA
        $posicao = strpos($readme_content, '## 🧠 INSTRUÇÕES PARA IA ASSISTENTE');
        
        if ($posicao !== false) {
            $novo_conteudo = substr($readme_content, 0, $posicao) . 
                            $secao_atualizacoes . "\n\n" . 
                            substr($readme_content, $posicao);
            
            file_put_contents($readme_path, $novo_conteudo);
            echo "   ✅ README atualizado com novas informações\n";
        } else {
            echo "   ⚠️  Não foi possível localizar seção para inserção\n";
        }
    }
    
    private function gerarSecaoAtualizacoes() {
        $secao = "## 🔄 ATUALIZAÇÕES AUTOMÁTICAS\n\n";
        $secao .= "**Última atualização:** $this->timestamp_atualizacao\n\n";
        
        if (!empty($this->mudancas)) {
            $secao .= "### 📊 MUDANÇAS DETECTADAS:\n\n";
            foreach ($this->mudancas as $tipo => $itens) {
                $secao .= "- **$tipo:** " . implode(', ', $itens) . "\n";
            }
            $secao .= "\n";
        }
        
        if (!empty($this->novos_padroes)) {
            $secao .= "### 🧠 NOVOS PADRÕES IDENTIFICADOS:\n\n";
            foreach ($this->novos_padroes as $tipo => $itens) {
                $secao .= "- **$tipo:** " . implode(', ', $itens) . "\n";
            }
            $secao .= "\n";
        }
        
        if (!empty($this->problemas_detectados)) {
            $secao .= "### ⚠️ PROBLEMAS DETECTADOS:\n\n";
            foreach ($this->problemas_detectados as $problema) {
                $secao .= "- $problema\n";
            }
            $secao .= "\n";
        }
        
        $secao .= "### 🎯 AÇÕES RECOMENDADAS:\n\n";
        if (!empty($this->problemas_detectados)) {
            $secao .= "1. Execute o corretor automático: `php testes-diagnosticos/corretor_automatico.php`\n";
        }
        $secao .= "2. Atualize a documentação com novos padrões descobertos\n";
        $secao .= "3. Teste as funcionalidades afetadas pelas mudanças\n";
        $secao .= "4. Execute o diagnóstico para verificar consistência\n\n";
        
        return $secao;
    }
    
    private function criarResumoExecutivo() {
        echo "5. 📋 CRIANDO RESUMO EXECUTIVO...\n";
        
        $resumo_path = __DIR__ . '/RESUMO_DOCUMENTACAO.md';
        $resumo_content = file_get_contents($resumo_path);
        
        // Adicionar seção de atualizações recentes
        $secao_atualizacoes = $this->gerarSecaoAtualizacoesResumo();
        
        // Inserir no final do arquivo
        $resumo_content .= "\n\n" . $secao_atualizacoes;
        
        file_put_contents($resumo_path, $resumo_content);
        echo "   ✅ Resumo executivo atualizado\n";
    }
    
    private function gerarSecaoAtualizacoesResumo() {
        $secao = "## 🔄 ATUALIZAÇÕES RECENTES\n\n";
        $secao .= "**Data:** $this->timestamp_atualizacao\n\n";
        
        if (!empty($this->mudancas)) {
            $secao .= "### 📊 Mudanças no Sistema:\n";
            foreach ($this->mudancas as $tipo => $itens) {
                $secao .= "- $tipo: " . implode(', ', $itens) . "\n";
            }
            $secao .= "\n";
        }
        
        if (!empty($this->novos_padroes)) {
            $secao .= "### 🧠 Novos Padrões:\n";
            foreach ($this->novos_padroes as $tipo => $itens) {
                $secao .= "- $tipo: " . implode(', ', $itens) . "\n";
            }
            $secao .= "\n";
        }
        
        return $secao;
    }
    
    private function gerarRelatorioAtualizacao() {
        echo "\n" . str_repeat("=", 60) . "\n";
        echo "📋 RELATÓRIO DE ATUALIZAÇÃO AUTOMÁTICA\n";
        echo str_repeat("=", 60) . "\n\n";
        
        echo "🕐 **Data/Hora:** $this->timestamp_atualizacao\n\n";
        
        if (!empty($this->mudancas)) {
            echo "📊 **MUDANÇAS DETECTADAS:**\n";
            foreach ($this->mudancas as $tipo => $itens) {
                echo "   • $tipo: " . implode(', ', $itens) . "\n";
            }
            echo "\n";
        } else {
            echo "✅ **NENHUMA MUDANÇA DETECTADA**\n\n";
        }
        
        if (!empty($this->novos_padroes)) {
            echo "🧠 **NOVOS PADRÕES IDENTIFICADOS:**\n";
            foreach ($this->novos_padroes as $tipo => $itens) {
                echo "   • $tipo: " . implode(', ', $itens) . "\n";
            }
            echo "\n";
        }
        
        if (!empty($this->problemas_detectados)) {
            echo "⚠️ **PROBLEMAS DETECTADOS:**\n";
            foreach ($this->problemas_detectados as $problema) {
                echo "   • $problema\n";
            }
            echo "\n";
        }
        
        echo "🎯 **PRÓXIMOS PASSOS:**\n";
        if (!empty($this->problemas_detectados)) {
            echo "1. Execute o corretor automático\n";
        }
        echo "2. Teste as funcionalidades afetadas\n";
        echo "3. Execute o diagnóstico para verificar consistência\n";
        echo "4. Atualize a documentação conforme necessário\n\n";
        
        echo "🧠 **INSTRUÇÕES PARA IA:**\n";
        echo "• Esta documentação foi atualizada automaticamente\n";
        echo "• Sempre consulte o README.md antes de fazer correções\n";
        echo "• Use os scripts de diagnóstico para validar mudanças\n";
        echo "• Mantenha a documentação atualizada com novas descobertas\n\n";
        
        echo str_repeat("=", 60) . "\n";
        echo "✅ ATUALIZAÇÃO CONCLUÍDA\n";
        echo str_repeat("=", 60) . "\n";
    }
}

// Executar atualização
try {
    $atualizador = new AtualizadorDocumentacao($conn);
    $atualizador->executarAtualizacao();
} catch (Exception $e) {
    echo "❌ ERRO NO ATUALIZADOR: " . $e->getMessage() . "\n";
}

$conn->close();
?> 