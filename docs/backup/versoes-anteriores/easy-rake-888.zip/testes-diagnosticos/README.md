# 🧠 DOCUMENTAÇÃO INTELIGENTE - Easy Rake

> **Para IA Assistente:** Esta documentação contém informações técnicas profundas, códigos de exemplo e padrões que devem ser consultados sempre que trabalhar no sistema Easy Rake.

## 🎯 VISÃO GERAL DO SISTEMA

### Arquitetura Principal
```
easy-rake/
├── api/                    # Backend APIs (RESTful)
│   ├── auth/              # Autenticação e sessões
│   ├── caixas/            # Operações de caixa
│   ├── dashboard/         # Estatísticas e dados do dashboard
│   ├── jogadores/         # Gestão de jogadores
│   ├── aprovacoes/        # Sistema de aprovações
│   ├── relatorios/        # Geração de relatórios
│   └── utils/             # Utilitários e helpers
├── css/                   # Estilos organizados por componentes
├── js/                    # JavaScript modular por funcionalidade
├── includes/              # Componentes PHP reutilizáveis
└── testes-diagnosticos/   # Scripts de teste e diagnóstico
```

### Tecnologias e Padrões
- **Backend:** PHP 7.4+ com MySQL 5.7+
- **Frontend:** HTML5, CSS3, JavaScript ES6+
- **Banco:** MySQL na porta 3307 (XAMPP)
- **Sessões:** PHP Sessions com cookies
- **APIs:** RESTful com JSON responses
- **Segurança:** Password hashing, prepared statements

## 🔧 ESTRUTURA DO BANCO DE DADOS

### Tabelas Principais
```sql
-- Usuários do sistema
usuarios (id, nome, cpf, senha, tipo_usuario, perfil, status, data_cadastro)

-- Unidades/Estabelecimentos
unidades (id, nome, telefone, codigo_acesso, status, data_criacao)

-- Associações usuário-unidade
associacoes_usuario_unidade (id, id_usuario, id_unidade, senha_hash, perfil, status_aprovacao, data_criacao)

-- Sistema de aprovações
aprovacoes (id, tipo, referencia_id, solicitante_id, aprovador_id, status, observacoes, data_solicitacao, data_aprovacao)

-- Caixas operacionais
caixas (id, operador_id, valor_inicial, status, data_abertura, data_fechamento)

-- Jogadores
jogadores (id, nome, cpf, limite_credito, status, data_cadastro)

-- Transações e movimentações
transacoes_jogadores, movimentacoes, gastos, rake, caixinhas_inclusoes
```

### Relacionamentos Críticos
```sql
-- Gestor → Unidade (1:1)
SELECT u.* FROM usuarios u 
INNER JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario 
WHERE aau.perfil = 'Gestor' AND aau.status_aprovacao = 'Aprovado'

-- Operador → Caixas (1:N)
SELECT c.* FROM caixas c 
WHERE c.operador_id IN (
    SELECT id_usuario FROM associacoes_usuario_unidade 
    WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'
)

-- Aprovações por unidade
SELECT a.* FROM aprovacoes a 
WHERE a.referencia_id IN (
    SELECT c.id FROM caixas c 
    WHERE c.operador_id IN (
        SELECT id_usuario FROM associacoes_usuario_unidade 
        WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'
    )
)
```

## 🧪 SCRIPTS DE DIAGNÓSTICO INTELIGENTE

### 1. Verificação de Conectividade
```bash
# Sempre execute primeiro para verificar conectividade
php testes-diagnosticos/check_db.php
```

**O que verifica:**
- Conexão MySQL na porta 3307
- Existência das tabelas principais
- Dados básicos de jogadores
- Integridade das estruturas

### 2. Diagnóstico de Usuários e Funcionários
```bash
# Verifica estado dos usuários e suas associações
php testes-diagnosticos/diagnostico_usuarios_funcionarios.php
```

**Informações críticas:**
- Usuários por tipo (Gestor, Caixa, Sanger)
- Associações com unidades
- Status de aprovação
- Senhas e hashes
- Problemas de integridade

### 3. Verificação de Códigos de Acesso
```bash
# Lista códigos de acesso das unidades
php testes-diagnosticos/diagnostico_codigos_acesso.php
```

**Útil para:**
- Testes de login
- Verificação de permissões
- Debug de autenticação

### 4. Diagnóstico de Relatórios
```bash
# Verifica estrutura para relatórios
php testes-diagnosticos/diagnostico_banco_relatorios.php
```

**Verifica:**
- Tabelas de relatórios
- Dados de exemplo
- Integridade referencial
- Performance das queries

## 🎯 PADRÕES DE CÓDIGO E CORREÇÕES

### Autenticação e Sessões
```php
// SEMPRE verificar sessão antes de qualquer operação
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit;
}

// Verificar perfil para operações específicas
if (!isset($_SESSION['perfil']) || $_SESSION['perfil'] !== 'Gestor') {
    echo json_encode(['success' => false, 'message' => 'Acesso restrito ao gestor.']);
    exit;
}
```

### Queries Seguras
```php
// SEMPRE usar prepared statements
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
```

### Respostas JSON Padronizadas
```php
// Padrão de resposta para todas as APIs
echo json_encode([
    'success' => true/false,
    'message' => 'Mensagem descritiva',
    'data' => $dados_ou_null,
    'error' => $erro_tecnico_ou_null,
    'timestamp' => date('Y-m-d H:i:s')
]);
```

### Tratamento de Erros
```php
try {
    // Operação principal
    $result = $conn->query($sql);
    if (!$result) {
        throw new Exception("Erro na query: " . $conn->error);
    }
} catch (Exception $e) {
    error_log("Erro: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro interno do servidor.',
        'error' => $e->getMessage()
    ]);
    exit;
}
```

## 🔍 FLUXOS CRÍTICOS DO SISTEMA

### 1. Sistema de Aprovações
```
Cadastro → Associação Pendente → Aprovação Gestor → Ativação
```

**Pontos de falha:**
- Senha não salva na tabela `usuarios`
- Associação não criada corretamente
- Status de aprovação incorreto
- Unidade não associada

### 2. Dashboard e Consistência
```
Dashboard Stats ←→ Aprovações Pendentes
```

**Sempre verificar:**
- Filtragem por unidade do gestor
- Contagem de aprovações + funcionários
- Sessão válida do usuário
- Permissões corretas

### 3. Operações de Caixa
```
Abrir Caixa → Operações → Fechamento → Relatórios
```

**Verificações necessárias:**
- Operador aprovado na unidade
- Caixa associado corretamente
- Movimentações registradas
- Integridade dos valores

## 🛠️ CORREÇÕES COMUNS E SOLUÇÕES

### Problema: Login não funciona
```php
// Verificar se senha está na tabela correta
$sql = "SELECT u.*, aau.senha_hash as senha_unidade 
        FROM usuarios u 
        LEFT JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario 
        WHERE u.cpf = ?";
```

### Problema: Aprovações não aparecem
```php
// Verificar filtro por unidade
$sql = "SELECT COUNT(*) FROM aprovacoes a 
        WHERE a.status = 'Pendente' 
        AND a.referencia_id IN (
            SELECT c.id FROM caixas c 
            WHERE c.operador_id IN (
                SELECT id_usuario FROM associacoes_usuario_unidade 
                WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'
            )
        )";
```

### Problema: Dashboard inconsistente
```php
// Sempre usar a mesma lógica do endpoint de aprovações
// Verificar se gestor está aprovado e associado à unidade
```

## 📊 MONITORAMENTO E LOGS

### Logs Importantes
```php
// Sempre logar operações críticas
error_log("Aprovação processada: ID " . $aprovacao_id . " por gestor " . $gestor_id);
error_log("Erro de autenticação: CPF " . $cpf . " - " . $erro);
error_log("Inconsistência detectada: Dashboard=" . $dashboard_count . " vs Aprovacoes=" . $aprovacoes_count);
```

### Métricas de Performance
```php
// Medir tempo de execução
$start_time = microtime(true);
// ... operação ...
$execution_time = microtime(true) - $start_time;
error_log("Query executada em " . round($execution_time * 1000, 2) . "ms");
```

## 🎯 CHECKLIST DE DIAGNÓSTICO

### Antes de qualquer correção:
1. ✅ Executar `check_db.php`
2. ✅ Verificar conectividade MySQL (porta 3307)
3. ✅ Analisar logs de erro
4. ✅ Verificar sessões e autenticação
5. ✅ Confirmar permissões de usuário
6. ✅ Validar integridade referencial

### Durante correções:
1. ✅ Usar prepared statements
2. ✅ Implementar tratamento de erros
3. ✅ Manter padrão de respostas JSON
4. ✅ Logar operações críticas
5. ✅ Testar com dados reais

### Após correções:
1. ✅ Executar testes automatizados
2. ✅ Verificar consistência de dados
3. ✅ Validar performance
4. ✅ Documentar mudanças
5. ✅ Atualizar esta documentação

## 🔗 LINKS ÚTEIS PARA IA

### Arquivos de Referência:
- `api/db_connect.php` - Configuração do banco
- `api/utils/response.php` - Padrões de resposta
- `includes/header-dashboard.php` - Estrutura de sessão
- `js/features/dashboard.js` - Lógica frontend

### Endpoints Críticos:
- `api/auth/login.php` - Autenticação
- `api/dashboard/get_stats.php` - Estatísticas
- `api/aprovacoes_listar_pendentes.php` - Aprovações
- `api/caixas/abrir_caixa.php` - Operações de caixa

### Scripts de Diagnóstico:
- `testes-diagnosticos/check_db.php` - Verificação básica
- `testes-diagnosticos/diagnostico_usuarios_funcionarios.php` - Usuários
- `testes-diagnosticos/teste_sistema_aprovacoes.php` - Testes completos

---

## 🧠 INSTRUÇÕES PARA IA ASSISTENTE

**SEMPRE consulte esta documentação antes de:**
1. Fazer correções no sistema
2. Implementar novas funcionalidades
3. Diagnosticar problemas
4. Otimizar performance
5. Manter consistência de dados

**Use os scripts de diagnóstico para:**
1. Verificar estado atual do sistema
2. Identificar pontos de falha
3. Validar correções implementadas
4. Manter qualidade do código

**Mantenha esta documentação atualizada com:**
1. Novos padrões descobertos
2. Soluções para problemas recorrentes
3. Otimizações implementadas
4. Mudanças na arquitetura

## 🤖 SISTEMA DE "PUXAR" IA AUTOMATICAMENTE

### Arquivos que "Puxam" a IA
- **`IA_MEMORY_HOOK.php`** - Hook de memória que sempre "puxa" IA para consulta
- **`IA_CONFIG.php`** - Configuração que força IA a consultar documentação
- **`ATUALIZADOR_AUTOMATICO.php`** - Atualiza documentação automaticamente

### Como Funciona
1. **Inclusão Automática** - Inclua `IA_CONFIG.php` em scripts principais
2. **Execução Automática** - Scripts executam automaticamente quando acessados
3. **Atualização Automática** - Documentação é atualizada com mudanças detectadas
4. **Consulta Obrigatória** - IA é "puxada" para consultar documentação

### Uso Recomendado
```php
// Incluir em scripts principais para "puxar" IA
require_once 'testes-diagnosticos/IA_CONFIG.php';

// Executar diagnóstico obrigatório
system('php testes-diagnosticos/diagnostico_simples.php');

// Atualizar documentação após mudanças
system('php testes-diagnosticos/ATUALIZADOR_AUTOMATICO.php');
```

### Benefícios
- **IA Sempre Informada** - Mesmo em chats novos
- **Documentação Atualizada** - Automaticamente
- **Padrões Mantidos** - Sempre consultados
- **Problemas Prevenidos** - Diagnóstico obrigatório

---

**Última atualização:** Julho 2025  
**Versão:** Easy Rake v1.0  
**IA Assistant:** Sempre consulte esta documentação para ser mais eficaz e precisa nas correções. 