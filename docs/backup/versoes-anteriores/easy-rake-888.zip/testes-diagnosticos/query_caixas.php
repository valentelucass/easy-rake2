<?php
require_once __DIR__ . '/../api/db_connect.php';

echo "Query direta - Caixas abertos:\n";
$sql = "SELECT c.id, c.operador_id, c.status, u.nome as operador_nome 
        FROM caixas c 
        LEFT JOIN usuarios u ON c.operador_id = u.id 
        WHERE c.status = 'Aberto'";
$result = $conn->query($sql);

if ($result) {
    echo "Total: " . $result->num_rows . " caixas abertos\n";
    while ($row = $result->fetch_assoc()) {
        echo "ID: {$row['id']} - Operador: {$row['operador_nome']} (ID: {$row['operador_id']})\n";
    }
} else {
    echo "Erro: " . $conn->error;
}

$conn->close();
?> 