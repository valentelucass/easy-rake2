<?php
echo "Script funcionando!\n";
echo "Testando conexão...\n";

$conn = new mysqli('localhost', 'root', '36140888', 'easy_rake', 3307);

if ($conn->connect_error) {
    echo "Erro de conexão: " . $conn->connect_error . "\n";
} else {
    echo "Conexão OK!\n";
    
    $result = $conn->query("SELECT COUNT(*) as total FROM caixas WHERE status = 'Aberto'");
    if ($result) {
        $row = $result->fetch_assoc();
        echo "Caixas abertos: " . $row['total'] . "\n";
        
        // Verificar quais caixas estão abertos
        $result2 = $conn->query("SELECT c.id, c.operador_id, u.nome FROM caixas c LEFT JOIN usuarios u ON c.operador_id = u.id WHERE c.status = 'Aberto'");
        while ($caixa = $result2->fetch_assoc()) {
            echo "Caixa ID: {$caixa['id']} - Operador: {$caixa['nome']} (ID: {$caixa['operador_id']})\n";
        }
    } else {
        echo "Erro na query: " . $conn->error . "\n";
    }
    
    $conn->close();
}
?> 