<?php
/**
 * 🔍 INVESTIGAR CAIXAS - Easy Rake
 * 
 * Script específico para investigar inconsistências na tabela de caixas
 * e identificar por que o dashboard mostra números incorretos.
 */

require_once __DIR__ . '/../api/db_connect.php';

echo "🔍 INVESTIGAÇÃO DE CAIXAS - EASY RAKE\n";
echo "====================================\n\n";

// Verificar conexão
if (!isset($conn) || $conn->connect_error) {
    echo "❌ ERRO: Não foi possível conectar ao banco de dados\n";
    exit;
}

echo "✅ Conexão MySQL OK (Porta 3307)\n\n";

// 1. Verificar todos os caixas
echo "1. 📦 VERIFICANDO TODOS OS CAIXAS...\n";
$sql = "SELECT c.id, c.operador_id, c.valor_inicial, c.status, c.data_abertura, c.data_fechamento, 
               u.nome as operador_nome, aau.id_unidade, aau.status_aprovacao
        FROM caixas c 
        LEFT JOIN usuarios u ON c.operador_id = u.id 
        LEFT JOIN associacoes_usuario_unidade aau ON c.operador_id = aau.id_usuario 
        ORDER BY c.id DESC";
$result = $conn->query($sql);

if ($result) {
    echo "   📊 Total de caixas: " . $result->num_rows . "\n\n";
    
    $caixas_abertos = 0;
    $caixas_fechados = 0;
    $caixas_sem_operador = 0;
    $caixas_operador_inativo = 0;
    
    while ($caixa = $result->fetch_assoc()) {
        $status_icon = $caixa['status'] == 'Aberto' ? '🟢' : '🔴';
        $operador_status = $caixa['status_aprovacao'] == 'Aprovado' ? '✅' : '❌';
        
        echo "   $status_icon Caixa ID: {$caixa['id']}\n";
        echo "      📊 Status: {$caixa['status']}\n";
        echo "      👤 Operador: {$caixa['operador_nome']} (ID: {$caixa['operador_id']}) $operador_status\n";
        echo "      💰 Valor inicial: R$ " . number_format($caixa['valor_inicial'], 2, ',', '.') . "\n";
        echo "      📅 Abertura: {$caixa['data_abertura']}\n";
        if ($caixa['data_fechamento']) {
            echo "      📅 Fechamento: {$caixa['data_fechamento']}\n";
        }
        echo "      🏢 Unidade: {$caixa['id_unidade']}\n";
        echo "      ✅ Status operador: {$caixa['status_aprovacao']}\n";
        echo "\n";
        
        // Contadores
        if ($caixa['status'] == 'Aberto') {
            $caixas_abertos++;
        } else {
            $caixas_fechados++;
        }
        
        if (!$caixa['operador_id']) {
            $caixas_sem_operador++;
        }
        
        if ($caixa['status_aprovacao'] != 'Aprovado') {
            $caixas_operador_inativo++;
        }
    }
    
    echo "   📊 RESUMO:\n";
    echo "      🟢 Caixas abertos: $caixas_abertos\n";
    echo "      🔴 Caixas fechados: $caixas_fechados\n";
    echo "      ⚠️  Caixas sem operador: $caixas_sem_operador\n";
    echo "      ⚠️  Caixas com operador inativo: $caixas_operador_inativo\n\n";
} else {
    echo "   ❌ Erro ao consultar caixas: " . $conn->error . "\n\n";
}

// 2. Verificar caixas que deveriam estar fechados
echo "2. 🔍 VERIFICANDO CAIXAS QUE DEVERIAM ESTAR FECHADOS...\n";

// Caixas abertos com operador não aprovado
$sql = "SELECT c.id, c.operador_id, u.nome as operador_nome, aau.status_aprovacao
        FROM caixas c 
        LEFT JOIN usuarios u ON c.operador_id = u.id 
        LEFT JOIN associacoes_usuario_unidade aau ON c.operador_id = aau.id_usuario 
        WHERE c.status = 'Aberto' AND (aau.status_aprovacao != 'Aprovado' OR aau.status_aprovacao IS NULL)";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "   ⚠️  Caixas abertos com operador não aprovado:\n";
    while ($caixa = $result->fetch_assoc()) {
        echo "      - Caixa ID: {$caixa['id']} - Operador: {$caixa['operador_nome']} - Status: {$caixa['status_aprovacao']}\n";
    }
    echo "\n";
} else {
    echo "   ✅ Todos os caixas abertos têm operador aprovado\n\n";
}

// 3. Verificar query do dashboard
echo "3. 📊 VERIFICANDO QUERY DO DASHBOARD...\n";

// Simular query do dashboard para caixas abertos
$sql_dashboard = "SELECT COUNT(*) as total FROM caixas WHERE status = 'Aberto'";
$result = $conn->query($sql_dashboard);
$dashboard_count = $result ? $result->fetch_assoc()['total'] : 0;

echo "   📊 Dashboard mostra: $dashboard_count caixas abertos\n";

// Query mais específica (como deveria ser)
$sql_corrigida = "SELECT COUNT(*) as total FROM caixas c 
                  INNER JOIN associacoes_usuario_unidade aau ON c.operador_id = aau.id_usuario 
                  WHERE c.status = 'Aberto' AND aau.status_aprovacao = 'Aprovado'";
$result = $conn->query($sql_corrigida);
$corrigido_count = $result ? $result->fetch_assoc()['total'] : 0;

echo "   ✅ Contagem corrigida: $corrigido_count caixas abertos (com operador aprovado)\n\n";

// 4. Verificar operadores aprovados
echo "4. 👥 VERIFICANDO OPERADORES APROVADOS...\n";
$sql = "SELECT u.id, u.nome, aau.id_unidade, aau.perfil, aau.status_aprovacao
        FROM usuarios u 
        INNER JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario 
        WHERE aau.perfil != 'Gestor' AND aau.status_aprovacao = 'Aprovado'
        ORDER BY u.nome";
$result = $conn->query($sql);

if ($result) {
    echo "   👥 Operadores aprovados:\n";
    while ($operador = $result->fetch_assoc()) {
        echo "      ✅ {$operador['nome']} (Unidade {$operador['id_unidade']}) - {$operador['perfil']}\n";
    }
    echo "\n";
} else {
    echo "   ❌ Erro ao consultar operadores\n\n";
}

// 5. Sugerir correções
echo "5. 🔧 SUGESTÕES DE CORREÇÃO...\n";

if ($dashboard_count != $corrigido_count) {
    echo "   ⚠️  PROBLEMA IDENTIFICADO:\n";
    echo "      - Dashboard mostra: $dashboard_count caixas abertos\n";
    echo "      - Realidade: $corrigido_count caixas abertos (com operador aprovado)\n";
    echo "      - Diferença: " . ($dashboard_count - $corrigido_count) . " caixas incorretos\n\n";
    
    echo "   🔧 SOLUÇÃO:\n";
    echo "      1. Fechar caixas com operador não aprovado\n";
    echo "      2. Corrigir query do dashboard para filtrar por operador aprovado\n";
    echo "      3. Usar a query corrigida:\n";
    echo "         SELECT COUNT(*) FROM caixas c \n";
    echo "         INNER JOIN associacoes_usuario_unidade aau ON c.operador_id = aau.id_usuario \n";
    echo "         WHERE c.status = 'Aberto' AND aau.status_aprovacao = 'Aprovado'\n\n";
    
    // Oferecer correção automática
    echo "   🤖 CORREÇÃO AUTOMÁTICA DISPONÍVEL:\n";
    echo "      Execute: php testes-diagnosticos/corretor_automatico.php\n\n";
} else {
    echo "   ✅ Dashboard está correto\n\n";
}

// 6. Relatório final
echo str_repeat("=", 50) . "\n";
echo "📋 RELATÓRIO DE INVESTIGAÇÃO\n";
echo str_repeat("=", 50) . "\n\n";

echo "🎯 PROBLEMA IDENTIFICADO:\n";
echo "   Dashboard mostra $dashboard_count caixas abertos\n";
echo "   Mas apenas $corrigido_count têm operador aprovado\n\n";

echo "🔧 AÇÃO RECOMENDADA:\n";
if ($dashboard_count != $corrigido_count) {
    echo "   1. Execute o corretor automático\n";
    echo "   2. Corrija a query do dashboard\n";
    echo "   3. Verifique novamente com este script\n";
} else {
    echo "   ✅ Sistema está correto\n";
}

echo "\n" . str_repeat("=", 50) . "\n";
echo "✅ INVESTIGAÇÃO CONCLUÍDA\n";
echo str_repeat("=", 50) . "\n";

$conn->close();
?> 