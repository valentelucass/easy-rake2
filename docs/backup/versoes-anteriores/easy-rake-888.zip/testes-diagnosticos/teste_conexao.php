<?php
echo "Testando conexão...\n";

try {
    require_once __DIR__ . '/../api/db_connect.php';
    echo "Conexão OK\n";
    
    $result = $conn->query("SELECT COUNT(*) as total FROM caixas WHERE status = 'Aberto'");
    if ($result) {
        $row = $result->fetch_assoc();
        echo "Caixas abertos: " . $row['total'] . "\n";
    } else {
        echo "Erro na query: " . $conn->error . "\n";
    }
    
    $conn->close();
} catch (Exception $e) {
    echo "Erro: " . $e->getMessage() . "\n";
}
?> 