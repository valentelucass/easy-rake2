<?php
require_once 'api/db_connect.php';

header('Content-Type: text/html; charset=utf-8');
echo '<h2>Diagnóstico de Usuários Caixa/Sanger</h2>';
$cpfs = ['11122233344', '22233344455', '11122233345', '22233344456'];

try {
    $in = implode(",", array_fill(0, count($cpfs), '?'));
    $stmt = $conn->prepare("SELECT id, nome, cpf, senha, tipo_usuario, status FROM usuarios WHERE cpf IN ($in)");
    $stmt->bind_param(str_repeat('s', count($cpfs)), ...$cpfs);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        echo '<p>Nenhum usuário encontrado.</p>';
    } else {
        echo '<table border="1" cellpadding="6" style="border-collapse:collapse;">';
        echo '<tr><th>ID</th><th>Nome</th><th>CPF</th><th>Senha (hash)</th><th>Tipo</th><th>Status</th></tr>';
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['id']) . '</td>';
            echo '<td>' . htmlspecialchars($row['nome']) . '</td>';
            echo '<td>' . htmlspecialchars($row['cpf']) . '</td>';
            echo '<td>' . (empty($row['senha']) ? '<span style="color:red">(vazio)</span>' : htmlspecialchars($row['senha'])) . '</td>';
            echo '<td>' . htmlspecialchars($row['tipo_usuario']) . '</td>';
            echo '<td>' . htmlspecialchars($row['status']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }
    // Diagnóstico das associações
    echo '<h3>Associações nas Unidades</h3>';
    $stmt2 = $conn->prepare("SELECT a.id, u.nome, u.cpf, a.perfil, a.status_aprovacao, a.senha_hash FROM associacoes_usuario_unidade a JOIN usuarios u ON a.id_usuario = u.id WHERE u.cpf IN ($in)");
    $stmt2->bind_param(str_repeat('s', count($cpfs)), ...$cpfs);
    $stmt2->execute();
    $result2 = $stmt2->get_result();
    if ($result2->num_rows === 0) {
        echo '<p>Nenhuma associação encontrada.</p>';
    } else {
        echo '<table border="1" cellpadding="6" style="border-collapse:collapse;">';
        echo '<tr><th>ID Assoc</th><th>Nome</th><th>CPF</th><th>Perfil</th><th>Status Aprovação</th><th>Senha Hash (associação)</th></tr>';
        while ($row = $result2->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['id']) . '</td>';
            echo '<td>' . htmlspecialchars($row['nome']) . '</td>';
            echo '<td>' . htmlspecialchars($row['cpf']) . '</td>';
            echo '<td>' . htmlspecialchars($row['perfil']) . '</td>';
            echo '<td>' . htmlspecialchars($row['status_aprovacao']) . '</td>';
            echo '<td>' . htmlspecialchars($row['senha_hash']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }
} catch (Exception $e) {
    echo '<p style="color:red">Erro ao buscar usuários: ' . $e->getMessage() . '</p>';
}
$conn->close(); 