<?php
/**
 * 🔒 AUDITORIA DE SEGURANÇA - Easy Rake
 * 
 * Script para identificar vulnerabilidades de segurança onde usuários
 * podem acessar dados de outros usuários, violando privacidade.
 */

require_once __DIR__ . '/../api/db_connect.php';

echo "🔒 AUDITORIA DE SEGURANÇA - EASY RAKE\n";
echo "=====================================\n\n";

// Verificar conexão
if (!isset($conn) || $conn->connect_error) {
    echo "❌ ERRO: Não foi possível conectar ao banco de dados\n";
    exit;
}

echo "✅ Conexão MySQL OK (Porta 3307)\n\n";

$vulnerabilidades = [];

// 1. VERIFICAR API GET_CAIXA_INFO - VULNERABILIDADE CRÍTICA
echo "1. 🔍 VERIFICANDO API GET_CAIXA_INFO...\n";
echo "   ⚠️  PROBLEMA IDENTIFICADO:\n";
echo "   - Arquivo: api/caixas/get_caixa_info.php\n";
echo "   - Linha 25: WHERE c.id = ? (SEM VERIFICAR OPERADOR)\n";
echo "   - Qualquer usuário pode acessar qualquer caixa!\n";
echo "   - CORREÇÃO NECESSÁRIA: Adicionar verificação de operador_id\n\n";

$vulnerabilidades[] = [
    'arquivo' => 'api/caixas/get_caixa_info.php',
    'problema' => 'Usuário pode acessar qualquer caixa sem verificação de propriedade',
    'severidade' => 'CRÍTICA',
    'linha' => 25
];

// 2. VERIFICAR API COMPILAR_DADOS - VULNERABILIDADE CRÍTICA
echo "2. 🔍 VERIFICANDO API COMPILAR_DADOS...\n";
echo "   ⚠️  PROBLEMA IDENTIFICADO:\n";
echo "   - Arquivo: api/caixas/compilar_dados.php\n";
echo "   - Linha 8: WHERE id = \$caixa_id (SEM VERIFICAR OPERADOR)\n";
echo "   - Qualquer usuário pode compilar dados de qualquer caixa!\n";
echo "   - CORREÇÃO NECESSÁRIA: Adicionar verificação de operador_id\n\n";

$vulnerabilidades[] = [
    'arquivo' => 'api/caixas/compilar_dados.php',
    'problema' => 'Usuário pode compilar dados de qualquer caixa sem verificação',
    'severidade' => 'CRÍTICA',
    'linha' => 8
];

// 3. VERIFICAR API RELATORIO_EXCEL - VULNERABILIDADE CRÍTICA
echo "3. 🔍 VERIFICANDO API RELATORIO_EXCEL...\n";
echo "   ⚠️  PROBLEMA IDENTIFICADO:\n";
echo "   - Arquivo: api/caixas/relatorio_excel.php\n";
echo "   - Linha 7: \$caixa_id = isset(\$_GET['caixa_id']) (SEM VERIFICAR OPERADOR)\n";
echo "   - Qualquer usuário pode gerar relatório de qualquer caixa!\n";
echo "   - CORREÇÃO NECESSÁRIA: Adicionar verificação de operador_id\n\n";

$vulnerabilidades[] = [
    'arquivo' => 'api/caixas/relatorio_excel.php',
    'problema' => 'Usuário pode gerar relatório de qualquer caixa sem verificação',
    'severidade' => 'CRÍTICA',
    'linha' => 7
];

// 4. VERIFICAR API RELATORIO_PDF - VULNERABILIDADE CRÍTICA
echo "4. 🔍 VERIFICANDO API RELATORIO_PDF...\n";
echo "   ⚠️  PROBLEMA IDENTIFICADO:\n";
echo "   - Arquivo: api/caixas/relatorio_pdf.php\n";
echo "   - Linha 7: \$caixa_id = isset(\$_GET['caixa_id']) (SEM VERIFICAR OPERADOR)\n";
echo "   - Qualquer usuário pode gerar PDF de qualquer caixa!\n";
echo "   - CORREÇÃO NECESSÁRIA: Adicionar verificação de operador_id\n\n";

$vulnerabilidades[] = [
    'arquivo' => 'api/caixas/relatorio_pdf.php',
    'problema' => 'Usuário pode gerar PDF de qualquer caixa sem verificação',
    'severidade' => 'CRÍTICA',
    'linha' => 7
];

// 5. VERIFICAR API RAKE_LISTAR - VULNERABILIDADE CRÍTICA
echo "5. 🔍 VERIFICANDO API RAKE_LISTAR...\n";
echo "   ⚠️  PROBLEMA IDENTIFICADO:\n";
echo "   - Arquivo: api/caixas/rake_listar.php\n";
echo "   - Linha 18: WHERE caixa_id = ? (SEM VERIFICAR OPERADOR)\n";
echo "   - Qualquer usuário pode ver rake de qualquer caixa!\n";
echo "   - CORREÇÃO NECESSÁRIA: Adicionar verificação de operador_id\n\n";

$vulnerabilidades[] = [
    'arquivo' => 'api/caixas/rake_listar.php',
    'problema' => 'Usuário pode ver rake de qualquer caixa sem verificação',
    'severidade' => 'CRÍTICA',
    'linha' => 18
];

// 6. VERIFICAR API HISTORICO_CONFERENCIA - VULNERABILIDADE CRÍTICA
echo "6. 🔍 VERIFICANDO API HISTORICO_CONFERENCIA...\n";
echo "   ⚠️  PROBLEMA IDENTIFICADO:\n";
echo "   - Arquivo: api/caixas/historico_conferencia.php\n";
echo "   - Linha 22: WHERE h.caixa_id = ? (SEM VERIFICAR OPERADOR)\n";
echo "   - Qualquer usuário pode ver histórico de qualquer caixa!\n";
echo "   - CORREÇÃO NECESSÁRIA: Adicionar verificação de operador_id\n\n";

$vulnerabilidades[] = [
    'arquivo' => 'api/caixas/historico_conferencia.php',
    'problema' => 'Usuário pode ver histórico de qualquer caixa sem verificação',
    'severidade' => 'CRÍTICA',
    'linha' => 22
];

// 7. VERIFICAR API GET_SESSION_STATS - VULNERABILIDADE CRÍTICA
echo "7. 🔍 VERIFICANDO API GET_SESSION_STATS...\n";
echo "   ⚠️  PROBLEMA IDENTIFICADO:\n";
echo "   - Arquivo: api/caixas/get_session_stats.php\n";
echo "   - Linha 35: WHERE id = ? (SEM VERIFICAR OPERADOR)\n";
echo "   - Qualquer usuário pode ver stats de qualquer caixa!\n";
echo "   - CORREÇÃO NECESSÁRIA: Adicionar verificação de operador_id\n\n";

$vulnerabilidades[] = [
    'arquivo' => 'api/caixas/get_session_stats.php',
    'problema' => 'Usuário pode ver stats de qualquer caixa sem verificação',
    'severidade' => 'CRÍTICA',
    'linha' => 35
];

// 8. VERIFICAR API CAIXINHAS_LISTAR_INCLUSAO - VULNERABILIDADE CRÍTICA
echo "8. 🔍 VERIFICANDO API CAIXINHAS_LISTAR_INCLUSAO...\n";
echo "   ⚠️  PROBLEMA IDENTIFICADO:\n";
echo "   - Arquivo: api/caixas/caixinhas_listar_inclusoes.php\n";
echo "   - Linha 20: WHERE i.caixinha_id = ? (SEM VERIFICAR OPERADOR)\n";
echo "   - Qualquer usuário pode ver inclusões de qualquer caixinha!\n";
echo "   - CORREÇÃO NECESSÁRIA: Adicionar verificação de operador_id\n\n";

$vulnerabilidades[] = [
    'arquivo' => 'api/caixas/caixinhas_listar_inclusoes.php',
    'problema' => 'Usuário pode ver inclusões de qualquer caixinha sem verificação',
    'severidade' => 'CRÍTICA',
    'linha' => 20
];

// 9. VERIFICAR APIS QUE ESTÃO CORRETAS
echo "9. ✅ VERIFICANDO APIS SEGURAS...\n";
echo "   ✅ api/caixas/listar_abertos.php - CORRETO (filtra por operador_id)\n";
echo "   ✅ api/caixas/listar_gastos.php - CORRETO (filtra por operador_id)\n";
echo "   ✅ api/caixas/registrar_gasto.php - CORRETO (filtra por operador_id)\n";
echo "   ✅ api/caixas/excluir_gasto.php - CORRETO (filtra por operador_id)\n";
echo "   ✅ api/caixas/caixinhas_criar.php - CORRETO (filtra por operador_id)\n";
echo "   ✅ api/caixas/caixinhas_listar.php - CORRETO (filtra por operador_id)\n";
echo "   ✅ api/caixas/imprimir_todas_gastos.php - CORRETO (filtra por operador_id)\n";
echo "   ✅ api/caixas/imprimir_recibo_gasto.php - CORRETO (filtra por operador_id)\n\n";

// 10. RELATÓRIO DE VULNERABILIDADES
echo "10. 📊 RELATÓRIO DE VULNERABILIDADES\n";
echo "    🚨 TOTAL DE VULNERABILIDADES CRÍTICAS: " . count($vulnerabilidades) . "\n\n";

foreach ($vulnerabilidades as $index => $vuln) {
    echo "    " . ($index + 1) . ". {$vuln['severidade']}: {$vuln['arquivo']}\n";
    echo "       Problema: {$vuln['problema']}\n";
    echo "       Linha: {$vuln['linha']}\n\n";
}

// 11. SUGESTÕES DE CORREÇÃO
echo "11. 🔧 SUGESTÕES DE CORREÇÃO\n";
echo "    Para cada API vulnerável, adicionar:\n\n";
echo "    // VERIFICAÇÃO DE SEGURANÇA - OBRIGATÓRIA\n";
echo "    session_start();\n";
echo "    if (!isset(\$_SESSION['user_id'])) {\n";
echo "        echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);\n";
echo "        exit;\n";
echo "    }\n\n";
echo "    // VERIFICAR SE O CAIXA PERTENCE AO USUÁRIO\n";
echo "    \$stmt = \$conn->prepare('SELECT operador_id FROM caixas WHERE id = ?');\n";
echo "    \$stmt->bind_param('i', \$caixa_id);\n";
echo "    \$stmt->execute();\n";
echo "    \$result = \$stmt->get_result();\n";
echo "    \$caixa = \$result->fetch_assoc();\n\n";
echo "    if (!\$caixa || \$caixa['operador_id'] != \$_SESSION['user_id']) {\n";
echo "        echo json_encode(['success' => false, 'message' => 'Acesso negado.']);\n";
echo "        exit;\n";
echo "    }\n\n";

// 12. RELATÓRIO FINAL
echo str_repeat("=", 60) . "\n";
echo "🚨 RELATÓRIO DE AUDITORIA DE SEGURANÇA\n";
echo str_repeat("=", 60) . "\n\n";

echo "🎯 STATUS: 🚨 VULNERABILIDADES CRÍTICAS ENCONTRADAS\n";
echo "   Total de vulnerabilidades: " . count($vulnerabilidades) . "\n";
echo "   Severidade: CRÍTICA (violação de privacidade de dados)\n\n";

echo "🔧 AÇÕES URGENTES NECESSÁRIAS:\n";
echo "   1. Corrigir TODAS as APIs vulneráveis\n";
echo "   2. Implementar verificação de propriedade de dados\n";
echo "   3. Testar todas as correções\n";
echo "   4. Executar auditoria novamente\n\n";

echo "🧠 INSTRUÇÕES PARA IA:\n";
echo "1. CORRIGIR IMEDIATAMENTE todas as vulnerabilidades identificadas\n";
echo "2. Implementar verificação de propriedade em todas as APIs\n";
echo "3. Testar cada correção individualmente\n";
echo "4. Executar este script novamente para validar\n";

echo "\n" . str_repeat("=", 60) . "\n";
echo "🚨 AUDITORIA CONCLUÍDA - CORREÇÕES URGENTES NECESSÁRIAS\n";
echo str_repeat("=", 60) . "\n";

$conn->close();
?> 