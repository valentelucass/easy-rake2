<?php
// Script para remover operador (usuário) e dados associados
// Uso: php remover_operador.php --id=8

require_once __DIR__ . '/../api/db_connect.php';

function getArg($name) {
    foreach ($GLOBALS['argv'] as $arg) {
        if (strpos($arg, "--$name=") === 0) {
            return substr($arg, strlen($name) + 3);
        }
    }
    return null;
}

$id = intval(getArg('id'));
if ($id <= 0) {
    echo "[ERRO] ID inválido. Use --id=NUM\n";
    exit(1);
}

// 1. Verifica se o usuário existe
$stmt = $conn->prepare('SELECT nome, tipo_usuario FROM usuarios WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo "[ERRO] Usuário não encontrado.\n";
    exit(1);
}
$user = $result->fetch_assoc();
echo "Removendo usuário: {$user['nome']} (ID: $id, Tipo: {$user['tipo_usuario']})\n";
$stmt->close();

// 2. Remover registros dependentes em todas as tabelas com FK

// Movimentações
$stmt = $conn->prepare('DELETE FROM movimentacoes WHERE operador_id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
echo "- Movimentações removidas: {$stmt->affected_rows}\n";
$stmt->close();

// Transações de jogadores
$stmt = $conn->prepare('DELETE FROM transacoes_jogadores WHERE operador_id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
echo "- Transações de jogadores removidas: {$stmt->affected_rows}\n";
$stmt->close();

// Gastos
$stmt = $conn->prepare('DELETE FROM gastos WHERE operador_id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
echo "- Gastos removidos: {$stmt->affected_rows}\n";
$stmt->close();

// Aprovações (como solicitante)
$stmt = $conn->prepare('DELETE FROM aprovacoes WHERE solicitante_id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
echo "- Aprovações (solicitante) removidas: {$stmt->affected_rows}\n";
$stmt->close();

// Aprovações (como aprovador)
$stmt = $conn->prepare('DELETE FROM aprovacoes WHERE aprovador_id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
echo "- Aprovações (aprovador) removidas: {$stmt->affected_rows}\n";
$stmt->close();

// Inclusões em caixinhas
$stmt = $conn->prepare('DELETE FROM caixinhas_inclusoes WHERE operador_id = ? OR usuario_id = ?');
$stmt->bind_param('ii', $id, $id);
$stmt->execute();
echo "- Inclusões em caixinhas removidas: {$stmt->affected_rows}\n";
$stmt->close();

// Histórico de relatórios
$stmt = $conn->prepare('DELETE FROM relatorios_historico WHERE id_usuario = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
echo "- Histórico de relatórios removido: {$stmt->affected_rows}\n";
$stmt->close();

// 3. Remove caixas abertos do operador
$stmt = $conn->prepare('DELETE FROM caixas WHERE operador_id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
echo "- Caixas removidos: {$stmt->affected_rows}\n";
$stmt->close();

// 4. Remove associações do operador
$stmt = $conn->prepare('DELETE FROM associacoes_usuario_unidade WHERE id_usuario = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
echo "- Associações removidas: {$stmt->affected_rows}\n";
$stmt->close();

// 5. Remove o usuário
$stmt = $conn->prepare('DELETE FROM usuarios WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
echo "- Usuário removido: {$stmt->affected_rows}\n";
$stmt->close();

$conn->close();
echo "[OK] Remoção concluída.\n"; 