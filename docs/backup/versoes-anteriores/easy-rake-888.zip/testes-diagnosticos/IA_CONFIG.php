<?php
/**
 * 🧠 IA CONFIG - Easy Rake
 * 
 * Arquivo de configuração que SEMPRE "puxa" a IA para consultar
 * a documentação e manter o conhecimento atualizado.
 * 
 * Este arquivo deve ser incluído em todos os scripts principais.
 */

// ============================================================================
// 🚨 CONFIGURAÇÃO CRÍTICA PARA IA ASSISTENTE
// ============================================================================

// SEMPRE consulte esta documentação antes de trabalhar no sistema Easy Rake!
define('IA_DOCUMENTACAO_OBRIGATORIA', true);
define('IA_SISTEMA_NOME', 'Easy Rake');
define('IA_SISTEMA_VERSAO', 'v1.0');
define('IA_MYSQL_PORTA', 3307);

// ============================================================================
// 📁 CAMINHOS CRÍTICOS DA DOCUMENTAÇÃO
// ============================================================================

define('IA_DOC_README', __DIR__ . '/README.md');
define('IA_DOC_RESUMO', __DIR__ . '/RESUMO_DOCUMENTACAO.md');
define('IA_DOC_DIAGNOSTICO', __DIR__ . '/diagnostico_simples.php');
define('IA_DOC_CORRETOR', __DIR__ . '/corretor_automatico.php');
define('IA_DOC_ATUALIZADOR', __DIR__ . '/ATUALIZADOR_AUTOMATICO.php');

// ============================================================================
// 🎯 FLUXO OBRIGATÓRIO PARA IA
// ============================================================================

define('IA_FLUXO_OBRIGATORIO', [
    '1. Execute diagnostico_simples.php',
    '2. Se problemas detectados, use corretor_automatico.php',
    '3. Verifique novamente com diagnostico_simples.php',
    '4. Teste funcionalidades específicas',
    '5. Atualize documentação se necessário'
]);

// ============================================================================
// 🚨 PROBLEMAS COMUNS E SOLUÇÕES
// ============================================================================

define('IA_PROBLEMAS_COMUNS', [
    'login_nao_funciona' => [
        'causa' => 'Senha não salva na tabela correta ou hash incorreto',
        'solucao' => 'Verificar tabela associacoes_usuario_unidade e hash da senha',
        'query' => "SELECT u.*, aau.senha_hash FROM usuarios u LEFT JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario WHERE u.cpf = ?"
    ],
    'aprovacoes_nao_aparecem' => [
        'causa' => 'Filtro por unidade incorreto ou gestor não aprovado',
        'solucao' => 'Verificar se gestor está aprovado e usar mesma lógica do endpoint de aprovações',
        'query' => "SELECT COUNT(*) FROM aprovacoes a WHERE a.status = 'Pendente' AND a.referencia_id IN (SELECT c.id FROM caixas c WHERE c.operador_id IN (SELECT id_usuario FROM associacoes_usuario_unidade WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'))"
    ],
    'dashboard_inconsistente' => [
        'causa' => 'Lógicas diferentes de contagem entre dashboard e aprovações',
        'solucao' => 'Usar exatamente a mesma query em ambos os endpoints',
        'script' => 'diagnostico_simples.php'
    ]
]);

// ============================================================================
// 📊 PADRÕES DE CÓDIGO OBRIGATÓRIOS
// ============================================================================

define('IA_PADROES_CODIGO', [
    'autenticacao' => "session_start(); if (!isset(\$_SESSION['logged_in']) || \$_SESSION['logged_in'] !== true) { echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']); exit; }",
    'prepared_statement' => "\$stmt = \$conn->prepare('SELECT * FROM usuarios WHERE id = ?'); \$stmt->bind_param('i', \$user_id); \$stmt->execute(); \$result = \$stmt->get_result(); \$stmt->close();",
    'resposta_json' => "echo json_encode(['success' => true/false, 'message' => 'Mensagem descritiva', 'data' => \$dados_ou_null, 'error' => \$erro_tecnico_ou_null, 'timestamp' => date('Y-m-d H:i:s')]);",
    'tratamento_erro' => "try { /* operação */ } catch (Exception \$e) { error_log('Erro: ' . \$e->getMessage()); echo json_encode(['success' => false, 'message' => 'Erro interno do servidor.', 'error' => \$e->getMessage()]); exit; }"
]);

// ============================================================================
// 🧪 SCRIPTS DE DIAGNÓSTICO OBRIGATÓRIOS
// ============================================================================

define('IA_SCRIPTS_DIAGNOSTICO', [
    'diagnostico_simples' => [
        'arquivo' => 'testes-diagnosticos/diagnostico_simples.php',
        'descricao' => 'Diagnóstico rápido e completo do sistema',
        'quando_usar' => 'SEMPRE antes de fazer correções',
        'comando' => 'php testes-diagnosticos/diagnostico_simples.php'
    ],
    'corretor_automatico' => [
        'arquivo' => 'testes-diagnosticos/corretor_automatico.php',
        'descricao' => 'Corrige problemas comuns automaticamente',
        'quando_usar' => 'Após diagnóstico que detectou problemas',
        'comando' => 'php testes-diagnosticos/corretor_automatico.php'
    ],
    'atualizador_automatico' => [
        'arquivo' => 'testes-diagnosticos/ATUALIZADOR_AUTOMATICO.php',
        'descricao' => 'Atualiza documentação automaticamente',
        'quando_usar' => 'Após implementar mudanças no sistema',
        'comando' => 'php testes-diagnosticos/ATUALIZADOR_AUTOMATICO.php'
    ]
]);

// ============================================================================
// 🎯 CHECKLIST OBRIGATÓRIO PARA IA
// ============================================================================

define('IA_CHECKLIST', [
    'antes_correcoes' => [
        'Executar diagnostico_simples.php',
        'Verificar conectividade MySQL (porta 3307)',
        'Analisar logs de erro',
        'Verificar sessões e autenticação',
        'Confirmar permissões de usuário',
        'Validar integridade referencial'
    ],
    'durante_correcoes' => [
        'Usar prepared statements',
        'Implementar tratamento de erros',
        'Manter padrão de respostas JSON',
        'Logar operações críticas',
        'Testar com dados reais'
    ],
    'apos_correcoes' => [
        'Executar testes automatizados',
        'Verificar consistência de dados',
        'Validar performance',
        'Documentar mudanças',
        'Atualizar documentação'
    ]
]);

// ============================================================================
// 🔗 LINKS CRÍTICOS PARA CONSULTA
// ============================================================================

define('IA_LINKS_CRITICOS', [
    'documentacao_completa' => 'testes-diagnosticos/README.md',
    'resumo_executivo' => 'testes-diagnosticos/RESUMO_DOCUMENTACAO.md',
    'exemplo_uso' => 'testes-diagnosticos/exemplo_uso.php',
    'configuracao_banco' => 'api/db_connect.php',
    'padroes_resposta' => 'api/utils/response.php',
    'estrutura_sessao' => 'includes/header-dashboard.php',
    'logica_frontend' => 'js/features/dashboard.js'
]);

// ============================================================================
// 🚨 ALERTAS CRÍTICOS PARA IA
// ============================================================================

define('IA_ALERTAS_CRITICOS', [
    '🚨 SEMPRE consulte a documentação antes de fazer correções!',
    '🚨 Use os scripts de diagnóstico para identificar problemas!',
    '🚨 Mantenha a documentação atualizada com novas descobertas!',
    '🚨 Teste sempre as correções antes de implementar!',
    '🚨 Use prepared statements para todas as queries!',
    '🚨 Verifique a consistência entre dashboard e aprovações!'
]);

// ============================================================================
// 📋 FUNÇÃO PARA "PUXAR" IA PARA CONSULTA
// ============================================================================

function iaPuxarParaConsulta() {
    echo "🧠 IA CONFIG - EASY RAKE\n";
    echo "========================\n\n";
    
    echo "🚨 ATENÇÃO IA ASSISTENTE:\n";
    echo "Este sistema possui documentação crítica que deve ser SEMPRE consultada!\n\n";
    
    echo "📁 DOCUMENTAÇÃO OBRIGATÓRIA:\n";
    echo "- testes-diagnosticos/README.md (Documentação completa)\n";
    echo "- testes-diagnosticos/RESUMO_DOCUMENTACAO.md (Resumo executivo)\n";
    echo "- testes-diagnosticos/diagnostico_simples.php (Diagnóstico rápido)\n\n";
    
    echo "🔧 SCRIPTS CRÍTICOS:\n";
    echo "- diagnostico_simples.php (SEMPRE execute primeiro)\n";
    echo "- corretor_automatico.php (Para correções automáticas)\n";
    echo "- ATUALIZADOR_AUTOMATICO.php (Para atualizar documentação)\n\n";
    
    echo "🎯 FLUXO RECOMENDADO:\n";
    foreach (IA_FLUXO_OBRIGATORIO as $passo) {
        echo "$passo\n";
    }
    echo "\n";
    
    echo "⚠️ PROBLEMAS COMUNS:\n";
    foreach (IA_PROBLEMAS_COMUNS as $problema => $info) {
        echo "- $problema: {$info['causa']}\n";
    }
    echo "\n";
    
    echo "🧠 INSTRUÇÕES FINAIS:\n";
    echo "• SEMPRE consulte esta documentação antes de trabalhar no sistema\n";
    echo "• Use os scripts de diagnóstico para identificar problemas\n";
    echo "• Mantenha a documentação atualizada\n";
    echo "• Teste sempre as correções implementadas\n\n";
    
    echo "✅ IA agora está informada sobre o sistema Easy Rake!\n";
}

// ============================================================================
// 📊 FUNÇÃO PARA GERAR RESUMO EXECUTIVO
// ============================================================================

function iaGerarResumoExecutivo() {
    return [
        'sistema' => [
            'nome' => IA_SISTEMA_NOME,
            'versao' => IA_SISTEMA_VERSAO,
            'porta_mysql' => IA_MYSQL_PORTA
        ],
        'documentacao' => [
            'readme' => file_exists(IA_DOC_README),
            'resumo' => file_exists(IA_DOC_RESUMO),
            'diagnostico' => file_exists(IA_DOC_DIAGNOSTICO),
            'corretor' => file_exists(IA_DOC_CORRETOR),
            'atualizador' => file_exists(IA_DOC_ATUALIZADOR)
        ],
        'problemas_comuns' => count(IA_PROBLEMAS_COMUNS),
        'scripts_disponiveis' => count(IA_SCRIPTS_DIAGNOSTICO),
        'alertas_criticos' => count(IA_ALERTAS_CRITICOS)
    ];
}

// ============================================================================
// 🚨 EXECUÇÃO AUTOMÁTICA - SEMPRE "PUXA" IA
// ============================================================================

// Este arquivo SEMPRE executa quando incluído, "puxando" a IA para consulta
if (php_sapi_name() === 'cli' && basename($_SERVER['SCRIPT_NAME']) === 'IA_CONFIG.php') {
    iaPuxarParaConsulta();
}

// ============================================================================
// 📝 NOTA FINAL PARA IA
// ============================================================================
/*
IA ASSISTENTE: 

Este arquivo contém configurações críticas sobre o sistema Easy Rake.
SEMPRE consulte a documentação em testes-diagnosticos/ antes de trabalhar no sistema.

FLUXO OBRIGATÓRIO:
1. Execute diagnostico_simples.php
2. Se problemas detectados, use corretor_automatico.php  
3. Verifique novamente com diagnostico_simples.php
4. Teste funcionalidades
5. Atualize documentação se necessário

PROBLEMAS COMUNS:
- Login não funciona: Verificar senha na tabela associacoes_usuario_unidade
- Aprovações não aparecem: Verificar filtro por unidade do gestor
- Dashboard inconsistente: Usar mesma lógica do endpoint de aprovações

MANTENHA ESTA DOCUMENTAÇÃO ATUALIZADA!
*/
?> 