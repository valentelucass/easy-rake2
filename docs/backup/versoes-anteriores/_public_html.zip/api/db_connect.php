<?php
// Definições do Banco de Dados (usa variáveis de ambiente se disponíveis)
define('DB_SERVER', getenv('DB_SERVER') ?: 'localhost');
define('DB_USERNAME', getenv('DB_USERNAME') ?: 'u805514793_Lucas');
define('DB_PASSWORD', getenv('DB_PASSWORD') ?: '#Codek8908');
define('DB_NAME', getenv('DB_NAME') ?: 'u805514793_easy_rake');
define('DB_PORT', getenv('DB_PORT') ?: 3306);

// Criar a conexão mysqli
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME, DB_PORT);

// Checar a conexão
if ($conn->connect_error) {
    // Loga o erro no servidor, mas não exibe detalhes ao usuário
    error_log('Conexão falhou: ' . $conn->connect_error);
    die('Erro interno ao conectar ao banco de dados.');
}

// Define o charset para UTF-8 para evitar problemas com acentos
$conn->set_charset('utf8mb4');

// Fechar a conexão ao final do script (boa prática)
register_shutdown_function(function() use ($conn) {
    if ($conn && $conn->ping()) {
        $conn->close();
    }
});