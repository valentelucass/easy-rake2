<?php
// Script de teste para demonstrar o sistema de aprovações
require_once 'api/db_connect.php';

echo "<h1>🧪 Teste do Sistema de Aprovações - Easy Rake</h1>";

try {
    // 1. Criar dados de teste
    echo "<h2>1. Criando dados de teste...</h2>";
    
    // Inserir jogador com limite alto (deve criar aprovação)
    $stmt = $conn->prepare("INSERT INTO jogadores (nome, cpf, telefone, limite_credito, saldo_atual, status) VALUES (?, ?, ?, ?, 0.00, 'Pendente')");
    $stmt->bind_param('sssd', 'João Silva Teste', '123.456.789-01', '(11) 99999-9999', 1500.00);
    $stmt->execute();
    $jogador_id = $conn->insert_id;
    
    // Criar aprovação para o jogador
    $stmt_aprov = $conn->prepare("INSERT INTO aprovacoes (tipo, referencia_id, solicitante_id, status, observacoes) VALUES (?, ?, ?, ?, ?)");
    $stmt_aprov->bind_param('siiss', 'Jogador', $jogador_id, 1, 'Pendente', 'Jogador com limite de crédito alto: R$ 1.500,00');
    $stmt_aprov->execute();
    
    // Inserir caixa com valor alto (deve criar aprovação)
    $stmt_caixa = $conn->prepare("INSERT INTO caixas (operador_id, valor_inicial, observacoes, status, data_abertura) VALUES (?, ?, ?, ?, NOW())");
    $stmt_caixa->bind_param('idss', 1, 6000.00, 'Caixa teste com valor alto', 'Pendente');
    $stmt_caixa->execute();
    $caixa_id = $conn->insert_id;
    
    // Criar aprovação para o caixa
    $stmt_aprov_caixa = $conn->prepare("INSERT INTO aprovacoes (tipo, referencia_id, solicitante_id, status, observacoes) VALUES (?, ?, ?, ?, ?)");
    $stmt_aprov_caixa->bind_param('siiss', 'Caixa', $caixa_id, 1, 'Pendente', 'Abertura de caixa com valor alto: R$ 6.000,00');
    $stmt_aprov_caixa->execute();
    
    echo "✅ Dados de teste criados com sucesso!<br>";
    echo "- Jogador ID: $jogador_id (limite R$ 1.500,00)<br>";
    echo "- Caixa ID: $caixa_id (valor R$ 6.000,00)<br><br>";
    
    // 2. Testar API de listagem de pendentes
    echo "<h2>2. Testando API de aprovações pendentes...</h2>";
    
    // Simular sessão de gestor
    $_SESSION['user_id'] = 1;
    $_SESSION['perfil'] = 'Gestor';
    
    // Incluir e testar a API
    ob_start();
    include 'api/aprovacoes_listar_pendentes.php';
    $response = ob_get_clean();
    
    $data = json_decode($response, true);
    if ($data['success']) {
        echo "✅ API funcionando! Encontradas " . count($data['aprovacoes']) . " aprovações pendentes:<br>";
        foreach ($data['aprovacoes'] as $aprov) {
            echo "- ID: {$aprov['id']} | Tipo: {$aprov['tipo']} | Status: {$aprov['status']}<br>";
            if (isset($aprov['descricao'])) {
                echo "  Descrição: {$aprov['descricao']}<br>";
            }
        }
    } else {
        echo "❌ Erro na API: " . $data['message'] . "<br>";
    }
    
    echo "<br>";
    
    // 3. Testar API de histórico
    echo "<h2>3. Testando API de histórico...</h2>";
    
    ob_start();
    include 'api/aprovacoes_listar_historico.php';
    $response_hist = ob_get_clean();
    
    $data_hist = json_decode($response_hist, true);
    if ($data_hist['success']) {
        echo "✅ API de histórico funcionando! Encontrados " . count($data_hist['historico']) . " registros no histórico.<br>";
    } else {
        echo "❌ Erro na API de histórico: " . $data_hist['message'] . "<br>";
    }
    
    echo "<br>";
    
    // 4. Testar aprovação
    echo "<h2>4. Testando aprovação...</h2>";
    
    // Simular aprovação via POST
    $_POST = json_encode(['tipo' => 'Jogador', 'id' => $jogador_id, 'acao' => 'aprovar']);
    
    ob_start();
    include 'api/aprovacoes_acao.php';
    $response_acao = ob_get_clean();
    
    $data_acao = json_decode($response_acao, true);
    if ($data_acao['success']) {
        echo "✅ Aprovação funcionando! " . $data_acao['message'] . "<br>";
    } else {
        echo "❌ Erro na aprovação: " . $data_acao['message'] . "<br>";
    }
    
    echo "<br>";
    
    // 5. Verificar status após aprovação
    echo "<h2>5. Verificando status após aprovação...</h2>";
    
    $stmt_check = $conn->prepare("SELECT status FROM jogadores WHERE id = ?");
    $stmt_check->bind_param('i', $jogador_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    $jogador = $result->fetch_assoc();
    
    if ($jogador['status'] === 'Ativo') {
        echo "✅ Jogador ativado com sucesso após aprovação!<br>";
    } else {
        echo "❌ Jogador não foi ativado. Status atual: " . $jogador['status'] . "<br>";
    }
    
    echo "<br>";
    
    // 6. Limpeza dos dados de teste
    echo "<h2>6. Limpando dados de teste...</h2>";
    
    $conn->query("DELETE FROM aprovacoes WHERE observacoes LIKE '%teste%' OR observacoes LIKE '%Teste%'");
    $conn->query("DELETE FROM caixas WHERE observacoes LIKE '%teste%' OR observacoes LIKE '%Teste%'");
    $conn->query("DELETE FROM jogadores WHERE nome LIKE '%Teste%'");
    
    echo "✅ Dados de teste removidos!<br>";
    
    echo "<br><h2>🎉 Teste concluído com sucesso!</h2>";
    echo "<p>O sistema de aprovações está funcionando corretamente:</p>";
    echo "<ul>";
    echo "<li>✅ Criação automática de aprovações</li>";
    echo "<li>✅ Listagem de aprovações pendentes</li>";
    echo "<li>✅ Histórico de aprovações</li>";
    echo "<li>✅ Processamento de aprovações</li>";
    echo "<li>✅ Ativação automática após aprovação</li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "❌ Erro durante o teste: " . $e->getMessage();
}

$conn->close();
?>

<style>
body {
    font-family: Arial, sans-serif;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background: #f5f5f5;
}

h1 {
    color: #e11d48;
    text-align: center;
    border-bottom: 3px solid #e11d48;
    padding-bottom: 10px;
}

h2 {
    color: #333;
    background: #fff;
    padding: 10px;
    border-radius: 5px;
    border-left: 4px solid #e11d48;
}

ul {
    background: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

li {
    margin: 5px 0;
    padding: 5px 0;
}
</style> 