// JS dedicado para Abrir Novo Caixa
// Responsável por: adicionar/remover linhas, calcular total, listeners

document.addEventListener('DOMContentLoaded', function() {
    const fichasLista = document.getElementById('fichas-lista');
    const btnAdicionarFicha = document.getElementById('btn-adicionar-ficha');
    const totalAberturaEl = document.getElementById('total-abertura');
    const form = document.getElementById('inventario-fichas-form');
    const sucessoContainer = document.getElementById('caixa-aberto-sucesso');
    let isLoading = false;

    function criarLinhaFicha(valor = '', qtd = '') {
        const linha = document.createElement('div');
        linha.className = 'form-group ficha-linha';
        linha.innerHTML = `
            <input type="number" min="0" step="0.01" class="ficha-valor" placeholder="Valor da Ficha" value="${valor}">
            <input type="number" min="0" step="1" class="ficha-qtd" placeholder="Quantidade" value="${qtd}">
            <button type="button" class="btn-remove-ficha" title="Remover"></button>
        `;
        linha.querySelector('.btn-remove-ficha').onclick = () => {
            linha.remove();
            atualizarTotal();
        };
        linha.querySelectorAll('input').forEach(inp => {
            inp.oninput = atualizarTotal;
        });
        return linha;
    }

    function adicionarLinhaFicha() {
        fichasLista.appendChild(criarLinhaFicha());
    }

    function atualizarTotal() {
        let total = 0;
        fichasLista.querySelectorAll('.ficha-linha').forEach(linha => {
            const valor = parseFloat(linha.querySelector('.ficha-valor').value.replace(',', '.')) || 0;
            const qtd = parseInt(linha.querySelector('.ficha-qtd').value) || 0;
            total += valor * qtd;
        });
        totalAberturaEl.textContent = 'Total de Abertura: R$ ' + total.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
    }

    // Inicialização
    function inicializarFichas() {
        fichasLista.innerHTML = '';
        fichasLista.appendChild(criarLinhaFicha());
        atualizarTotal();
    }

    // Listener do botão adicionar
    if (btnAdicionarFicha) {
        btnAdicionarFicha.onclick = adicionarLinhaFicha;
    }

    // Atualiza total ao digitar
    fichasLista.oninput = atualizarTotal;

    inicializarFichas();

    // --- SUBMISSÃO ROBUSTA DO FORMULÁRIO ---
    if (form) {
        form.onsubmit = async function(e) {
            e.preventDefault();
            if (isLoading) return;
            // Validação básica
            let valido = true;
            let fichas = [];
            let total = 0;
            fichasLista.querySelectorAll('.ficha-linha').forEach(linha => {
                const valor = parseFloat(linha.querySelector('.ficha-valor').value.replace(',', '.')) || 0;
                const qtd = parseInt(linha.querySelector('.ficha-qtd').value) || 0;
                if (valor <= 0 || qtd <= 0) valido = false;
                fichas.push({ valor, qtd });
                total += valor * qtd;
            });
            if (!valido || fichas.length === 0 || total <= 0) {
                alert('Preencha todos os valores e quantidades corretamente.');
                return;
            }
            // Desabilita botões
            isLoading = true;
            form.querySelectorAll('button').forEach(btn => btn.disabled = true);
            sucessoContainer.style.display = 'none';
            sucessoContainer.innerHTML = '';
            // Mostra loading
            totalAberturaEl.textContent = 'Processando abertura...';
            // Envia para o backend
            try {
                const response = await fetch('api/caixas/abrir_caixa.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ fichas, valor_inicial: total })
                });
                const result = await response.json();
                if (result.success && result.caixa) {
                    // Mostra botão de acesso ao dashboard do caixa aberto
                    sucessoContainer.innerHTML = `
                        <button class="btn btn-primary btn-lg btn-block" style="margin-top:1rem;" onclick="window.location.href='caixa-aberto-dashboard.php?id=${result.caixa.id}'">
                            Caixa aberto com sucesso!<br>
                            Valor: <b>R$ ${Number(result.caixa.valor_inicial).toLocaleString('pt-BR', {minimumFractionDigits:2})}</b><br>
                            Data/Hora: <b>${result.caixa.data_abertura ? result.caixa.data_abertura : ''}</b>
                            <br>Clique aqui para acessar o dashboard do caixa
                        </button>
                    `;
                    sucessoContainer.style.display = 'block';
                    totalAberturaEl.textContent = 'Total de Abertura: R$ ' + Number(result.caixa.valor_inicial).toLocaleString('pt-BR', {minimumFractionDigits:2});
                    // Opcional: resetar formulário
                    // form.reset();
                } else {
                    alert(result.message || 'Erro ao abrir caixa.');
                    totalAberturaEl.textContent = 'Total de Abertura: R$ 0,00';
                }
            } catch (err) {
                alert('Erro de conexão. Tente novamente.');
                totalAberturaEl.textContent = 'Total de Abertura: R$ 0,00';
            }
            // Reabilita botões
            isLoading = false;
            form.querySelectorAll('button').forEach(btn => btn.disabled = false);
        }
    }
}); 