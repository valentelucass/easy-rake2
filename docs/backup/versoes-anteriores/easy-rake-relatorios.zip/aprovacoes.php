<?php
// Inicia a sessão
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// Inclui a conexão com o banco de dados
require_once 'api/db_connect.php';

// Busca informações do usuário logado
$user_id = $_SESSION['user_id'];
$nome_usuario = $_SESSION['nome_usuario'];
$perfil_usuario = $_SESSION['perfil'];

// Inicializa variáveis para evitar erros
$stats = [
    'aprovacoes_pendentes' => 0
];

// Busca estatísticas de aprovações
try {
    $stats_query = "SELECT COUNT(*) as aprovacoes_pendentes FROM aprovacoes WHERE status = 'Pendente'";
    $stats_result = $conn->query($stats_query);
    if ($stats_result) {
        $stats = $stats_result->fetch_assoc();
    }
} catch (Exception $e) {
    error_log("Erro ao buscar estatísticas: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EASY RAKE - Aprovações</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/pages/_aprovacoes.css">
    <link rel="stylesheet" href="css/components/_header.css">
</head>
<body>
    <!-- Header Mobile Fixo -->
    <header id="mobile-header">
        <button id="hamburger-btn" aria-label="Abrir menu">
            <span class="hamburger-bar"></span>
            <span class="hamburger-bar"></span>
            <span class="hamburger-bar"></span>
        </button>
        <span class="mobile-title">EASY RAKE</span>
        <button id="logout-btn-mobile" aria-label="Sair" onclick="logout()">Sair</button>
    </header>

    <!-- Menu Lateral Deslizante -->
    <nav id="side-menu">
        <ul>
            <li><a href="abrir-caixa.php" class="menu-link">Abrir Novo Caixa</a></li>
            <li><a href="relatorios.php" class="menu-link">Relatórios</a></li>
            <li><a href="jogadores.php" class="menu-link">Jogadores</a></li>
            <li><a href="aprovacoes.php" class="menu-link active">Aprovações</a></li>
        </ul>
    </nav>
    <div id="menu-overlay"></div>

    <div class="app-container">
        <!-- Header Desktop (oculto em mobile) -->
        <header class="app-header">
            <div class="app-header-row">
                <a href="dashboard.php" class="back-arrow" title="Voltar">
                    <svg class="back-arrow-svg" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true">
                        <polyline points="16 4 8 12 16 20" fill="none" stroke="var(--accent-color)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </a>
                <div class="user-info">
                    <h1 class="company-title">EASY RAKE</h1>
                    <p class="user-name">Bem-vindo, <?php echo htmlspecialchars($nome_usuario); ?></p>
                    <p class="user-role"><?php echo htmlspecialchars($perfil_usuario); ?></p>
                </div>
                <button class="button button--secondary" onclick="logout()">Sair</button>
            </div>
        </header>
        
        <!-- Navegação Desktop (oculta em mobile) -->
        <nav id="tabs-container" class="tabs-container" role="tablist">
            <a href="abrir-caixa.php" class="tab-button">Abrir Novo Caixa</a>
            <a href="relatorios.php" class="tab-button">Relatórios</a>
            <a href="jogadores.php" class="tab-button">Jogadores</a>
            <a href="aprovacoes.php" class="tab-button active">Aprovações</a>
        </nav>
        
        <main id="main-content" class="dashboard-main">
            <div class="content-container">
                <div class="card-box section">
                    <h2>Aprovações</h2>
                    <p>Gerencie as aprovações pendentes do sistema.</p>
                    <div class="approvals-grid">
                        <div class="approval-card">
                            <h3>Aprovações Pendentes</h3>
                            <p class="approval-count"><?php echo $stats['aprovacoes_pendentes'] ?? 0; ?> pendentes</p>
                            <button class="button button--primary">Ver Todas</button>
                        </div>
                        <div class="approval-card">
                            <h3>Aprovações Aprovadas</h3>
                            <p class="approval-count">0 aprovadas hoje</p>
                            <button class="button button--secondary">Ver Histórico</button>
                        </div>
                        <div class="approval-card">
                            <h3>Aprovações Rejeitadas</h3>
                            <p class="approval-count">0 rejeitadas hoje</p>
                            <button class="button button--secondary">Ver Histórico</button>
                        </div>
                        <div class="approval-card">
                            <h3>Total de Aprovações</h3>
                            <p class="approval-count">0 no total</p>
                            <button class="button button--secondary">Ver Relatório</button>
                        </div>
                    </div>
                </div>

                <div class="card-box section">
                    <h2>Últimas Aprovações</h2>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tipo</th>
                                    <th>Solicitante</th>
                                    <th>Data Solicitação</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="6">Nenhuma aprovação encontrada</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        function logout() {
            if (confirm('Tem certeza que deseja sair?')) {
                window.location.href = 'api/auth/logout.php';
            }
        }
    </script>
    <script src="js/features/dashboard.js"></script>
</body>
</html> 