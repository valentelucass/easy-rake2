<?php
header('Content-Type: application/json');
require_once '../db_connect.php';

// Pega os dados JSON enviados pelo JavaScript
$input = json_decode(file_get_contents('php://input'), true);

// Padronizar CPF do gestor (apenas números)
if (isset($input['cpf_gestor'])) {
    $input['cpf_gestor'] = preg_replace('/\D/', '', $input['cpf_gestor']);
}

// Validação básica de campos obrigatórios
$required_fields = ['nome', 'cpf_gestor', 'telefone', 'nome_gestor', 'email_gestor', 'senha', 'confirmar_senha'];
foreach ($required_fields as $field) {
    if (empty($input[$field])) {
        echo json_encode(['success' => false, 'message' => "O campo '$field' é obrigatório."]);
        exit;
    }
}

// Validações específicas
if ($input['senha'] !== $input['confirmar_senha']) {
    echo json_encode(['success' => false, 'message' => 'As senhas não coincidem.']);
    exit;
}

if (!filter_var($input['email_gestor'], FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'O formato do e-mail é inválido.']);
    exit;
}

// Inicia a transação
$conn->begin_transaction();

try {
    // 1. Verificar se o email ou CPF já existe
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ? OR cpf = ?");
    $stmt->bind_param("ss", $input['email_gestor'], $input['cpf_gestor']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        throw new Exception("Um usuário com este e-mail ou CPF já está cadastrado no sistema.");
    }

    // 2. Inserir a nova unidade (sem endereço)
    $stmt_insert_unidade = $conn->prepare("INSERT INTO unidades (nome, telefone) VALUES (?, ?)");
    $stmt_insert_unidade->bind_param("ss", $input['nome'], $input['telefone']);
    $stmt_insert_unidade->execute();
    $id_unidade = $conn->insert_id;

    // 3. Criar o usuário gestor
    $senha_hash = password_hash($input['senha'], PASSWORD_DEFAULT);
    $stmt_insert_user = $conn->prepare("INSERT INTO usuarios (nome, email, cpf, senha, perfil, status) VALUES (?, ?, ?, ?, 'Gestor', 'Ativo')");
    $stmt_insert_user->bind_param("ssss", $input['nome_gestor'], $input['email_gestor'], $input['cpf_gestor'], $senha_hash);
    $stmt_insert_user->execute();
    $id_usuario = $conn->insert_id;

    // Se tudo deu certo, efetiva as mudanças no banco
    $conn->commit();

    echo json_encode([
        'success' => true, 
        'message' => 'Unidade criada com sucesso! O gestor pode fazer login com suas credenciais.',
        'unidade_id' => $id_unidade,
        'gestor_email' => $input['email_gestor']
    ]);

} catch (Exception $e) {
    // Se algo deu errado, desfaz todas as operações
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
?>