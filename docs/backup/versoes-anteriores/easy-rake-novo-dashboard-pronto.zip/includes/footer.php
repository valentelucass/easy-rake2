<!-- FOOTER EASY RAKE -->
<link rel="stylesheet" href="css/components/_footer.css">
<footer class="footer">
    <div class="footer__container">
        <span>&copy; <?php echo date('Y'); ?> Easy Rake. Todos os direitos reservados.</span>
    </div>
</footer> 