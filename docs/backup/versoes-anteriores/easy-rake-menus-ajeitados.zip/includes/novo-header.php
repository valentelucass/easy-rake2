<!-- NOVO HEADER/MENU FIXO EASY RAKE -->
<link rel="stylesheet" href="css/components/novo-header.css">
<header class="novo-header">
    <div class="novo-header__container">
        <div class="novo-header__logo">EASY RAKE</div>
        <nav class="novo-header__nav">
            <a href="abrir-caixa.php" class="novo-header__link">Abrir Caixa</a>
            <a href="relatorios.php" class="novo-header__link">Relatórios</a>
            <a href="jogadores.php" class="novo-header__link">Jogadores</a>
            <a href="aprovacoes.php" class="novo-header__link">Aprovações</a>
        </nav>
        <div class="novo-header__user">
            <button class="novo-header__logout" onclick="window.location.href='api/auth/logout.php'">Sair</button>
        </div>
        <button class="novo-header__menu-btn" id="novoMenuBtn" aria-label="Abrir menu">&#9776;</button>
    </div>
    <nav class="novo-header__nav-mobile" id="novoNavMobile">
        <a href="abrir-caixa.php" class="novo-header__link">Abrir Caixa</a>
        <a href="relatorios.php" class="novo-header__link">Relatórios</a>
        <a href="jogadores.php" class="novo-header__link">Jogadores</a>
        <a href="aprovacoes.php" class="novo-header__link">Aprovações</a>
        <button class="novo-header__logout-mobile" onclick="window.location.href='api/auth/logout.php'">Sair</button>
    </nav>
</header>
<script src="js/features/novo-header.js"></script> 