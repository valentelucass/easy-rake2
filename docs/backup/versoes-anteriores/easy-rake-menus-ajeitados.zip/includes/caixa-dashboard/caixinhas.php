<div class="caixa-dashboard-tab-content">
    <h2>Caixinhas</h2>
    <p>Conteúdo da aba Caixinhas.</p>
</div> 