<div class="caixa-dashboard-tab-content">
    <!-- Resumo Financeiro -->
    <section class="caixa-dashboard-section">
        <h3>Resumo Financeiro</h3>
        <div class="caixa-dashboard-resumo">
            <div class="resumo-card">
                <span class="resumo-label">INVENTÁRIO DE ABERTURA (FICHAS)</span>
                <span class="resumo-valor">R$ 34.234,00</span>
            </div>
            <div class="resumo-card">
                <span class="resumo-label">TOTAL RECEITAS</span>
                <span class="resumo-valor green">R$ 0,00</span>
            </div>
            <div class="resumo-card">
                <span class="resumo-label">TOTAL DESPESAS</span>
                <span class="resumo-valor red">R$ 0,00</span>
            </div>
            <div class="resumo-card">
                <span class="resumo-label">SALDO ATUAL</span>
                <span class="resumo-valor red">R$ 0,00</span>
            </div>
        </div>
    </section>

    <!-- Ações de Fechamento -->
    <section class="caixa-dashboard-section">
        <h3>Ações de Fechamento</h3>
        <div class="caixa-dashboard-acoes">
            <div class="acao-card">
                <h4>Encerrar Caixa</h4>
                <p>Finaliza o caixa e registra o fechamento no sistema.</p>
                <button class="btn btn-danger">ENCERRAR CAIXA</button>
            </div>
            <div class="acao-card">
                <h4>Exportar Relatórios</h4>
                <p>Gere relatórios em PDF e Excel com todos os dados do caixa.</p>
                <button class="btn btn-secondary">PDF</button>
                <button class="btn btn-secondary">EXCEL</button>
            </div>
        </div>
    </section>

    <!-- Compilação de Dados de Caixa -->
    <section class="caixa-dashboard-section">
        <h3>Compilação de Dados de Caixa</h3>
        <div class="caixa-dashboard-compilacao">
            <button class="btn btn-primary" style="float:right; margin-bottom:10px;">ATUALIZAR</button>
            <table class="caixa-dashboard-table">
                <thead>
                    <tr>
                        <th>DATA</th>
                        <th>TIPO</th>
                        <th>DESCRIÇÃO</th>
                        <th>VALOR (R$)</th>
                        <th>OPERADOR</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Exemplo de dados -->
                </tbody>
            </table>
            <div class="caixa-dashboard-totais">
                <div>Total de Receitas: R$ 0,00</div>
                <div>Total de Despesas: R$ 0,00</div>
                <div>Saldo Final: R$ 34.234,00</div>
            </div>
        </div>
    </section>

    <!-- Status do Caixa -->
    <section class="caixa-dashboard-section">
        <h3>Status do Caixa</h3>
        <div class="caixa-dashboard-status">
            <div class="status-card">
                <span class="status-label">Status:</span>
                <span class="status-value status-aberto">ABERTO</span>
            </div>
            <div class="status-card">
                <span class="status-label">Operador:</span>
                <span class="status-value">lucas mateus andrade de costa</span>
            </div>
            <div class="status-card">
                <span class="status-label">Data de Abertura:</span>
                <span class="status-value">09/07/2025, 03:24:08</span>
            </div>
            <div class="status-card">
                <span class="status-label">Tempo Aberto:</span>
                <span class="status-value">~3h-60min</span>
            </div>
        </div>
    </section>
</div> 