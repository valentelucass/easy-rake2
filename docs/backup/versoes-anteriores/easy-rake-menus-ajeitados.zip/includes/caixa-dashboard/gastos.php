<div class="caixa-dashboard-tab-content">
    <h2>Gastos</h2>
    <p>Conteúdo da aba Gastos.</p>
</div> 