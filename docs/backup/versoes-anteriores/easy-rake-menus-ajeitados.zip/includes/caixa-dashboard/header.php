<?php global $id_caixa; ?>
<link rel="stylesheet" href="css/components/novo-header.css">
<header class="caixa-dashboard-header">
    <div class="caixa-dashboard-header__container caixa-dashboard-header__container--inline" style="align-items: center; padding-left: 1.2rem; gap: 2.5rem;">
        <a href="/easy-rake/abrir-caixa.php" class="caixa-dashboard-header__logo-link" style="display:flex;align-items:center;text-decoration:none;">
            <img src="css/images/logomarca.png" alt="Logo" class="caixa-dashboard-header__logo-img logo-grande">
        </a>
        <?php $tab = isset($_GET['tab']) ? $_GET['tab'] : 'fechamento'; ?>
        <nav class="caixa-dashboard-menu" style="flex:1;display:flex;justify-content:center;align-items:center;gap:2.5rem;">
            <a href="?id=<?php echo $id_caixa; ?>&tab=fechamento" class="tab-btn<?php echo $tab === 'fechamento' ? ' active' : ''; ?>">Fechamento</a>
            <a href="?id=<?php echo $id_caixa; ?>&tab=fichas" class="tab-btn<?php echo $tab === 'fichas' ? ' active' : ''; ?>">Fichas</a>
            <a href="?id=<?php echo $id_caixa; ?>&tab=rake" class="tab-btn<?php echo $tab === 'rake' ? ' active' : ''; ?>">Rake</a>
            <a href="?id=<?php echo $id_caixa; ?>&tab=caixinhas" class="tab-btn<?php echo $tab === 'caixinhas' ? ' active' : ''; ?>">Caixinhas</a>
            <a href="?id=<?php echo $id_caixa; ?>&tab=gastos" class="tab-btn<?php echo $tab === 'gastos' ? ' active' : ''; ?>">Gastos</a>
            <a href="?id=<?php echo $id_caixa; ?>&tab=jogadores" class="tab-btn<?php echo $tab === 'jogadores' ? ' active' : ''; ?>">Jogadores</a>
            <a href="?id=<?php echo $id_caixa; ?>&tab=inventario" class="tab-btn<?php echo $tab === 'inventario' ? ' active' : ''; ?>">Inventário</a>
        </nav>
    </div>
</header> 