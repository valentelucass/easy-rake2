<div class="caixa-dashboard-tab-content">
    <h2>Inventário</h2>
    <p>Conteúdo da aba Inventário.</p>
</div> 