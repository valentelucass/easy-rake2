<link rel="stylesheet" href="css/components/novo-footer.css">
<footer class="novo-footer">
    <div class="novo-footer__container">
        <span>&copy; 2025 Easy Rake. Todos os direitos reservados.</span>
    </div>
</footer> 