<div class="caixa-dashboard-tab-content">
    <h2>Fichas</h2>
    <p>Conteúdo da aba Fichas.</p>
</div> 