<div class="caixa-dashboard-tab-content">
    <h2>Rake</h2>
    <p>Conteúdo da aba Rake.</p>
</div> 