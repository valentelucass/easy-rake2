<div class="caixa-dashboard-tab-content">
    <h2>Jogadores</h2>
    <p>Conteúdo da aba Jogadores.</p>
</div> 