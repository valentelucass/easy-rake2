<?php
session_start();
$id_caixa = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$id_caixa) {
    echo '<h2>Caixa não encontrado.</h2>';
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard do Caixa #<?php echo $id_caixa; ?> | EASY RAKE</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/components/_header.css">
    <link rel="stylesheet" href="css/pages/_dashboard.css">
    <link rel="stylesheet" href="css/pages/_caixa-dashboard.css">
    <link rel="stylesheet" href="css/pages/_fechamento.css">
    <link rel="stylesheet" href="css/components/_buttons.css">
</head>
<body>
    <div class="app-container">
        <?php include 'includes/caixa-dashboard/header.php'; ?>
        <main id="main-content" class="dashboard-main">
            <div class="content-container">
                <?php
                $tab = isset($_GET['tab']) ? $_GET['tab'] : 'fechamento';
                $abas_validas = [
                    'fechamento',
                    'fichas',
                    'rake',
                    'caixinhas',
                    'gastos',
                    'jogadores',
                    'inventario'
                ];
                if (!in_array($tab, $abas_validas)) {
                    $tab = 'fechamento';
                }
                include "includes/caixa-dashboard/{$tab}.php";
                ?>
            </div>
        </main>
        <?php include 'includes/caixa-dashboard/footer.php'; ?>
    </div>

    <script>
    window.CAIXA_ID = <?php echo $id_caixa; ?>;
    </script>
    <script src="js/features/caixa-dashboard/caixa-aberto-dashboard.js"></script>
    <script src="js/features/caixa-dashboard/fechamento.js"></script>
    <script src="js/features/notifications.js"></script>
</body>
</html> 