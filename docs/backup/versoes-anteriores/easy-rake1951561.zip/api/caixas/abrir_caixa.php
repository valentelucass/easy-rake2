<?php
// Inicia a sessão
session_start();

// Define o cabeçalho de resposta para JSON
header('Content-Type: application/json');

// Verifica se o usuário está logado
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit;
}

// Inclui a conexão com o banco de dados
require_once '../db_connect.php';
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]));
}

// Pega os dados JSON enviados pelo JavaScript
$input = json_decode(file_get_contents('php://input'), true);

$valor_inicial = $input['valor_inicial'] ?? 0;
$observacoes = $input['observacoes'] ?? '';
$operador_id = $_SESSION['user_id'];

// Validação básica
if (empty($valor_inicial) || $valor_inicial <= 0) {
    echo json_encode(['success' => false, 'message' => 'Valor inicial é obrigatório e deve ser maior que zero.']);
    exit;
}

try {
    $conn->begin_transaction();
    
    // Verifica se já existe um caixa aberto para este operador
    $checkStmt = $conn->prepare("SELECT id FROM caixas WHERE operador_id = ? AND status = 'Aberto'");
    $checkStmt->bind_param("i", $operador_id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Você já possui um caixa aberto.']);
        $checkStmt->close();
        exit;
    }
    $checkStmt->close();

    // Define o status inicial baseado no valor
    $status_inicial = 'Aberto';
    $precisa_aprovacao = false;
    
    // Se o valor inicial for maior que R$ 5000, precisa de aprovação
    if ($valor_inicial > 5000.00) {
        $status_inicial = 'Pendente';
        $precisa_aprovacao = true;
    }

    // Prepara a query para inserir o novo caixa
    $stmt = $conn->prepare("INSERT INTO caixas (operador_id, valor_inicial, observacoes, status, data_abertura) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("idss", $operador_id, $valor_inicial, $observacoes, $status_inicial);
    
    if ($stmt->execute()) {
        $caixa_id = $conn->insert_id;
        
        // Se precisa de aprovação, criar registro na tabela de aprovações
        if ($precisa_aprovacao) {
            $observacoes_aprov = "Abertura de caixa com valor alto: R$ " . number_format($valor_inicial, 2, ',', '.');
            if (!empty($observacoes)) {
                $observacoes_aprov .= " | Observações: " . $observacoes;
            }
            
            $stmt_aprov = $conn->prepare('INSERT INTO aprovacoes (tipo, referencia_id, solicitante_id, status, observacoes) VALUES (?, ?, ?, ?, ?)');
            $stmt_aprov->bind_param('siiss', 'Caixa', $caixa_id, $operador_id, 'Pendente', $observacoes_aprov);
            $stmt_aprov->execute();
            $stmt_aprov->close();
            
            $mensagem = 'Caixa aberto com sucesso! Solicitação de aprovação enviada para o gestor devido ao valor alto.';
        } else {
            $mensagem = 'Caixa aberto com sucesso!';
        }
        
        $conn->commit();
        
        echo json_encode([
            'success' => true, 
            'message' => $mensagem,
            'caixa_id' => $caixa_id,
            'valor_inicial' => $valor_inicial,
            'precisa_aprovacao' => $precisa_aprovacao
        ]);
    } else {
        throw new Exception('Erro ao abrir caixa.');
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor: ' . $e->getMessage()]);
}

$conn->close();
?>