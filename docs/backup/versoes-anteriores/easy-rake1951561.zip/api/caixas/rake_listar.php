<?php
session_start();
header('Content-Type: application/json');
require_once '../db_connect.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['perfil'] ?? '', ['Gestor', 'Caixa'])) {
    echo json_encode(['success' => false, 'message' => 'Acesso negado.']);
    exit;
}

$caixa_id = isset($_GET['caixa_id']) ? intval($_GET['caixa_id']) : 0;
if ($caixa_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID do caixa inválido.']);
    exit;
}

// VERIFICAÇÃO DE SEGURANÇA - OBRIGATÓRIA
// Verificar se o caixa pertence ao usuário logado
$stmt = $conn->prepare('SELECT operador_id FROM caixas WHERE id = ?');
$stmt->bind_param('i', $caixa_id);
$stmt->execute();
$result = $stmt->get_result();
$caixa_check = $result->fetch_assoc();

if (!$caixa_check || $caixa_check['operador_id'] != $_SESSION['user_id']) {
    echo json_encode(['success' => false, 'message' => 'Acesso negado. Este caixa não pertence a você.']);
    exit;
}
$stmt->close();

$sql = "SELECT valor, data_hora, usuario_nome FROM rake WHERE caixa_id = ? ORDER BY data_hora DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $caixa_id);
$stmt->execute();
$res = $stmt->get_result();
$registros = [];
while ($row = $res->fetch_assoc()) {
    $row['data_hora_formatada'] = date('d/m/Y H:i', strtotime($row['data_hora']));
    $registros[] = $row;
}
$stmt->close();

echo json_encode(['success' => true, 'registros' => $registros]);
?> 