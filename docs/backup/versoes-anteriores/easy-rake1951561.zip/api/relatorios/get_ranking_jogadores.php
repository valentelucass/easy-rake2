<?php
require_once __DIR__ . '/../db_connect.php';
header('Content-Type: application/json');

try {
    $sql = "SELECT j.nome, j.cpf, SUM(tj.valor) as total_movimentado
            FROM transacoes_jogadores tj
            JOIN jogadores j ON tj.jogador_id = j.id
            GROUP BY tj.jogador_id
            ORDER BY total_movimentado DESC
            LIMIT 10";
    $result = $conn->query($sql);
    $ranking = [];
    while ($row = $result->fetch_assoc()) {
        $ranking[] = [
            'nome' => $row['nome'],
            'cpf' => $row['cpf'],
            'total_movimentado' => (float)$row['total_movimentado']
        ];
    }
    echo json_encode([
        'success' => true,
        'ranking' => $ranking
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar ranking de jogadores: ' . $e->getMessage()
    ]);
}
$conn->close(); 