<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit;
}

require_once '../db_connect.php';
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]));
}

$data = json_decode(file_get_contents('php://input'), true);
$nome = htmlspecialchars(trim($data['nome'] ?? ''));
$cpf = htmlspecialchars(trim($data['cpf'] ?? ''));
$telefone = htmlspecialchars(trim($data['telefone'] ?? ''));
$limite_credito = isset($data['limite_credito']) ? floatval($data['limite_credito']) : 0.00;

// Função simples para validar CPF (formato ###.###.###-##)
function validarCPF($cpf) {
    return preg_match('/^\d{3}\.\d{3}\.\d{3}-\d{2}$/', $cpf);
}

if (empty($nome) || empty($cpf)) {
    echo json_encode(['success' => false, 'message' => 'Nome e CPF são obrigatórios.']);
    exit;
}
if (!validarCPF($cpf)) {
    echo json_encode(['success' => false, 'message' => 'CPF em formato inválido.']);
    exit;
}

// Verifica se o CPF já existe
$stmt = $conn->prepare('SELECT id FROM jogadores WHERE cpf = ?');
$stmt->bind_param('s', $cpf);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'CPF já cadastrado.']);
    $stmt->close();
    exit;
}
$stmt->close();

// Buscar unidade do usuário logado
$stmt = $conn->prepare('SELECT id_unidade FROM associacoes_usuario_unidade WHERE id_usuario = ? AND status_aprovacao = "Aprovado" LIMIT 1');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($unidade_id);
if (!$stmt->fetch() || !$unidade_id) {
    echo json_encode(['success' => false, 'message' => 'Usuário não está associado a nenhuma unidade aprovada.']);
    $stmt->close();
    exit;
}
$stmt->close();

try {
    $conn->begin_transaction();
    
    // Define o status inicial baseado no limite de crédito
    $status_inicial = 'Ativo';
    $precisa_aprovacao = false;
    
    // Se o limite de crédito for maior que R$ 1000, precisa de aprovação
    if ($limite_credito > 1000.00) {
        $status_inicial = 'Pendente';
        $precisa_aprovacao = true;
    }
    
    // Insere o novo jogador
    $stmt = $conn->prepare('INSERT INTO jogadores (nome, cpf, telefone, limite_credito, saldo_atual, status, unidade_id) VALUES (?, ?, ?, ?, 0.00, ?, ?)');
    $stmt->bind_param('sssdis', $nome, $cpf, $telefone, $limite_credito, $status_inicial, $unidade_id);
    
    if ($stmt->execute()) {
        $jogador_id = $conn->insert_id;
        
        // Se precisa de aprovação, criar registro na tabela de aprovações
        if ($precisa_aprovacao) {
            $observacoes = "Jogador com limite de crédito alto: R$ " . number_format($limite_credito, 2, ',', '.');
            $stmt_aprov = $conn->prepare('INSERT INTO aprovacoes (tipo, referencia_id, solicitante_id, status, observacoes) VALUES (?, ?, ?, ?, ?)');
            $stmt_aprov->bind_param('siiss', 'Jogador', $jogador_id, $_SESSION['user_id'], 'Pendente', $observacoes);
            $stmt_aprov->execute();
            $stmt_aprov->close();
            
            $mensagem = 'Jogador cadastrado com sucesso! Solicitação de aprovação enviada para o gestor devido ao limite de crédito alto.';
        } else {
            $mensagem = 'Jogador cadastrado com sucesso!';
        }
        
        $conn->commit();
        echo json_encode(['success' => true, 'message' => $mensagem, 'precisa_aprovacao' => $precisa_aprovacao]);
    } else {
        throw new Exception('Erro ao cadastrar jogador.');
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Erro ao cadastrar jogador: ' . $e->getMessage()]);
}

$conn->close();
exit;
?>