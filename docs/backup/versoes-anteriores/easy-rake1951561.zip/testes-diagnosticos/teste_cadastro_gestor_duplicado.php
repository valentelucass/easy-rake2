<?php
// Teste: tentar cadastrar um segundo gestor na mesma unidade

$url = 'http://localhost/easy-rake/api/usuarios/registrar_funcionario.php';

$data = [
    'codigo_acesso' => 'BA8671B6', // Código de acesso correto da Unidade Teste A
    'nome_completo' => 'Gestor Duplicado',
    'cpf' => '55555555555',
    'senha' => '123456',
    'confirmar_senha' => '123456',
    'tipo_usuario' => 'gestor'
];

$options = [
    'http' => [
        'header'  => "Content-type: application/json\r\n",
        'method'  => 'POST',
        'content' => json_encode($data),
    ],
];
$context  = stream_context_create($options);
$result = file_get_contents($url, false, $context);
echo $result;
?> 