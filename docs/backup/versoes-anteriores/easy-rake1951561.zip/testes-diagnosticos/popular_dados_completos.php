<?php
require_once __DIR__ . '/../api/db_connect.php';
header('Content-Type: text/plain; charset=utf-8');
echo "POPULAÇÃO DE DADOS DE TESTE COMPLETOS\n";

// Limpar dados de teste anteriores
$conn->query("DELETE FROM caixinhas_inclusoes WHERE caixinha_id IN (SELECT id FROM caixinhas WHERE caixa_id IN (SELECT id FROM caixas WHERE operador_id IN (SELECT id FROM usuarios WHERE nome LIKE '%TESTE%')))");
$conn->query("DELETE FROM caixinhas WHERE caixa_id IN (SELECT id FROM caixas WHERE operador_id IN (SELECT id FROM usuarios WHERE nome LIKE '%TESTE%'))");
$conn->query("DELETE FROM gastos WHERE caixa_id IN (SELECT id FROM caixas WHERE operador_id IN (SELECT id FROM usuarios WHERE nome LIKE '%TESTE%'))");
$conn->query("DELETE FROM caixas WHERE operador_id IN (SELECT id FROM usuarios WHERE nome LIKE '%TESTE%')");
$conn->query("DELETE FROM jogadores WHERE nome LIKE '%TESTE%'");
$conn->query("DELETE FROM associacoes_usuario_unidade WHERE id_usuario IN (SELECT id FROM usuarios WHERE nome LIKE '%TESTE%')");
$conn->query("DELETE FROM usuarios WHERE nome LIKE '%TESTE%'");
$conn->query("DELETE FROM unidades WHERE nome LIKE '%TESTE%'");
echo "Dados de teste anteriores removidos.\n";

// 1. Criar unidades
$unidades = [
    ['nome' => 'Unidade Teste A', 'telefone' => '11999999999'],
    ['nome' => 'Unidade Teste B', 'telefone' => '11888888888']
];
foreach ($unidades as $unidade) {
    $codigo = strtoupper(substr(md5($unidade['nome'] . time()), 0, 8));
    $stmt = $conn->prepare("INSERT INTO unidades (nome, telefone, codigo_acesso) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $unidade['nome'], $unidade['telefone'], $codigo);
    $stmt->execute();
    echo "Unidade criada: {$unidade['nome']} (Código: $codigo)\n";
}

// 2. Criar usuários (gestores e caixas)
$usuarios = [
    ['nome' => 'Gestor Teste A', 'cpf' => '111.111.111-11', 'tipo' => 'gestor', 'perfil' => 'Gestor'],
    ['nome' => 'Caixa Teste A', 'cpf' => '222.222.222-22', 'tipo' => 'caixa', 'perfil' => 'Caixa'],
    ['nome' => 'Gestor Teste B', 'cpf' => '333.333.333-33', 'tipo' => 'gestor', 'perfil' => 'Gestor'],
    ['nome' => 'Caixa Teste B', 'cpf' => '444.444.444-44', 'tipo' => 'caixa', 'perfil' => 'Caixa']
];
foreach ($usuarios as $usuario) {
    $senha_hash = password_hash('123456', PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, cpf, senha, tipo_usuario, perfil, status) VALUES (?, ?, ?, ?, ?, 'Ativo')");
    $stmt->bind_param("sssss", $usuario['nome'], $usuario['cpf'], $senha_hash, $usuario['tipo'], $usuario['perfil']);
    $stmt->execute();
    echo "Usuário criado: {$usuario['nome']}\n";
}

// 3. Associar usuários às unidades
$associacoes = [
    ['usuario' => 'Gestor Teste A', 'unidade' => 'Unidade Teste A'],
    ['usuario' => 'Caixa Teste A', 'unidade' => 'Unidade Teste A'],
    ['usuario' => 'Gestor Teste B', 'unidade' => 'Unidade Teste B'],
    ['usuario' => 'Caixa Teste B', 'unidade' => 'Unidade Teste B']
];
foreach ($associacoes as $assoc) {
    $stmt = $conn->prepare("
        INSERT INTO associacoes_usuario_unidade (id_usuario, id_unidade, senha_hash, perfil, status_aprovacao) 
        SELECT u.id, un.id, u.senha, ?, 'Aprovado'
        FROM usuarios u, unidades un 
        WHERE u.nome = ? AND un.nome = ?
    ");
    $perfil = strpos($assoc['usuario'], 'Gestor') !== false ? 'Gestor' : 'Caixa';
    $stmt->bind_param("sss", $perfil, $assoc['usuario'], $assoc['unidade']);
    $stmt->execute();
    echo "Associação criada: {$assoc['usuario']} → {$assoc['unidade']}\n";
}

// 4. Criar jogadores para cada unidade
$jogadores_unidade_a = [
    ['nome' => 'João Silva TESTE', 'cpf' => '555.555.555-55', 'telefone' => '11555555555'],
    ['nome' => 'Maria Santos TESTE', 'cpf' => '666.666.666-66', 'telefone' => '11666666666']
];
$jogadores_unidade_b = [
    ['nome' => 'Pedro Costa TESTE', 'cpf' => '777.777.777-77', 'telefone' => '11777777777'],
    ['nome' => 'Ana Lima TESTE', 'cpf' => '888.888.888-88', 'telefone' => '11888888888']
];
// Buscar ID das unidades
$stmt = $conn->prepare("SELECT id FROM unidades WHERE nome = 'Unidade Teste A'");
$stmt->execute();
$result = $stmt->get_result();
$unidade_a_id = $result->fetch_assoc()['id'];
$stmt = $conn->prepare("SELECT id FROM unidades WHERE nome = 'Unidade Teste B'");
$stmt->execute();
$result = $stmt->get_result();
$unidade_b_id = $result->fetch_assoc()['id'];
foreach ($jogadores_unidade_a as $jogador) {
    $stmt = $conn->prepare("INSERT INTO jogadores (nome, cpf, telefone, unidade_id, status) VALUES (?, ?, ?, ?, 'Ativo')");
    $stmt->bind_param("sssi", $jogador['nome'], $jogador['cpf'], $jogador['telefone'], $unidade_a_id);
    $stmt->execute();
    echo "Jogador criado (Unidade A): {$jogador['nome']}\n";
}
foreach ($jogadores_unidade_b as $jogador) {
    $stmt = $conn->prepare("INSERT INTO jogadores (nome, cpf, telefone, unidade_id, status) VALUES (?, ?, ?, ?, 'Ativo')");
    $stmt->bind_param("sssi", $jogador['nome'], $jogador['cpf'], $jogador['telefone'], $unidade_b_id);
    $stmt->execute();
    echo "Jogador criado (Unidade B): {$jogador['nome']}\n";
}

// 5. Criar caixas abertos
$caixas = [
    ['operador' => 'Caixa Teste A', 'valor' => 1000.00],
    ['operador' => 'Caixa Teste B', 'valor' => 1500.00]
];
foreach ($caixas as $caixa) {
    $stmt = $conn->prepare("
        INSERT INTO caixas (operador_id, valor_inicial, status) 
        SELECT id, ?, 'Aberto' FROM usuarios WHERE nome = ?
    ");
    $stmt->bind_param("ds", $caixa['valor'], $caixa['operador']);
    $stmt->execute();
    echo "Caixa aberto: {$caixa['operador']} (R$ {$caixa['valor']})\n";
}
// Buscar IDs dos caixas
$stmt = $conn->prepare("SELECT c.id, u.nome FROM caixas c INNER JOIN usuarios u ON c.operador_id = u.id WHERE c.status = 'Aberto'");
$stmt->execute();
$result = $stmt->get_result();
$caixas_ids = [];
while ($row = $result->fetch_assoc()) {
    $caixas_ids[$row['nome']] = $row['id'];
}

// 6. Criar gastos em cada caixa
$gastos = [
    ['desc' => 'Bebida TESTE', 'valor' => 10.00, 'operador' => 'Caixa Teste A'],
    ['desc' => 'Comida TESTE', 'valor' => 20.00, 'operador' => 'Caixa Teste A'],
    ['desc' => 'Material TESTE', 'valor' => 15.00, 'operador' => 'Caixa Teste B']
];
foreach ($gastos as $gasto) {
    $caixa_id = $caixas_ids[$gasto['operador']];
    $stmt = $conn->prepare("INSERT INTO gastos (caixa_id, descricao, valor, operador_id) SELECT ?, ?, ?, id FROM usuarios WHERE nome = ?");
    $stmt->bind_param("isds", $caixa_id, $gasto['desc'], $gasto['valor'], $gasto['operador']);
    $stmt->execute();
    echo "Gasto registrado: {$gasto['desc']} (R$ {$gasto['valor']}) no {$gasto['operador']}\n";
}

// 7. Criar caixinhas e inclusões
$caixinhas = [
    ['nome' => 'Caixinha Domingo TESTE', 'cashback' => 10, 'participantes' => 5, 'operador' => 'Caixa Teste A'],
    ['nome' => 'Caixinha Segunda TESTE', 'cashback' => 15, 'participantes' => 3, 'operador' => 'Caixa Teste B']
];
foreach ($caixinhas as $caixinha) {
    $caixa_id = $caixas_ids[$caixinha['operador']];
    $stmt = $conn->prepare("INSERT INTO caixinhas (caixa_id, nome, cashback_percent, participantes, status) VALUES (?, ?, ?, ?, 'Ativo')");
    $stmt->bind_param("isii", $caixa_id, $caixinha['nome'], $caixinha['cashback'], $caixinha['participantes']);
    $stmt->execute();
    $caixinha_id = $conn->insert_id;
    echo "Caixinha criada: {$caixinha['nome']} no {$caixinha['operador']}\n";
    // Incluir valor
    $stmt2 = $conn->prepare("INSERT INTO caixinhas_inclusoes (caixinha_id, valor, usuario_id, operador_id) SELECT ?, 50.00, id, id FROM usuarios WHERE nome = ?");
    $stmt2->bind_param("is", $caixinha_id, $caixinha['operador']);
    $stmt2->execute();
    echo "Inclusão de valor feita na caixinha: {$caixinha['nome']}\n";
}

echo "\nPopulação concluída com sucesso!\n"; 