<?php
require_once 'api/db_connect.php';

header('Content-Type: text/html; charset=utf-8');
echo '<h2>Códigos de Acesso das Unidades</h2>';

try {
    $result = $conn->query("SELECT id, nome, codigo_acesso, status FROM unidades");
    if ($result->num_rows === 0) {
        echo '<p>Nenhuma unidade cadastrada.</p>';
    } else {
        echo '<table border="1" cellpadding="6" style="border-collapse:collapse;">';
        echo '<tr><th>ID</th><th>Nome</th><th>Código de Acesso</th><th>Status</th></tr>';
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['id']) . '</td>';
            echo '<td>' . htmlspecialchars($row['nome']) . '</td>';
            echo '<td><b>' . htmlspecialchars($row['codigo_acesso']) . '</b></td>';
            echo '<td>' . htmlspecialchars($row['status']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }
} catch (Exception $e) {
    echo '<p style="color:red">Erro ao buscar códigos de acesso: ' . $e->getMessage() . '</p>';
}
$conn->close(); 