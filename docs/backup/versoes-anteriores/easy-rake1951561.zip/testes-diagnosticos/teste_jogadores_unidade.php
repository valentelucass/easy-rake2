<?php
/**
 * TESTE AVANÇADO: Integridade de jogadores/unidade
 */
require_once __DIR__ . '/../api/db_connect.php';

header('Content-Type: text/html; charset=utf-8');
echo "<h2>Teste Avançado: Integridade de jogadores/unidade</h2>";

// 1. Jogadores sem unidade_id
$result = $conn->query("SELECT id, nome FROM jogadores WHERE unidade_id IS NULL");
if ($result->num_rows > 0) {
    echo "<p style='color:red;'>❌ Jogadores sem unidade_id:</p>";
    while ($row = $result->fetch_assoc()) {
        echo "ID: {$row['id']} - {$row['nome']}<br>";
    }
} else {
    echo "<p style='color:green;'>✅ Todos os jogadores possuem unidade_id</p>";
}

// 2. Jogadores com unidade_id inválido
$result = $conn->query("SELECT j.id, j.nome, j.unidade_id FROM jogadores j LEFT JOIN unidades u ON j.unidade_id = u.id WHERE j.unidade_id IS NOT NULL AND u.id IS NULL");
if ($result->num_rows > 0) {
    echo "<p style='color:red;'>❌ Jogadores com unidade_id inválido:</p>";
    while ($row = $result->fetch_assoc()) {
        echo "ID: {$row['id']} - {$row['nome']} (unidade_id: {$row['unidade_id']})<br>";
    }
} else {
    echo "<p style='color:green;'>✅ Todos os jogadores possuem unidade_id válido</p>";
}

echo "<strong>Teste concluído.</strong>"; 