<?php
require_once __DIR__ . '/../api/db_connect.php';

echo "ESTRUTURA DA TABELA CAIXINHAS_INCLUSOES:\n";
$result = $conn->query('DESCRIBE caixinhas_inclusoes');
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . ' - ' . $row['Type'] . ' - ' . $row['Null'] . ' - ' . $row['Key'] . "\n";
}
?> 