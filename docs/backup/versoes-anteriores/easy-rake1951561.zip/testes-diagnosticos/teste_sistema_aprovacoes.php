<?php
// Script de teste para demonstrar o sistema de aprovações
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'api/db_connect.php';

echo "<h1>🧪 Teste do Sistema de Aprovações - Easy Rake</h1>";

try {
    // Limpeza prévia dos dados de teste para evitar duplicidade
    $conn->query("DELETE FROM aprovacoes WHERE observacoes LIKE '%teste%' OR observacoes LIKE '%Teste%' OR observacoes LIKE '%valor alto%'");
    // Deletar gastos e movimentações vinculados a caixas de teste antes de deletar as caixas
    $resultCaixas = $conn->query("SELECT id FROM caixas WHERE observacoes LIKE '%teste%' OR observacoes LIKE '%Teste%' OR observacoes LIKE '%valor alto%'");
    if ($resultCaixas && $resultCaixas->num_rows > 0) {
        while ($row = $resultCaixas->fetch_assoc()) {
            $caixaId = $row['id'];
            $conn->query("DELETE FROM gastos WHERE caixa_id = $caixaId");
            $conn->query("DELETE FROM movimentacoes WHERE caixa_id = $caixaId");
        }
    }
    $conn->query("DELETE FROM caixas WHERE observacoes LIKE '%teste%' OR observacoes LIKE '%Teste%' OR observacoes LIKE '%valor alto%'");
    // Deletar transações de jogadores de teste antes de deletar os jogadores
    $resultJogadores = $conn->query("SELECT id FROM jogadores WHERE nome LIKE '%Teste%' OR cpf = '123.456.789-01'");
    if ($resultJogadores && $resultJogadores->num_rows > 0) {
        while ($row = $resultJogadores->fetch_assoc()) {
            $jogadorId = $row['id'];
            $conn->query("DELETE FROM transacoes_jogadores WHERE jogador_id = $jogadorId");
        }
    }
    $conn->query("DELETE FROM jogadores WHERE nome LIKE '%Teste%' OR cpf = '123.456.789-01'");
    
    // 1. Criar dados de teste
    echo "<h2>1. Criando dados de teste...</h2>";
    
    // Inserir jogador com limite alto (deve criar aprovação)
    $nome = 'João Silva Teste';
    $cpf = '123.456.789-01';
    $telefone = '(11) 99999-9999';
    $limite = 1500.00;
    $stmt = $conn->prepare("INSERT INTO jogadores (nome, cpf, telefone, limite_credito, saldo_atual, status) VALUES (?, ?, ?, ?, 0.00, 'Pendente')");
    $stmt->bind_param('sssd', $nome, $cpf, $telefone, $limite);
    $stmt->execute();
    $jogador_id = $conn->insert_id;
    
    // Criar aprovação para o jogador
    $tipo_aprov = 'Jogador';
    $status_aprov = 'Pendente';
    $obs_aprov = 'Jogador com limite de crédito alto: R$ 1.500,00';
    $solicitante_id = 1;
    $stmt_aprov = $conn->prepare("INSERT INTO aprovacoes (tipo, referencia_id, solicitante_id, status, observacoes) VALUES (?, ?, ?, ?, ?)");
    $stmt_aprov->bind_param('siiss', $tipo_aprov, $jogador_id, $solicitante_id, $status_aprov, $obs_aprov);
    $stmt_aprov->execute();
    
    // Sempre criar uma aprovação de caixa pendente para garantir o teste
    // Inserir caixa de teste com valor alto (deve criar aprovação)
    $operador_id = 1;
    $valor_inicial = 6000.00;
    $obs_caixa = 'Caixa teste com valor alto - '.uniqid();
    $status_caixa = 'Pendente';
    $stmt_caixa = $conn->prepare("INSERT INTO caixas (operador_id, valor_inicial, observacoes, status, data_abertura) VALUES (?, ?, ?, ?, NOW())");
    $stmt_caixa->bind_param('idss', $operador_id, $valor_inicial, $obs_caixa, $status_caixa);
    $stmt_caixa->execute();
    $caixa_id = $conn->insert_id;
    
    // Criar aprovação para o caixa
    $tipo_aprov_caixa = 'Caixa';
    $status_aprov_caixa = 'Pendente';
    $obs_aprov_caixa = 'Abertura de caixa com valor alto: R$ 6.000,00';
    $stmt_aprov_caixa = $conn->prepare("INSERT INTO aprovacoes (tipo, referencia_id, solicitante_id, status, observacoes) VALUES (?, ?, ?, ?, ?)");
    $stmt_aprov_caixa->bind_param('siiss', $tipo_aprov_caixa, $caixa_id, $operador_id, $status_aprov_caixa, $obs_aprov_caixa);
    $stmt_aprov_caixa->execute();
    
    echo "✅ Dados de teste criados com sucesso!<br>";
    echo "- Jogador ID: $jogador_id (limite R$ 1.500,00)<br>";
    echo "- Caixa ID: $caixa_id (valor R$ 6.000,00)<br><br>";
    
    // Diagnóstico do usuário gestor antes de rodar o teste
    echo "<h2>Diagnóstico do usuário gestor (12924554466)</h2>";
    $cpf_gestor = '12924554466';
    $stmt = $conn->prepare("SELECT id, nome, cpf, perfil, status FROM usuarios WHERE cpf = ?");
    $stmt->bind_param('s', $cpf_gestor);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        echo "❌ Usuário gestor não encontrado no banco.<br>";
    } else {
        $user = $result->fetch_assoc();
        echo "Usuário: {$user['nome']} | Perfil: {$user['perfil']} | Status: {$user['status']}<br>";
        // Verificar associação como gestor aprovado
        $stmt2 = $conn->prepare("SELECT id, id_unidade, perfil, status_aprovacao FROM associacoes_usuario_unidade WHERE id_usuario = ? AND perfil = 'Gestor' AND status_aprovacao = 'Aprovado' LIMIT 1");
        $stmt2->bind_param('i', $user['id']);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        if ($result2->num_rows === 0) {
            echo "❌ Usuário NÃO possui associação aprovada como Gestor em nenhuma unidade.<br>";
        } else {
            $assoc = $result2->fetch_assoc();
            echo "✅ Associação encontrada: Unidade ID {$assoc['id_unidade']} | Perfil: {$assoc['perfil']} | Status: {$assoc['status_aprovacao']}<br>";
        }
        $stmt2->close();
    }
    $stmt->close();
    
    // 2. Testar API de listagem de pendentes via HTTP
    echo "<h2>2. Testando API de aprovações pendentes (HTTP)...</h2>";
    
    // Fazer login via HTTP para obter cookies de sessão (usando JSON)
    $loginUrl = 'http://localhost/easy-rake/api/auth/login.php';
    $loginData = json_encode([
        'cpf' => '12924554466', // Usuário gestor
        'senha' => '123456'   // Senha do gestor
    ]);
    $cookieFile = tempnam(sys_get_temp_dir(), 'cookie');
    $ch = curl_init($loginUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $loginData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    $loginResponse = curl_exec($ch);
    curl_close($ch);
    echo "<pre>Resposta do login: $loginResponse</pre>";
    
    // Chamar API de aprovações pendentes
    $pendentesUrl = 'http://localhost/easy-rake/api/aprovacoes_listar_pendentes.php';
    $ch = curl_init($pendentesUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    $pendentesResponse = curl_exec($ch);
    curl_close($ch);
    
    $data = json_decode($pendentesResponse, true);
    if (is_array($data) && isset($data['success']) && $data['success']) {
        echo "✅ API funcionando! Encontradas " . count($data['aprovacoes']) . " aprovações pendentes:<br>";
        foreach ($data['aprovacoes'] as $aprov) {
            echo "- ID: {$aprov['id']} | Tipo: {$aprov['tipo']} | Status: {$aprov['status']}<br>";
            if (isset($aprov['descricao'])) {
                echo "  Descrição: {$aprov['descricao']}<br>";
            }
        }
    } else {
        echo "❌ Erro na API: " . ($data['message'] ?? 'Resposta inválida ou nula') . "<br>";
    }
    
    // 3. Testar API de histórico via HTTP
    echo "<h2>3. Testando API de histórico (HTTP)...</h2>";
    $historicoUrl = 'http://localhost/easy-rake/api/aprovacoes_listar_historico.php';
    $ch = curl_init($historicoUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    $historicoResponse = curl_exec($ch);
    curl_close($ch);
    
    $data_hist = json_decode($historicoResponse, true);
    if (is_array($data_hist) && isset($data_hist['success']) && $data_hist['success']) {
        echo "✅ API de histórico funcionando! Encontrados " . count($data_hist['historico']) . " registros no histórico.<br>";
    } else {
        echo "❌ Erro na API de histórico: " . ($data_hist['message'] ?? 'Resposta inválida ou nula') . "<br>";
    }
    
    // Limpar cookie temporário
    @unlink($cookieFile);
    
    echo "<br>";
    
    // 4. Testar aprovação via HTTP
    echo "<h2>4. Testando aprovação (HTTP)...</h2>";
    // Buscar o ID da aprovação pendente criada (tipo Caixa)
    $aprovacao_id = null;
    $ch = curl_init($pendentesUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    $pendentesResponse = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($pendentesResponse, true);
    if (is_array($data) && isset($data['success']) && $data['success'] && count($data['aprovacoes']) > 0) {
        foreach ($data['aprovacoes'] as $aprov) {
            if ($aprov['tipo'] === 'Caixa' && $aprov['status'] === 'Pendente') {
                $aprovacao_id = $aprov['id'];
                break;
            }
        }
    }
    if ($aprovacao_id) {
        $acaoUrl = 'http://localhost/easy-rake/api/aprovacoes_acao.php';
        $acaoData = json_encode([
            'tipo' => 'Caixa',
            'id' => $aprovacao_id,
            'acao' => 'aprovar'
        ]);
        $ch = curl_init($acaoUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $acaoData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
        $acaoResponse = curl_exec($ch);
        curl_close($ch);
        echo "<pre>Resposta da aprovação: $acaoResponse</pre>";
    } else {
        echo "❌ Nenhuma aprovação de caixa pendente encontrada para aprovar.<br>";
    }
    
    echo "<br>";
    
    // 5. Verificar status após aprovação
    echo "<h2>5. Verificando status após aprovação...</h2>";
    
    $stmt_check = $conn->prepare("SELECT status FROM jogadores WHERE id = ?");
    $stmt_check->bind_param('i', $jogador_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    $jogador = $result->fetch_assoc();
    
    if ($jogador['status'] === 'Ativo') {
        echo "✅ Jogador ativado com sucesso após aprovação!<br>";
    } else {
        echo "❌ Jogador não foi ativado. Status atual: " . $jogador['status'] . "<br>";
    }
    
    echo "<br>";
    
    // 6. Limpeza dos dados de teste
    echo "<h2>6. Limpando dados de teste...</h2>";
    
    $conn->query("DELETE FROM aprovacoes WHERE observacoes LIKE '%teste%' OR observacoes LIKE '%Teste%'");
    $conn->query("DELETE FROM caixas WHERE observacoes LIKE '%teste%' OR observacoes LIKE '%Teste%'");
    $conn->query("DELETE FROM jogadores WHERE nome LIKE '%Teste%'");
    
    echo "✅ Dados de teste removidos!<br>";
    
    echo "<br><h2>🎉 Teste concluído com sucesso!</h2>";
    echo "<p>O sistema de aprovações está funcionando corretamente:</p>";
    echo "<ul>";
    echo "<li>✅ Criação automática de aprovações</li>";
    echo "<li>✅ Listagem de aprovações pendentes</li>";
    echo "<li>✅ Histórico de aprovações</li>";
    echo "<li>✅ Processamento de aprovações</li>";
    echo "<li>✅ Ativação automática após aprovação</li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "❌ Erro durante o teste: " . $e->getMessage();
}

$conn->close();
?>

<style>
body {
    font-family: Arial, sans-serif;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background: #f5f5f5;
}

h1 {
    color: #e11d48;
    text-align: center;
    border-bottom: 3px solid #e11d48;
    padding-bottom: 10px;
}

h2 {
    color: #333;
    background: #fff;
    padding: 10px;
    border-radius: 5px;
    border-left: 4px solid #e11d48;
}

ul {
    background: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

li {
    margin: 5px 0;
    padding: 5px 0;
}
</style> 