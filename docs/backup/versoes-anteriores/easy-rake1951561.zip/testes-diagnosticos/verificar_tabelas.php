<?php
require_once __DIR__ . '/../api/db_connect.php';

echo "TABELAS NO BANCO:\n";
$result = $conn->query('SHOW TABLES');
while ($row = $result->fetch_array()) {
    echo $row[0] . "\n";
}

echo "\nVERIFICANDO TABELA CAIXINHAS_INCLUSOES:\n";
$result = $conn->query('SHOW TABLES LIKE "caixinhas_inclusoes"');
if ($result->num_rows > 0) {
    echo "Tabela caixinhas_inclusoes existe\n";
    $result = $conn->query('DESCRIBE caixinhas_inclusoes');
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . ' - ' . $row['Type'] . ' - ' . $row['Null'] . ' - ' . $row['Key'] . "\n";
    }
} else {
    echo "Tabela caixinhas_inclusoes NÃO existe\n";
}
?> 