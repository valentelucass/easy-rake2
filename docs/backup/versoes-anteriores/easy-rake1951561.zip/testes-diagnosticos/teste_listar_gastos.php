<?php
require_once __DIR__ . '/../api/db_connect.php';
header('Content-Type: text/plain; charset=utf-8');
echo "TESTE: Listagem de Gastos\n";

// Buscar um caixa aberto
$res = $conn->query("SELECT id FROM caixas WHERE status = 'Aberto' LIMIT 1");
if ($row = $res->fetch_assoc()) {
    $caixa_id = $row['id'];
    $stmt = $conn->prepare("SELECT g.*, u.nome as operador FROM gastos g LEFT JOIN usuarios u ON g.operador_id = u.id WHERE g.caixa_id = ? ORDER BY g.data_registro DESC");
    $stmt->bind_param('i', $caixa_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $total = 0;
    while ($gasto = $result->fetch_assoc()) {
        echo "ID: {$gasto['id']} | Desc: {$gasto['descricao']} | Valor: R$ {$gasto['valor']} | Operador: {$gasto['operador']} | Data: {$gasto['data_registro']}\n";
        $total += $gasto['valor'];
    }
    echo "Total de despesas: R$ $total\n";
} else {
    echo "Nenhum caixa aberto encontrado para testar.\n";
} 