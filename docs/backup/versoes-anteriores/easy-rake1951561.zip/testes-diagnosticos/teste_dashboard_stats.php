<?php
session_start();

// Simular login como Caixa Teste A (user_id 30, perfil Caixa)
$_SESSION['logged_in'] = true;
$_SESSION['user_id'] = 30;
$_SESSION['perfil'] = 'Caixa';

chdir(__DIR__ . '/../api/dashboard');
require_once 'get_stats.php';
?> 