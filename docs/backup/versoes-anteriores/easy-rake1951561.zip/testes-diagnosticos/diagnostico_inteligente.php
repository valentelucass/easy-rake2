<?php
/**
 * 🧠 DIAGNÓSTICO INTELIGENTE - Easy Rake
 * 
 * Script avançado que analisa profundamente o sistema e fornece insights
 * valiosos para a IA assistente entender e corrigir problemas.
 * 
 * SEMPRE execute este script antes de fazer correções no sistema.
 */

require_once __DIR__ . '/../api/db_connect.php';

echo "🧠 DIAGNÓSTICO INTELIGENTE - EASY RAKE\n";
echo "=====================================\n\n";

// Verificar se a conexão foi estabelecida
if (!isset($conn) || $conn->connect_error) {
    echo "❌ ERRO: Não foi possível conectar ao banco de dados\n";
    if (isset($conn)) {
        echo "❌ Detalhes: " . $conn->connect_error . "\n";
    }
    exit;
}

echo "✅ Conexão com banco estabelecida\n";

class DiagnosticoInteligente {
    private $conn;
    private $problemas = [];
    private $recomendacoes = [];
    private $metricas = [];
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function executarDiagnosticoCompleto() {
        echo "🔍 INICIANDO ANÁLISE PROFUNDA DO SISTEMA...\n\n";
        
        $this->verificarConectividade();
        $this->analisarEstruturaBanco();
        $this->verificarIntegridadeDados();
        $this->analisarSistemaAprovacoes();
        $this->verificarConsistenciaDashboard();
        $this->analisarPerformance();
        $this->verificarSeguranca();
        $this->gerarRelatorio();
    }
    
    private function verificarConectividade() {
        echo "1. 🔌 VERIFICANDO CONECTIVIDADE...\n";
        
        if ($this->conn->connect_error) {
            $this->problemas[] = "❌ Conexão MySQL falhou: " . $this->conn->connect_error;
            return;
        }
        
        echo "✅ Conexão MySQL OK (Porta 3307)\n";
        echo "✅ Charset: " . $this->conn->character_set_name() . "\n";
        $this->metricas['conectividade'] = 'OK';
    }
    
    private function analisarEstruturaBanco() {
        echo "\n2. 🗄️ ANALISANDO ESTRUTURA DO BANCO...\n";
        
        $tabelas_criticas = [
            'usuarios', 'unidades', 'associacoes_usuario_unidade', 
            'aprovacoes', 'caixas', 'jogadores', 'transacoes_jogadores',
            'movimentacoes', 'gastos', 'rake', 'caixinhas_inclusoes'
        ];
        
        foreach ($tabelas_criticas as $tabela) {
            try {
                $result = $this->conn->query("SHOW TABLES LIKE '$tabela'");
                if ($result && $result->num_rows > 0) {
                    echo "✅ Tabela '$tabela' existe\n";
                    
                    // Contar registros
                    $count_result = $this->conn->query("SELECT COUNT(*) as total FROM $tabela");
                    if ($count_result) {
                        $count = $count_result->fetch_assoc()['total'];
                        echo "   📊 Registros: $count\n";
                        $this->metricas[$tabela . '_registros'] = $count;
                    } else {
                        echo "   ⚠️  Erro ao contar registros\n";
                    }
                } else {
                    echo "❌ Tabela '$tabela' NÃO EXISTE\n";
                    $this->problemas[] = "Tabela crítica '$tabela' não encontrada";
                }
            } catch (Exception $e) {
                echo "❌ Erro ao verificar tabela '$tabela': " . $e->getMessage() . "\n";
                $this->problemas[] = "Erro ao verificar tabela '$tabela'";
            }
        }
    }
    
    private function verificarIntegridadeDados() {
        echo "\n3. 🔗 VERIFICANDO INTEGRIDADE DOS DADOS...\n";
        
        try {
            // Verificar usuários sem associação
            $sql = "SELECT COUNT(*) as total FROM usuarios u 
                    LEFT JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario 
                    WHERE aau.id IS NULL";
            $result = $this->conn->query($sql);
            if ($result) {
                $usuarios_sem_assoc = $result->fetch_assoc()['total'];
                
                if ($usuarios_sem_assoc > 0) {
                    echo "⚠️  $usuarios_sem_assoc usuários sem associação a unidades\n";
                    $this->recomendacoes[] = "Verificar usuários sem associação: $usuarios_sem_assoc";
                } else {
                    echo "✅ Todos os usuários têm associação\n";
                }
            } else {
                echo "⚠️  Erro ao verificar usuários sem associação\n";
            }
            
            // Verificar gestores aprovados
            $sql = "SELECT COUNT(*) as total FROM associacoes_usuario_unidade 
                    WHERE perfil = 'Gestor' AND status_aprovacao = 'Aprovado'";
            $result = $this->conn->query($sql);
            if ($result) {
                $gestores_aprovados = $result->fetch_assoc()['total'];
                echo "👑 Gestores aprovados: $gestores_aprovados\n";
                $this->metricas['gestores_aprovados'] = $gestores_aprovados;
            } else {
                echo "⚠️  Erro ao verificar gestores aprovados\n";
                $this->metricas['gestores_aprovados'] = 0;
            }
            
            // Verificar operadores pendentes
            $sql = "SELECT COUNT(*) as total FROM associacoes_usuario_unidade 
                    WHERE perfil != 'Gestor' AND status_aprovacao = 'Pendente'";
            $result = $this->conn->query($sql);
            if ($result) {
                $operadores_pendentes = $result->fetch_assoc()['total'];
                echo "⏳ Operadores pendentes: $operadores_pendentes\n";
                $this->metricas['operadores_pendentes'] = $operadores_pendentes;
            } else {
                echo "⚠️  Erro ao verificar operadores pendentes\n";
                $this->metricas['operadores_pendentes'] = 0;
            }
        } catch (Exception $e) {
            echo "❌ Erro ao verificar integridade dos dados: " . $e->getMessage() . "\n";
        }
    }
    
    private function analisarSistemaAprovacoes() {
        echo "\n4. ✅ ANALISANDO SISTEMA DE APROVAÇÕES...\n";
        
        // Aprovações pendentes por tipo
        $sql = "SELECT tipo, COUNT(*) as total FROM aprovacoes 
                WHERE status = 'Pendente' GROUP BY tipo";
        $result = $this->conn->query($sql);
        
        $total_pendentes = 0;
        while ($row = $result->fetch_assoc()) {
            echo "📋 {$row['tipo']}: {$row['total']} pendentes\n";
            $total_pendentes += $row['total'];
        }
        
        // Verificar aprovações órfãs (sem caixa/jogador válido)
        $sql = "SELECT COUNT(*) as total FROM aprovacoes a 
                LEFT JOIN caixas c ON a.referencia_id = c.id AND a.tipo = 'Caixa'
                LEFT JOIN jogadores j ON a.referencia_id = j.id AND a.tipo = 'Jogador'
                WHERE a.status = 'Pendente' AND c.id IS NULL AND j.id IS NULL";
        $result = $this->conn->query($sql);
        $aprovacoes_orfas = $result->fetch_assoc()['total'];
        
        if ($aprovacoes_orfas > 0) {
            echo "⚠️  $aprovacoes_orfas aprovações órfãs (referência inválida)\n";
            $this->problemas[] = "Aprovações órfãs detectadas: $aprovacoes_orfas";
        }
        
        $this->metricas['aprovacoes_pendentes'] = $total_pendentes;
        $this->metricas['aprovacoes_orfas'] = $aprovacoes_orfas;
    }
    
    private function verificarConsistenciaDashboard() {
        echo "\n5. 📊 VERIFICANDO CONSISTÊNCIA DO DASHBOARD...\n";
        
        // Simular query do dashboard para cada gestor
        $sql = "SELECT u.id, u.nome, aau.id_unidade FROM usuarios u 
                INNER JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario 
                WHERE aau.perfil = 'Gestor' AND aau.status_aprovacao = 'Aprovado'";
        $result = $this->conn->query($sql);
        
        while ($gestor = $result->fetch_assoc()) {
            $unidade_id = $gestor['id_unidade'];
            
            // Contar aprovações da unidade (query do dashboard)
            $sql_dash = "SELECT COUNT(*) as total FROM aprovacoes a 
                        WHERE a.status = 'Pendente' 
                        AND a.tipo IN ('Caixa', 'Jogador', 'Relatorio') 
                        AND a.referencia_id IN (
                            SELECT c.id FROM caixas c 
                            WHERE c.operador_id IN (
                                SELECT id_usuario FROM associacoes_usuario_unidade 
                                WHERE id_unidade = $unidade_id AND status_aprovacao = 'Aprovado'
                            )
                        )";
            $result_dash = $this->conn->query($sql_dash);
            $aprovacoes_dash = $result_dash->fetch_assoc()['total'];
            
            // Contar funcionários pendentes
            $sql_func = "SELECT COUNT(*) as total FROM associacoes_usuario_unidade 
                        WHERE status_aprovacao = 'Pendente' 
                        AND id_unidade = $unidade_id AND perfil != 'Gestor'";
            $result_func = $this->conn->query($sql_func);
            $funcionarios_pendentes = $result_func->fetch_assoc()['total'];
            
            $total_esperado = $aprovacoes_dash + $funcionarios_pendentes;
            
            echo "👤 {$gestor['nome']} (Unidade $unidade_id):\n";
            echo "   📋 Aprovações: $aprovacoes_dash\n";
            echo "   👥 Funcionários pendentes: $funcionarios_pendentes\n";
            echo "   📊 Total esperado: $total_esperado\n";
            
            if ($total_esperado > 0) {
                $this->metricas['dashboard_' . $unidade_id] = $total_esperado;
            }
        }
    }
    
    private function analisarPerformance() {
        echo "\n6. ⚡ ANALISANDO PERFORMANCE...\n";
        
        // Verificar índices críticos
        $tabelas_index = ['usuarios', 'aprovacoes', 'caixas', 'associacoes_usuario_unidade'];
        
        foreach ($tabelas_index as $tabela) {
            $sql = "SHOW INDEX FROM $tabela";
            $result = $this->conn->query($sql);
            $indices = $result->num_rows;
            echo "📈 $tabela: $indices índices\n";
            
            if ($indices < 3) {
                $this->recomendacoes[] = "Considerar adicionar índices em $tabela";
            }
        }
        
        // Verificar queries lentas (simulação)
        $start_time = microtime(true);
        $sql = "SELECT COUNT(*) FROM aprovacoes a 
                INNER JOIN usuarios u ON a.solicitante_id = u.id 
                WHERE a.status = 'Pendente'";
        $this->conn->query($sql);
        $execution_time = microtime(true) - $start_time;
        
        echo "⏱️  Query de aprovações: " . round($execution_time * 1000, 2) . "ms\n";
        
        if ($execution_time > 0.1) {
            $this->recomendacoes[] = "Query de aprovações pode ser otimizada";
        }
    }
    
    private function verificarSeguranca() {
        echo "\n7. 🔒 VERIFICANDO SEGURANÇA...\n";
        
        // Verificar senhas não hasheadas
        $sql = "SELECT COUNT(*) as total FROM usuarios 
                WHERE LENGTH(senha) < 60 OR senha NOT LIKE '$2y$%'";
        $result = $this->conn->query($sql);
        $senhas_inseguras = $result->fetch_assoc()['total'];
        
        if ($senhas_inseguras > 0) {
            echo "⚠️  $senhas_inseguras senhas não estão hasheadas corretamente\n";
            $this->problemas[] = "Senhas inseguras detectadas: $senhas_inseguras";
        } else {
            echo "✅ Todas as senhas estão hasheadas\n";
        }
        
        // Verificar usuários inativos
        $sql = "SELECT COUNT(*) as total FROM usuarios WHERE status = 'Inativo'";
        $result = $this->conn->query($sql);
        $usuarios_inativos = $result->fetch_assoc()['total'];
        echo "🚫 Usuários inativos: $usuarios_inativos\n";
        
        $this->metricas['senhas_inseguras'] = $senhas_inseguras;
        $this->metricas['usuarios_inativos'] = $usuarios_inativos;
    }
    
    private function gerarRelatorio() {
        echo "\n" . str_repeat("=", 50) . "\n";
        echo "📋 RELATÓRIO FINAL DO DIAGNÓSTICO\n";
        echo str_repeat("=", 50) . "\n\n";
        
        // Resumo de problemas
        if (count($this->problemas) > 0) {
            echo "🚨 PROBLEMAS DETECTADOS:\n";
            foreach ($this->problemas as $problema) {
                echo "   • $problema\n";
            }
            echo "\n";
        } else {
            echo "✅ NENHUM PROBLEMA CRÍTICO DETECTADO\n\n";
        }
        
        // Recomendações
        if (count($this->recomendacoes) > 0) {
            echo "💡 RECOMENDAÇÕES:\n";
            foreach ($this->recomendacoes as $recomendacao) {
                echo "   • $recomendacao\n";
            }
            echo "\n";
        }
        
        // Métricas resumidas
        echo "📊 MÉTRICAS DO SISTEMA:\n";
        echo "   • Gestores aprovados: " . ($this->metricas['gestores_aprovados'] ?? 0) . "\n";
        echo "   • Operadores pendentes: " . ($this->metricas['operadores_pendentes'] ?? 0) . "\n";
        echo "   • Aprovações pendentes: " . ($this->metricas['aprovacoes_pendentes'] ?? 0) . "\n";
        echo "   • Aprovações órfãs: " . ($this->metricas['aprovacoes_orfas'] ?? 0) . "\n";
        echo "   • Senhas inseguras: " . ($this->metricas['senhas_inseguras'] ?? 0) . "\n";
        echo "   • Usuários inativos: " . ($this->metricas['usuarios_inativos'] ?? 0) . "\n\n";
        
        // Status geral
        $status_geral = count($this->problemas) == 0 ? "✅ SAUDÁVEL" : "⚠️ ATENÇÃO NECESSÁRIA";
        echo "🎯 STATUS GERAL DO SISTEMA: $status_geral\n\n";
        
        // Instruções para IA
        echo "🧠 INSTRUÇÕES PARA IA ASSISTENTE:\n";
        echo "1. Se problemas foram detectados, priorize a correção\n";
        echo "2. Use os scripts específicos para diagnósticos detalhados\n";
        echo "3. Sempre teste as correções antes de implementar\n";
        echo "4. Mantenha a documentação atualizada\n";
        echo "5. Consulte o README.md para padrões de código\n\n";
        
        echo "🔗 PRÓXIMOS PASSOS SUGERIDOS:\n";
        if (count($this->problemas) > 0) {
            echo "   • Executar correções específicas para os problemas detectados\n";
            echo "   • Re-executar este diagnóstico após correções\n";
        } else {
            echo "   • Sistema está funcionando corretamente\n";
            echo "   • Focar em melhorias e otimizações\n";
        }
        
        echo "\n" . str_repeat("=", 50) . "\n";
        echo "✅ DIAGNÓSTICO CONCLUÍDO\n";
        echo str_repeat("=", 50) . "\n";
    }
}

// Executar diagnóstico
try {
    echo "🔧 Criando instância do diagnóstico...\n";
    $diagnostico = new DiagnosticoInteligente($conn);
    echo "🔧 Executando diagnóstico completo...\n";
    $diagnostico->executarDiagnosticoCompleto();
    echo "🔧 Diagnóstico concluído.\n";
} catch (Exception $e) {
    echo "❌ ERRO NO DIAGNÓSTICO: " . $e->getMessage() . "\n";
    echo "❌ Stack trace: " . $e->getTraceAsString() . "\n";
}

$conn->close();
?> 