<?php
// Diagnóstico de Aprovações Pendentes por Unidade e Usuário (Depuração Total)
require_once __DIR__ . '/../api/db_connect.php';

function printLine($msg = '') { echo $msg . "\n"; }

printLine("🔍 DIAGNÓSTICO DE APROVAÇÕES PENDENTES POR UNIDADE E USUÁRIO (DEPURAÇÃO)");
printLine(str_repeat('=', 60));

printLine("[LOG] Iniciando consulta de aprovações pendentes...");
// Buscar aprovações pendentes (tabela aprovacoes)
$sql = "SELECT a.id, a.tipo, a.referencia_id, a.solicitante_id, a.status, a.data_solicitacao, u.nome AS solicitante_nome, a.tipo, a.referencia_id
FROM aprovacoes a
INNER JOIN usuarios u ON a.solicitante_id = u.id
WHERE a.status = 'Pendente' LIMIT 20";
$res = $conn->query($sql);
printLine("[LOG] Consulta de aprovações pendentes finalizada.");

printLine("\n--- APROVAÇÕES PENDENTES (TABELA APROVACOES) ---");
$encontrou = false;
while ($row = $res->fetch_assoc()) {
    print_r($row);
    $encontrou = true;
}
if (!$encontrou) printLine("Nenhuma aprovação pendente encontrada.");

printLine("[LOG] Iniciando consulta de solicitações pendentes de funcionários...");
// Buscar solicitações pendentes de funcionários (tabela associacoes_usuario_unidade)
$sql_func = "SELECT aau.id, aau.id_usuario as solicitante_id, aau.id_unidade, aau.perfil, aau.status_aprovacao as status, aau.data_criacao as data_solicitacao, u.nome as solicitante_nome FROM associacoes_usuario_unidade aau INNER JOIN usuarios u ON aau.id_usuario = u.id WHERE aau.status_aprovacao = 'Pendente' LIMIT 20";
$res_func = $conn->query($sql_func);
printLine("[LOG] Consulta de solicitações pendentes de funcionários finalizada.");

printLine("\n--- SOLICITAÇÕES PENDENTES DE FUNCIONÁRIOS (TABELA ASSOCIACOES_USUARIO_UNIDADE) ---");
$encontrou_func = false;
while ($row = $res_func->fetch_assoc()) {
    print_r($row);
    $encontrou_func = true;
}
if (!$encontrou_func) printLine("Nenhuma solicitação pendente de funcionário encontrada.");

printLine("\nDiagnóstico concluído.");
$conn->close(); 