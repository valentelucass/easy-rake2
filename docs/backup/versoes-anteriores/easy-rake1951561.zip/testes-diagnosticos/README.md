# 🧠 DOCUMENTAÇÃO INTELIGENTE - Easy Rake

> **Para IA Assistente:** Esta documentação contém informações técnicas profundas, códigos de exemplo e padrões que devem ser consultados sempre que trabalhar no sistema Easy Rake.

## 🎯 VISÃO GERAL DO SISTEMA

### Arquitetura Principal
```
easy-rake/
├── api/                    # Backend APIs (RESTful)
│   ├── auth/              # Autenticação e sessões
│   ├── caixas/            # Operações de caixa
│   ├── dashboard/         # Estatísticas e dados do dashboard
│   ├── jogadores/         # Gestão de jogadores
│   ├── aprovacoes/        # Sistema de aprovações
│   ├── relatorios/        # Geração de relatórios
│   └── utils/             # Utilitários e helpers
├── css/                   # Estilos organizados por componentes
├── js/                    # JavaScript modular por funcionalidade
├── includes/              # Componentes PHP reutilizáveis
└── testes-diagnosticos/   # Scripts de teste e diagnóstico
```

### Tecnologias e Padrões
- **Backend:** PHP 7.4+ com MySQL 5.7+
- **Frontend:** HTML5, CSS3, JavaScript ES6+
- **Banco:** MySQL na porta 3307 (XAMPP)
- **Sessões:** PHP Sessions com cookies
- **APIs:** RESTful com JSON responses
- **Segurança:** Password hashing, prepared statements

## 🔧 ESTRUTURA DO BANCO DE DADOS

### Tabelas Principais
```sql
-- Usuários do sistema
usuarios (id, nome, cpf, senha, tipo_usuario, perfil, status, data_cadastro)

-- Unidades/Estabelecimentos
unidades (id, nome, telefone, codigo_acesso, status, data_criacao)

-- Associações usuário-unidade
associacoes_usuario_unidade (id, id_usuario, id_unidade, senha_hash, perfil, status_aprovacao, data_criacao)

-- Sistema de aprovações
aprovacoes (id, tipo, referencia_id, solicitante_id, aprovador_id, status, observacoes, data_solicitacao, data_aprovacao)

-- Caixas operacionais
caixas (id, operador_id, valor_inicial, status, data_abertura, data_fechamento)

-- Jogadores
jogadores (id, nome, cpf, limite_credito, status, data_cadastro)

-- Transações e movimentações
transacoes_jogadores, movimentacoes, gastos, rake, caixinhas_inclusoes
```

### Relacionamentos Críticos
```sql
-- Gestor → Unidade (1:1)
SELECT u.* FROM usuarios u 
INNER JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario 
WHERE aau.perfil = 'Gestor' AND aau.status_aprovacao = 'Aprovado'

-- Operador → Caixas (1:N)
SELECT c.* FROM caixas c 
WHERE c.operador_id IN (
    SELECT id_usuario FROM associacoes_usuario_unidade 
    WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'
)

-- Aprovações por unidade
SELECT a.* FROM aprovacoes a 
WHERE a.referencia_id IN (
    SELECT c.id FROM caixas c 
    WHERE c.operador_id IN (
        SELECT id_usuario FROM associacoes_usuario_unidade 
        WHERE id_unidade = ? AND status_aprovacao = 'Aprovado'
    )
)
```

## 🧪 SCRIPTS DE DIAGNÓSTICO INTELIGENTE

### 1. Diagnóstico Simples (Recomendado)
```bash
# Diagnóstico rápido e completo
php testes-diagnosticos/diagnostico_simples.php
```

**O que verifica:**
- Conexão MySQL na porta 3307
- Existência das tabelas principais
- Dados básicos de jogadores
- Integridade das estruturas
- Usuários e funcionários
- Códigos de acesso
- Estrutura para relatórios

### 2. Diagnóstico Inteligente (Completo)
```bash
# Análise profunda e completa
php testes-diagnosticos/diagnostico_inteligente.php
```

**Análise completa:**
- Verificação de conectividade
- Análise de usuários e funcionários
- Verificação de códigos de acesso
- Diagnóstico de relatórios
- Análise de performance
- Verificação de integridade
- Relatório detalhado

### 3. Verificador de Estrutura
```bash
# Verifica estrutura completa do sistema
php testes-diagnosticos/verificador_estrutura.php
```

**Verifica:**
- Estrutura de todas as tabelas
- Dados de caixas e jogadores
- Dashboard e contadores
- Integridade referencial
- Dados de exemplo

## 🤖 SISTEMA IA CONSOLIDADO

### Sistema IA Completo
```bash
# Executa todo o sistema IA
php testes-diagnosticos/sistema_ia.php

# Executa apenas hook de memória
php testes-diagnosticos/sistema_ia.php memory

# Executa apenas configuração
php testes-diagnosticos/sistema_ia.php config

# Executa apenas atualizador
php testes-diagnosticos/sistema_ia.php update
```

**Funcionalidades:**
- **Hook de Memória**: Gera memória IA com informações do sistema
- **Configuração IA**: Aplica configurações obrigatórias
- **Atualizador Automático**: Atualiza documentação automaticamente

### Como "Puxar" IA Automaticamente
```php
// Incluir em qualquer script principal
require_once 'testes-diagnosticos/sistema_ia.php';

// IA será automaticamente "puxada" para consultar documentação
```

## 🧪 SCRIPTS DE TESTE

### 1. Teste de Integração
```bash
# Testa integrações entre funcionalidades
php testes-diagnosticos/teste_simples_integracao.php
```

**Testa:**
- Conexões entre abrir caixa, relatórios, jogadores e aprovações
- Fluxos completos do sistema
- Relatórios cruzados
- Dashboard integrado

### 2. Teste de Sistema de Aprovações
```bash
# Teste específico do sistema de aprovações
php testes-diagnosticos/teste_sistema_aprovacoes.php
```

**Testa:**
- Criação de aprovações
- Processamento de aprovações
- Ativação de entidades
- Fluxos de trabalho

## 🔧 CORREÇÃO AUTOMÁTICA

### Corretor Automático
```bash
# Corrige problemas comuns automaticamente
php testes-diagnosticos/corretor_automatico.php
```

**Corrige:**
- Problemas de integridade referencial
- Dados inconsistentes
- Configurações incorretas
- Problemas de segurança

## 🎯 PADRÕES DE CÓDIGO E CORREÇÕES

### Autenticação e Sessões
```php
// SEMPRE verificar sessão antes de qualquer operação
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit;
}

// Verificar perfil para operações específicas
if (!isset($_SESSION['perfil']) || $_SESSION['perfil'] !== 'Gestor') {
    echo json_encode(['success' => false, 'message' => 'Acesso restrito ao gestor.']);
    exit;
}
```

### Queries Seguras
```php
// SEMPRE usar prepared statements
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
```

### Respostas JSON Padronizadas
```php
// Padrão de resposta para todas as APIs
echo json_encode([
    'success' => true/false,
    'message' => 'Mensagem descritiva',
    'data' => $dados_ou_null,
    'error' => $erro_tecnico_ou_null,
    'timestamp' => date('Y-m-d H:i:s')
]);
```

### Tratamento de Erros
```php
try {
    // Operação principal
    $result = $conn->query($sql);
    if (!$result) {
        throw new Exception("Erro na query: " . $conn->error);
    }
} catch (Exception $e) {
    error_log("Erro: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro interno do servidor.',
        'error' => $e->getMessage()
    ]);
    exit;
}
```

## 🔍 FLUXOS CRÍTICOS DO SISTEMA

### 1. Sistema de Aprovações
```
Cadastro → Associação Pendente → Aprovação Gestor → Ativação
```

**Pontos de falha:**
- Senha não salva na tabela `usuarios`
- Associação não criada na `associacoes_usuario_unidade`
- Status não atualizado após aprovação

### 2. Dashboard e Contadores
```
Query Dashboard → Contagem Caixas → Contagem Jogadores → Contagem Aprovações
```

**Problemas comuns:**
- Lógicas diferentes de contagem entre endpoints
- Filtros por unidade inconsistentes
- Cache não atualizado

### 3. Segurança e Propriedade
```
Usuário Logado → Verificar Propriedade → Operação → Resposta
```

**Verificações obrigatórias:**
- Sessão ativa
- Propriedade dos dados
- Permissões de perfil
- Integridade referencial

## 🚨 PROBLEMAS COMUNS E SOLUÇÕES

### Login não funciona:
- **Causa**: Senha não salva na tabela correta
- **Solução**: Verificar `associacoes_usuario_unidade`
- **Script**: `corretor_automatico.php`

### Aprovações não aparecem:
- **Causa**: Filtro por unidade incorreto
- **Solução**: Usar mesma lógica do endpoint de aprovações
- **Script**: `diagnostico_simples.php`

### Dashboard inconsistente:
- **Causa**: Lógicas diferentes de contagem
- **Solução**: Usar exatamente a mesma query
- **Script**: `diagnostico_simples.php`

### Caixas múltiplos:
- **Causa**: Operador com múltiplos caixas abertos
- **Solução**: Fechar caixas antigos, manter apenas o mais recente
- **Script**: `corretor_automatico.php`

## 📋 CHECKLIST OBRIGATÓRIO

### Antes de Correções:
- [ ] Executar `diagnostico_simples.php`
- [ ] Verificar conectividade MySQL (porta 3307)
- [ ] Analisar logs de erro
- [ ] Verificar sessões e autenticação
- [ ] Confirmar permissões de usuário
- [ ] Validar integridade referencial

### Durante Correções:
- [ ] Usar prepared statements
- [ ] Implementar tratamento de erros
- [ ] Manter padrão de respostas JSON
- [ ] Logar operações críticas
- [ ] Testar com dados reais

### Após Correções:
- [ ] Executar testes automatizados
- [ ] Verificar consistência de dados
- [ ] Validar performance
- [ ] Documentar mudanças
- [ ] Atualizar documentação

## 🎯 FLUXO RECOMENDADO PARA IA

### Antes de Qualquer Trabalho:
1. **Execute diagnóstico** → `diagnostico_simples.php`
2. **Consulte documentação** → `README.md`
3. **Verifique problemas** → Use scripts específicos se necessário

### Durante Correções:
1. **Use padrões documentados** → Códigos seguros e testados
2. **Siga fluxos críticos** → Sistema de aprovações, dashboard, caixas
3. **Mantenha consistência** → Mesmas queries em endpoints relacionados

### Após Correções:
1. **Teste funcionalidades** → Execute testes específicos
2. **Verifique consistência** → Use diagnóstico novamente
3. **Atualize documentação** → Use sistema IA

## 📊 BENEFÍCIOS DO SISTEMA

### Para IA Assistente:
- **Eficiência** - Diagnóstico rápido e correção automática
- **Precisão** - Queries testadas e fluxos validados
- **Economia** - Menos tentativas e correção direcionada
- **Memória** - Sempre "puxada" para consultar documentação

### Para o Sistema:
- **Qualidade** - Padrões mantidos e testados
- **Consistência** - Dados sempre íntegros
- **Performance** - Queries otimizadas
- **Manutenibilidade** - Documentação sempre atualizada

## 🚨 INSTRUÇÕES FINAIS PARA IA

**SEMPRE:**
1. Consulte a documentação antes de trabalhar no sistema
2. Execute o diagnóstico antes de fazer correções
3. Use os scripts de correção automática quando disponíveis
4. Mantenha a documentação atualizada
5. Teste sempre as correções implementadas

**NUNCA:**
1. Ignore verificações de segurança
2. Use queries não preparadas
3. Esqueça de verificar propriedade dos dados
4. Deixe de testar correções
5. Trabalhe sem consultar a documentação

---

*Documentação atualizada em: <?php echo date('d/m/Y H:i:s'); ?>*  
*Sistema: Easy Rake v1.0*  
*Banco de Dados: MySQL (Porta 3307)* 