<?php
/**
 * 🔒 VERIFICAR CORREÇÕES DE SEGURANÇA - Easy Rake
 */

echo "🔒 VERIFICANDO CORREÇÕES DE SEGURANÇA - EASY RAKE\n";
echo "================================================\n\n";

$apis_corrigidas = [
    'api/caixas/get_caixa_info.php',
    'api/caixas/compilar_dados.php',
    'api/caixas/rake_listar.php',
    'api/caixas/historico_conferencia.php',
    'api/caixas/get_session_stats.php',
    'api/caixas/caixinhas_listar_inclusoes.php',
    'api/caixas/relatorio_excel.php',
    'api/caixas/relatorio_pdf.php'
];

$corrigidas = 0;
$total = count($apis_corrigidas);

foreach ($apis_corrigidas as $arquivo) {
    echo "🔍 Verificando: $arquivo\n";
    
    if (!file_exists($arquivo)) {
        echo "   ❌ Arquivo não encontrado\n\n";
        continue;
    }
    
    $conteudo = file_get_contents($arquivo);
    
    // Verificar se tem verificação de segurança
    $tem_verificacao = strpos($conteudo, 'VERIFICAÇÃO DE SEGURANÇA - OBRIGATÓRIA') !== false;
    $tem_propriedade = strpos($conteudo, 'operador_id != $_SESSION[\'user_id\']') !== false;
    $tem_negado = strpos($conteudo, 'Acesso negado') !== false;
    
    if ($tem_verificacao && $tem_propriedade && $tem_negado) {
        echo "   ✅ CORRIGIDA - Segurança implementada\n";
        $corrigidas++;
    } else {
        echo "   ❌ VULNERÁVEL - Falta verificação de segurança\n";
        if (!$tem_verificacao) echo "      - Falta comentário de verificação\n";
        if (!$tem_propriedade) echo "      - Falta verificação de propriedade\n";
        if (!$tem_negado) echo "      - Falta mensagem de acesso negado\n";
    }
    
    echo "\n";
}

// Relatório final
echo str_repeat("=", 60) . "\n";
echo "📋 RELATÓRIO DE VERIFICAÇÃO\n";
echo str_repeat("=", 60) . "\n\n";

echo "📊 RESULTADO:\n";
echo "   ✅ APIs corrigidas: $corrigidas de $total\n";
echo "   ❌ APIs vulneráveis: " . ($total - $corrigidas) . " de $total\n\n";

if ($corrigidas == $total) {
    echo "🎯 STATUS: ✅ SISTEMA SEGURO\n";
    echo "   ✅ Todas as vulnerabilidades foram corrigidas\n";
    echo "   ✅ Usuários só acessam seus próprios dados\n";
    echo "   ✅ Sistema pronto para produção\n";
} else {
    echo "🎯 STATUS: ⚠️  VULNERABILIDADES RESTANTES\n";
    echo "   ❌ " . ($total - $corrigidas) . " APIs ainda precisam ser corrigidas\n";
    echo "   ❌ Sistema NÃO está seguro para produção\n";
}

echo "\n🧠 INSTRUÇÕES PARA IA:\n";
if ($corrigidas == $total) {
    echo "1. ✅ Sistema está seguro\n";
    echo "2. ✅ Implementar verificação em novas APIs\n";
    echo "3. ✅ Manter padrão de segurança\n";
} else {
    echo "1. ❌ Corrigir APIs restantes\n";
    echo "2. ❌ Implementar verificação de propriedade\n";
    echo "3. ❌ Testar todas as correções\n";
}

echo "\n" . str_repeat("=", 60) . "\n";
echo "🔒 VERIFICAÇÃO CONCLUÍDA\n";
echo str_repeat("=", 60) . "\n";
?> 