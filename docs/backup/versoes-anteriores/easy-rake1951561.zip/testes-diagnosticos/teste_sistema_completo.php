<?php
/**
 * TESTE SISTEMA COMPLETO - Easy Rake
 * Verifica todos os problemas reportados pelo usuário
 */

require_once __DIR__ . '/../api/db_connect.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h1>🧪 TESTE SISTEMA COMPLETO - Easy Rake</h1>";
echo "<p><strong>Data/Hora:</strong> " . date('d/m/Y H:i:s') . "</p>";

// ============================================================================
// 1. VERIFICAÇÃO DE ESTRUTURA DO BANCO
// ============================================================================

echo "<h2>1. 📊 VERIFICAÇÃO DE ESTRUTURA DO BANCO</h2>";

$tabelas_necessarias = [
    'usuarios', 'unidades', 'associacoes_usuario_unidade', 
    'jogadores', 'caixas', 'caixinhas', 'caixinhas_inclusoes',
    'transacoes_jogadores', 'movimentacoes', 'gastos', 'aprovacoes'
];

$tabelas_ok = [];
$tabelas_faltando = [];

foreach ($tabelas_necessarias as $tabela) {
    $result = $conn->query("SHOW TABLES LIKE '$tabela'");
    if ($result && $result->num_rows > 0) {
        $tabelas_ok[] = $tabela;
        echo "✅ Tabela <strong>$tabela</strong> existe<br>";
    } else {
        $tabelas_faltando[] = $tabela;
        echo "❌ Tabela <strong>$tabela</strong> NÃO existe<br>";
    }
}

if (!empty($tabelas_faltando)) {
    echo "<p style='color: red;'><strong>ERRO CRÍTICO:</strong> Tabelas faltando: " . implode(', ', $tabelas_faltando) . "</p>";
    exit;
}

// ============================================================================
// 2. VERIFICAÇÃO DE UNIDADES E CÓDIGOS DE ACESSO
// ============================================================================

echo "<h2>2. 🏢 VERIFICAÇÃO DE UNIDADES E CÓDIGOS DE ACESSO</h2>";

$result = $conn->query("SELECT id, nome, codigo_acesso, status FROM unidades ORDER BY id");
if ($result && $result->num_rows > 0) {
    echo "<table border='1' cellpadding='6' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Nome</th><th>Código Acesso</th><th>Status</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['nome']) . "</td>";
        echo "<td><strong>" . htmlspecialchars($row['codigo_acesso']) . "</strong></td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>❌ Nenhuma unidade encontrada!</p>";
}

// ============================================================================
// 3. VERIFICAÇÃO DE USUÁRIOS E ASSOCIAÇÕES
// ============================================================================

echo "<h2>3. 👥 VERIFICAÇÃO DE USUÁRIOS E ASSOCIAÇÕES</h2>";

$result = $conn->query("
    SELECT u.id, u.nome, u.cpf, u.tipo_usuario, u.status,
           aau.id_unidade, aau.perfil, aau.status_aprovacao,
           un.nome as unidade_nome, un.codigo_acesso
    FROM usuarios u
    LEFT JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario
    LEFT JOIN unidades un ON aau.id_unidade = un.id
    ORDER BY u.id
");

if ($result && $result->num_rows > 0) {
    echo "<table border='1' cellpadding='6' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Nome</th><th>CPF</th><th>Tipo</th><th>Status</th><th>Unidade</th><th>Perfil</th><th>Aprovação</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['nome']) . "</td>";
        echo "<td>" . htmlspecialchars($row['cpf']) . "</td>";
        echo "<td>" . $row['tipo_usuario'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "<td>" . ($row['unidade_nome'] ? htmlspecialchars($row['unidade_nome']) . " (" . $row['codigo_acesso'] . ")" : "N/A") . "</td>";
        echo "<td>" . ($row['perfil'] ?? 'N/A') . "</td>";
        echo "<td>" . ($row['status_aprovacao'] ?? 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>❌ Nenhum usuário encontrado!</p>";
}

// ============================================================================
// 4. VERIFICAÇÃO DE JOGADORES (PROBLEMA PRINCIPAL)
// ============================================================================

echo "<h2>4. 🎮 VERIFICAÇÃO DE JOGADORES (PROBLEMA PRINCIPAL)</h2>";

$result = $conn->query("SELECT id, nome, cpf, status, data_cadastro FROM jogadores ORDER BY id");
if ($result && $result->num_rows > 0) {
    echo "<p><strong>Total de jogadores:</strong> " . $result->num_rows . "</p>";
    echo "<table border='1' cellpadding='6' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Nome</th><th>CPF</th><th>Status</th><th>Data Cadastro</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['nome']) . "</td>";
        echo "<td>" . htmlspecialchars($row['cpf']) . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "<td>" . $row['data_cadastro'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<p style='color: orange;'><strong>⚠️ PROBLEMA IDENTIFICADO:</strong> Jogadores não têm associação com unidades!</p>";
    echo "<p>Isso significa que todos os jogadores são globais e aparecem para todas as unidades.</p>";
} else {
    echo "<p style='color: red;'>❌ Nenhum jogador encontrado!</p>";
}

// ============================================================================
// 5. VERIFICAÇÃO DE CAIXAS ABERTOS
// ============================================================================

echo "<h2>5. 💰 VERIFICAÇÃO DE CAIXAS ABERTOS</h2>";

$result = $conn->query("
    SELECT c.id, c.valor_inicial, c.status, c.data_abertura,
           u.nome as operador, u.tipo_usuario,
           un.nome as unidade_nome
    FROM caixas c
    LEFT JOIN usuarios u ON c.operador_id = u.id
    LEFT JOIN associacoes_usuario_unidade aau ON u.id = aau.id_usuario
    LEFT JOIN unidades un ON aau.id_unidade = un.id
    WHERE c.status = 'Aberto'
    ORDER BY c.data_abertura DESC
");

if ($result && $result->num_rows > 0) {
    echo "<p><strong>Total de caixas abertos:</strong> " . $result->num_rows . "</p>";
    echo "<table border='1' cellpadding='6' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Operador</th><th>Unidade</th><th>Valor Inicial</th><th>Data Abertura</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['operador']) . " (" . $row['tipo_usuario'] . ")</td>";
        echo "<td>" . ($row['unidade_nome'] ? htmlspecialchars($row['unidade_nome']) : 'N/A') . "</td>";
        echo "<td>R$ " . number_format($row['valor_inicial'], 2, ',', '.') . "</td>";
        echo "<td>" . $row['data_abertura'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>✅ Nenhum caixa aberto no momento.</p>";
}

// ============================================================================
// 6. VERIFICAÇÃO DE CAIXINHAS
// ============================================================================

echo "<h2>6. 🎯 VERIFICAÇÃO DE CAIXINHAS</h2>";

$result = $conn->query("
    SELECT cx.id, cx.nome, cx.cashback_percent, cx.participantes, cx.status,
           c.id as caixa_id, u.nome as operador
    FROM caixinhas cx
    LEFT JOIN caixas c ON cx.caixa_id = c.id
    LEFT JOIN usuarios u ON c.operador_id = u.id
    ORDER BY cx.id
");

if ($result && $result->num_rows > 0) {
    echo "<p><strong>Total de caixinhas:</strong> " . $result->num_rows . "</p>";
    echo "<table border='1' cellpadding='6' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Nome</th><th>Cashback</th><th>Participantes</th><th>Status</th><th>Caixa</th><th>Operador</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['nome']) . "</td>";
        echo "<td>" . $row['cashback_percent'] . "%</td>";
        echo "<td>" . $row['participantes'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "<td>" . ($row['caixa_id'] ?? 'N/A') . "</td>";
        echo "<td>" . ($row['operador'] ? htmlspecialchars($row['operador']) : 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Verificar inclusões
    echo "<h3>Inclusões nas Caixinhas:</h3>";
    $result_inclusoes = $conn->query("
        SELECT ci.id, ci.caixinha_id, ci.valor, ci.data_inclusao,
               cx.nome as caixinha_nome, u.nome as usuario
        FROM caixinhas_inclusoes ci
        LEFT JOIN caixinhas cx ON ci.caixinha_id = cx.id
        LEFT JOIN usuarios u ON ci.usuario_id = u.id
        ORDER BY ci.data_inclusao DESC
        LIMIT 10
    ");
    
    if ($result_inclusoes && $result_inclusoes->num_rows > 0) {
        echo "<table border='1' cellpadding='6' style='border-collapse:collapse;'>";
        echo "<tr><th>ID</th><th>Caixinha</th><th>Valor</th><th>Usuário</th><th>Data</th></tr>";
        while ($row = $result_inclusoes->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['caixinha_nome']) . "</td>";
            echo "<td>R$ " . number_format($row['valor'], 2, ',', '.') . "</td>";
            echo "<td>" . htmlspecialchars($row['usuario']) . "</td>";
            echo "<td>" . $row['data_inclusao'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: orange;'>⚠️ Nenhuma inclusão encontrada nas caixinhas.</p>";
    }
} else {
    echo "<p>✅ Nenhuma caixinha criada ainda.</p>";
}

// ============================================================================
// 7. TESTE DE FUNCIONALIDADES CRÍTICAS
// ============================================================================

echo "<h2>7. 🔧 TESTE DE FUNCIONALIDADES CRÍTICAS</h2>";

// Teste 1: Verificar se há gestores aprovados
$result = $conn->query("
    SELECT COUNT(*) as total FROM associacoes_usuario_unidade 
    WHERE perfil = 'Gestor' AND status_aprovacao = 'Aprovado'
");
$gestores_aprovados = $result->fetch_assoc()['total'];
echo "<p><strong>Gestores aprovados:</strong> $gestores_aprovados</p>";

// Teste 2: Verificar se há operadores aprovados
$result = $conn->query("
    SELECT COUNT(*) as total FROM associacoes_usuario_unidade 
    WHERE perfil != 'Gestor' AND status_aprovacao = 'Aprovado'
");
$operadores_aprovados = $result->fetch_assoc()['total'];
echo "<p><strong>Operadores aprovados:</strong> $operadores_aprovados</p>";

// Teste 3: Verificar aprovações pendentes
$result = $conn->query("SELECT COUNT(*) as total FROM aprovacoes WHERE status = 'Pendente'");
$aprovacoes_pendentes = $result->fetch_assoc()['total'];
echo "<p><strong>Aprovações pendentes:</strong> $aprovacoes_pendentes</p>";

// Teste 4: Verificar funcionários pendentes
$result = $conn->query("
    SELECT COUNT(*) as total FROM associacoes_usuario_unidade 
    WHERE status_aprovacao = 'Pendente' AND perfil != 'Gestor'
");
$funcionarios_pendentes = $result->fetch_assoc()['total'];
echo "<p><strong>Funcionários pendentes:</strong> $funcionarios_pendentes</p>";

// ============================================================================
// 8. ANÁLISE DOS PROBLEMAS REPORTADOS
// ============================================================================

echo "<h2>8. 🚨 ANÁLISE DOS PROBLEMAS REPORTADOS</h2>";

echo "<h3>Problema 1: Jogadores não aparecem entre unidades</h3>";
echo "<p><strong>Status:</strong> <span style='color: red;'>❌ CONFIRMADO</span></p>";
echo "<p><strong>Causa:</strong> A tabela 'jogadores' não possui campo 'unidade_id' ou associação com unidades.</p>";
echo "<p><strong>Impacto:</strong> Todos os jogadores são globais e aparecem para todas as unidades.</p>";

echo "<h3>Problema 2: Caixinhas não incluem valor</h3>";
echo "<p><strong>Status:</strong> <span style='color: orange;'>⚠️ VERIFICAR</span></p>";
echo "<p><strong>Análise:</strong> A tabela 'caixinhas_inclusoes' existe e tem a estrutura correta.</p>";
echo "<p><strong>Possível causa:</strong> Problema no frontend ou na API de inclusão.</p>";

echo "<h3>Problema 3: Código da unidade não aparece</h3>";
echo "<p><strong>Status:</strong> <span style='color: orange;'>⚠️ VERIFICAR</span></p>";
echo "<p><strong>Análise:</strong> Os códigos de acesso existem no banco.</p>";
echo "<p><strong>Possível causa:</strong> Não está sendo exibido na interface.</p>";

// ============================================================================
// 9. RECOMENDAÇÕES DE CORREÇÃO
// ============================================================================

echo "<h2>9. 💡 RECOMENDAÇÕES DE CORREÇÃO</h2>";

echo "<h3>Correção 1: Adicionar associação de jogadores com unidades</h3>";
echo "<pre>";
echo "ALTER TABLE jogadores ADD COLUMN unidade_id INT AFTER id;\n";
echo "ALTER TABLE jogadores ADD CONSTRAINT fk_jogadores_unidade FOREIGN KEY (unidade_id) REFERENCES unidades(id);\n";
echo "</pre>";

echo "<h3>Correção 2: Atualizar APIs de jogadores</h3>";
echo "<p>Modificar as APIs para filtrar jogadores por unidade:</p>";
echo "<ul>";
echo "<li>api/jogadores/buscar_jogadores.php - Adicionar filtro por unidade</li>";
echo "<li>api/jogadores/registrar_jogador.php - Associar à unidade do usuário</li>";
echo "</ul>";

echo "<h3>Correção 3: Exibir código da unidade na interface</h3>";
echo "<p>Adicionar exibição do código de acesso nas páginas relevantes.</p>";

echo "<h3>Correção 4: Testar funcionalidade de caixinhas</h3>";
echo "<p>Verificar se a API de inclusão de valores está funcionando corretamente.</p>";

// ============================================================================
// 10. RESUMO EXECUTIVO
// ============================================================================

echo "<h2>10. 📋 RESUMO EXECUTIVO</h2>";

echo "<div style='background: #f0f0f0; padding: 15px; border-radius: 5px;'>";
echo "<h3>Status Geral do Sistema:</h3>";
echo "<ul>";
echo "<li><strong>Estrutura do Banco:</strong> ✅ OK</li>";
echo "<li><strong>Unidades:</strong> ✅ " . ($result->num_rows ?? 0) . " unidades encontradas</li>";
echo "<li><strong>Usuários:</strong> ✅ Sistema de associações funcionando</li>";
echo "<li><strong>Jogadores:</strong> ❌ PROBLEMA CRÍTICO - Sem filtro por unidade</li>";
echo "<li><strong>Caixas:</strong> ✅ Sistema funcionando</li>";
echo "<li><strong>Caixinhas:</strong> ⚠️ Estrutura OK, verificar funcionalidade</li>";
echo "<li><strong>Aprovações:</strong> ✅ Sistema funcionando</li>";
echo "</ul>";

echo "<h3>Problemas Críticos Identificados:</h3>";
echo "<ol>";
echo "<li><strong>Jogadores globais:</strong> Não há separação por unidade</li>";
echo "<li><strong>Interface:</strong> Códigos de acesso não são exibidos</li>";
echo "<li><strong>Caixinhas:</strong> Funcionalidade de inclusão precisa ser testada</li>";
echo "</ol>";

echo "<h3>Prioridade de Correção:</h3>";
echo "<ol>";
echo "<li><strong>ALTA:</strong> Adicionar campo unidade_id na tabela jogadores</li>";
echo "<li><strong>ALTA:</strong> Atualizar APIs para filtrar jogadores por unidade</li>";
echo "<li><strong>MÉDIA:</strong> Exibir códigos de acesso na interface</li>";
echo "<li><strong>MÉDIA:</strong> Testar e corrigir funcionalidade de caixinhas</li>";
echo "</ol>";
echo "</div>";

echo "<hr>";
echo "<p><em>Teste concluído em " . date('d/m/Y H:i:s') . "</em></p>";
?> 