// JS para a aba Transações de Fichas

document.addEventListener('DOMContentLoaded', function() {
    // Elementos principais
    const buscaInput = document.getElementById('fichas-busca-input');
    const buscaBtn = document.getElementById('fichas-busca-btn');
    const listaResultados = document.getElementById('fichas-busca-resultados');
    const dadosJogadorBox = document.getElementById('fichas-dados-jogador');
    const formTransacao = document.getElementById('fichas-form-transacao');
    const valorInput = document.getElementById('fichas-valor');
    const btnVender = document.getElementById('fichas-btn-vender');
    const btnDevolver = document.getElementById('fichas-btn-devolver');
    const alertaCredito = document.getElementById('fichas-alerta-credito');
    const tabelaJogadores = document.getElementById('fichas-tabela-jogadores');
    const btnImprimirTodas = document.getElementById('fichas-btn-imprimir-todas');
    // ... outros elementos/modais

    let jogadorSelecionado = null;
    let podeProsseguirCredito = false;

    // Busca de jogador
    if (buscaBtn && buscaInput) {
        buscaBtn.onclick = function(e) {
            e.preventDefault();
            buscarJogadores(buscaInput.value.trim());
        };
        buscaInput.onkeyup = function(e) {
            if (e.key === 'Enter') buscarJogadores(buscaInput.value.trim());
        };
    }

    function buscarJogadores(termo) {
        if (!termo) return;
        fetch('api/jogadores/buscar_jogadores.php?busca=' + encodeURIComponent(termo))
            .then(r => r.json())
            .then(data => {
                if (data.success && data.jogadores.length > 0) {
                    mostrarResultadosBusca(data.jogadores);
                } else {
                    listaResultados.innerHTML = '<div class="fichas-busca-nenhum">Nenhum jogador encontrado.</div>';
                }
            });
    }

    function mostrarResultadosBusca(jogadores) {
        listaResultados.innerHTML = '';
        jogadores.forEach(jogador => {
            const div = document.createElement('div');
            div.className = 'fichas-busca-resultado';
            div.textContent = `${jogador.nome} - ${jogador.cpf} - ${jogador.telefone}`;
            div.onclick = () => selecionarJogador(jogador);
            listaResultados.appendChild(div);
        });
    }

    function selecionarJogador(jogador) {
        jogadorSelecionado = jogador;
        podeProsseguirCredito = false;
        // Preencher dados do jogador
        dadosJogadorBox.innerHTML = `
            <div class="fichas-dado"><strong>Nome:</strong> ${jogador.nome}</div>
            <div class="fichas-dado"><strong>CPF:</strong> ${jogador.cpf}</div>
            <div class="fichas-dado"><strong>Telefone:</strong> ${jogador.telefone}</div>
            <div class="fichas-dado"><strong>Saldo Atual:</strong> R$ ${Number(jogador.saldo_atual).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</div>
            <div class="fichas-dado"><strong>Limite de Crédito:</strong> R$ ${Number(jogador.limite_credito).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</div>
            <div class="fichas-dado"><strong>Situação:</strong> ${jogador.status}</div>
        `;
        dadosJogadorBox.style.display = 'flex';
        formTransacao.style.display = 'flex';
    }

    // Formulário de transação
    if (formTransacao) {
        formTransacao.onsubmit = function(e) {
            e.preventDefault();
            if (!jogadorSelecionado) return;
            const valor = parseFloat(valorInput.value);
            if (!valor || valor <= 0) {
                mostrarAlerta('Informe um valor válido.');
                return;
            }
            // Validação de crédito
            const saldoDisponivel = Number(jogadorSelecionado.saldo_atual) + Number(jogadorSelecionado.limite_credito);
            if (btnVender && btnVender === document.activeElement && valor > saldoDisponivel && !podeProsseguirCredito) {
                mostrarAlertaCredito();
                return;
            }
            // Enviar transação
            realizarTransacao(valor, btnVender === document.activeElement ? 'COMPRA' : 'DEVOLUCAO');
        };
    }

    function mostrarAlerta(msg) {
        alertaCredito.innerHTML = msg;
        alertaCredito.style.display = 'block';
        setTimeout(() => { alertaCredito.style.display = 'none'; }, 3000);
    }
    function mostrarAlertaCredito() {
        alertaCredito.innerHTML = '⚠ LIMITE DE CRÉDITO EXCEDIDO. RECOMENDA-SE CONSULTAR O GESTOR DO CASH GAME.<br><button id="fichas-btn-prosseguir">Prosseguir</button> <button id="fichas-btn-cancelar">Cancelar</button>';
        alertaCredito.style.display = 'block';
        document.getElementById('fichas-btn-prosseguir').onclick = function() {
            podeProsseguirCredito = true;
            alertaCredito.style.display = 'none';
            formTransacao.requestSubmit();
        };
        document.getElementById('fichas-btn-cancelar').onclick = function() {
            podeProsseguirCredito = false;
            alertaCredito.style.display = 'none';
        };
    }

    function realizarTransacao(valor, tipo) {
        fetch('api/fichas/registrar_transacao.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                jogador_id: jogadorSelecionado.id,
                valor: valor,
                tipo: tipo
            })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                mostrarAlerta('Transação realizada com sucesso!');
                valorInput.value = '';
                atualizarTabelaJogadores();
                gerarRecibo(data.recibo);
            } else {
                mostrarAlerta(data.message || 'Erro ao registrar transação.');
            }
        });
    }

    // Atualização da tabela de jogadores ativos
    function atualizarTabelaJogadores() {
        fetch('api/fichas/listar_jogadores_sessao.php')
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    preencherTabelaJogadores(data.jogadores);
                }
            });
    }
    function preencherTabelaJogadores(jogadores) {
        const tbody = tabelaJogadores.querySelector('tbody');
        tbody.innerHTML = '';
        jogadores.forEach(jogador => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${jogador.nome}</td>
                <td>${jogador.fichas_compradas}</td>
                <td>${jogador.fichas_devolvidas}</td>
                <td>R$ ${Number(jogador.saldo_atual).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</td>
                <td><button class="fichas-btn fichas-btn--rebuy" data-id="${jogador.id}">Re-buy</button></td>
                <td><button class="fichas-btn fichas-btn--devolucao" data-id="${jogador.id}">Devolução</button></td>
                <td><button class="fichas-btn fichas-btn--detalhes" data-id="${jogador.id}">Detalhes</button></td>
                <td><button class="fichas-btn fichas-btn--imprimir" data-id="${jogador.id}"><span class="icon-impressora"></span></button></td>
            `;
            tbody.appendChild(tr);
        });
    }

    // Geração de recibo (simples, pode ser adaptado para impressão térmica)
    function gerarRecibo(dados) {
        // Aqui você pode abrir um modal ou janela de impressão com o recibo formatado
        // Exemplo: window.open('recibo.php?id='+dados.id, '_blank');
    }

    // Inicialização
    atualizarTabelaJogadores();
}); 