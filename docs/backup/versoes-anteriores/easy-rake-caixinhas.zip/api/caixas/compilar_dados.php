<?php
require_once '../db_connect.php';
header('Content-Type: application/json');

$caixa_id = isset($_GET['caixa_id']) ? intval($_GET['caixa_id']) : 0;
if (!$caixa_id) {
    echo json_encode(['erro' => 'ID do caixa não informado.']);
    exit;
}

// Buscar informações completas do caixa
$sql_caixa = "SELECT c.*, u.nome as operador_nome
               FROM caixas c
               LEFT JOIN usuarios u ON c.operador_id = u.id
               WHERE c.id = ?";
$stmt_caixa = $conn->prepare($sql_caixa);
$stmt_caixa->bind_param('i', $caixa_id);
$stmt_caixa->execute();
$res_caixa = $stmt_caixa->get_result();
$caixa = $res_caixa->fetch_assoc();

if (!$caixa) {
    echo json_encode(['erro' => 'Caixa não encontrado.']);
    exit;
}

// Buscar movimentações do caixa
$sql = "SELECT m.*, u.nome as operador_nome
        FROM movimentacoes m
        LEFT JOIN usuarios u ON m.operador_id = u.id
        WHERE m.caixa_id = ?
        ORDER BY m.data_movimentacao ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $caixa_id);
$stmt->execute();
$res = $stmt->get_result();
$movimentacoes = [];
$total_entradas = 0;
$total_saidas = 0;
while ($row = $res->fetch_assoc()) {
    $movimentacoes[] = $row;
    if ($row['tipo'] === 'Entrada') {
        $total_entradas += floatval($row['valor']);
    } else {
        $total_saidas += floatval($row['valor']);
    }
}

// Buscar transações de jogadores ligadas a este caixa (por data)
$transacoes = [];
if ($caixa) {
    $data_ini = $caixa['data_abertura'];
    $data_fim = $caixa['data_fechamento'] ?? date('Y-m-d H:i:s');
    $sql_trans = "SELECT t.*, j.nome as jogador_nome, j.status as jogador_status, u.nome as operador_nome
        FROM transacoes_jogadores t
        LEFT JOIN jogadores j ON t.jogador_id = j.id
        LEFT JOIN usuarios u ON t.operador_id = u.id
        WHERE t.data_transacao BETWEEN ? AND ?
        ORDER BY t.data_transacao ASC";
    $stmt3 = $conn->prepare($sql_trans);
    $stmt3->bind_param('ss', $data_ini, $data_fim);
    $stmt3->execute();
    $res3 = $stmt3->get_result();
    while ($row = $res3->fetch_assoc()) {
        $transacoes[] = $row;
    }
}

// Calcular saldo final
$saldo_final = isset($caixa['valor_final']) ? floatval($caixa['valor_final']) : (floatval($caixa['valor_inicial']) + $total_entradas - $total_saidas);

// Resposta
echo json_encode([
    'caixa' => $caixa,
    'movimentacoes' => $movimentacoes,
    'transacoes_jogadores' => $transacoes,
    'total_entradas' => $total_entradas,
    'total_saidas' => $total_saidas,
    'saldo_final' => $saldo_final
]); 