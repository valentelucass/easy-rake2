<?php
// Proxy para src/api/auth/logout.php
require_once __DIR__ . '/../../../src/api/auth/logout.php'; 