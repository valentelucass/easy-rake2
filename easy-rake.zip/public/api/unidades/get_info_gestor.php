<?php
// Proxy para src/api/unidades/get_info_gestor.php
require_once __DIR__ . '/../../../src/api/unidades/get_info_gestor.php'; 