# Funcionalidades da Página de Jogadores - Easy Rake

## Visão Geral
A página de jogadores permite gerenciar os dados dos participantes do cash game, incluindo cadastro, edição, busca e quitação de saldos.

## Funcionalidades Implementadas

### 1. Cadastro de Jogadores
- **Formulário completo** com campos obrigatórios e opcionais
- **Validação de CPF** no formato ###.###.###-##
- **Campos disponíveis:**
  - Nome completo (obrigatório)
  - CPF (obrigatório, com validação)
  - Telefone (opcional)
  - Limite de crédito (opcional)

### 2. Listagem e Busca
- **Tabela responsiva** com todos os jogadores cadastrados
- **Busca instantânea** por nome, CPF ou telefone
- **Colunas exibidas:**
  - Nome
  - CPF
  - Telefone
  - Limite de crédito
  - Saldo atual (com cores: verde=positivo, vermelho=negativo)
  - Data de cadastro
  - Situação (Em dia, Devedor, A receber, Limite Excedido)

### 3. Quitação de Saldos
- **Modal intuitivo** para quitação de débitos e créditos
- **Duas opções de quitação:**
  - **Pagamento de Débito:** Jogador paga valor para reduzir saldo negativo
  - **Pagamento de Crédito:** Caixa paga valor ao jogador referente a saldo positivo
- **Funcionalidades do modal:**
  - Exibe saldo atual do jogador
  - Calcula saldo final em tempo real
  - Validação de valores
  - Campo para observações
  - Feedback visual do resultado

### 4. Situação dos Jogadores
O sistema classifica automaticamente a situação dos jogadores:
- **Em dia:** Saldo = 0
- **Devedor:** Saldo < 0 (dentro do limite)
- **Limite Excedido:** Saldo negativo > limite de crédito
- **A receber:** Saldo > 0

### 5. Edição e Exclusão
- **Edição:** Modal para alterar dados do jogador
- **Exclusão:** Confirmação antes de remover jogador

## Arquivos Criados/Modificados

### APIs
- `api/jogadores/quitar_saldo.php` - Nova API para quitação de saldos

### Frontend
- `jogadores.php` - Página principal atualizada
- `css/pages/_jogadores.css` - Estilos para modal de quitação
- `js/features/jogadores.js` - JavaScript com funcionalidade de quitação

### Banco de Dados
- Utiliza tabelas existentes: `jogadores` e `transacoes_jogadores`
- Registra todas as quitações como transações quitadas

## Como Usar

1. **Acesse a página:** `/jogadores.php`
2. **Cadastre jogadores:** Clique em "Novo Jogador"
3. **Busque jogadores:** Use o campo de busca
4. **Quite saldos:** Clique em "Quitar" na linha do jogador
5. **Edite dados:** Clique em "Editar" na linha do jogador

## Validações Implementadas

- CPF deve estar no formato correto
- Valores de quitação devem ser > 0
- Saldo deve permitir o tipo de quitação selecionado
- Campos obrigatórios são validados
- Feedback visual para todas as operações

## Responsividade

- Interface adaptável para dispositivos móveis
- Modais responsivos
- Tabela com scroll horizontal em telas pequenas
- Botões empilhados em telas pequenas 