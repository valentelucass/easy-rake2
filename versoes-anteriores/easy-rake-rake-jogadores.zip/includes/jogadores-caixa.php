<?php
// Inclui a aba jogadores (parcial reutilizável)
include __DIR__ . '/jogadores-aba.php'; 