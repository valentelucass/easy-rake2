/*
 * ==========================================================================
 * EASY RAKE - FECHAMENTO DE CAIXA JAVASCRIPT
 * ==========================================================================
 * Autor: Gemini
 * Descrição: Funcionalidades específicas para o fechamento de caixa,
 * incluindo resumo financeiro, encerramento e exportação.
 * ==========================================================================
 */

// --- Compilação de Dados de Caixa (Fechamento) ---
function renderCompilacaoTabela(dados) {
    if (!dados || !Array.isArray(dados.movimentacoes)) {
        document.getElementById('compilacao-caixa-tabela').innerHTML = '<div class="error-message">Nenhum dado encontrado.</div>';
        return;
    }
    let html = `<table class="data-table">
        <thead>
            <tr>
                <th>Data</th>
                <th>Tipo</th>
                <th>Descrição</th>
                <th>Valor (R$)</th>
                <th>Operador</th>
            </tr>
        </thead>
        <tbody>`;
    dados.movimentacoes.forEach(mov => {
        html += `<tr>
            <td>${mov.data_movimentacao}</td>
            <td>${mov.tipo}</td>
            <td>${mov.descricao}</td>
            <td>${Number(mov.valor).toLocaleString('pt-BR', {minimumFractionDigits:2})}</td>
            <td>${mov.operador_nome || '-'}</td>
        </tr>`;
    });
    html += '</tbody></table>';
    // Totais
    html += `<div class="compilacao-totais">
        <strong>Total de Entradas:</strong> R$ ${Number(dados.total_entradas).toLocaleString('pt-BR', {minimumFractionDigits:2})}<br>
        <strong>Total de Saídas:</strong> R$ ${Number(dados.total_saidas).toLocaleString('pt-BR', {minimumFractionDigits:2})}<br>
        <strong>Saldo Final:</strong> R$ ${Number(dados.saldo_final).toLocaleString('pt-BR', {minimumFractionDigits:2})}
    </div>`;
    document.getElementById('compilacao-caixa-tabela').innerHTML = html;
}

function carregarCompilacaoCaixa() {
    const loader = document.getElementById('compilacao-caixa-loader');
    const erro = document.getElementById('compilacao-caixa-erro');
    const tabela = document.getElementById('compilacao-caixa-tabela');
    loader.classList.remove('hidden');
    erro.classList.add('hidden');
    tabela.innerHTML = '';
    fetch(`api/caixas/compilar_dados.php?caixa_id=${window.CAIXA_ID}`)
        .then(r => r.json())
        .then(dados => {
            loader.classList.add('hidden');
            if (dados.erro) {
                erro.textContent = dados.erro;
                erro.classList.remove('hidden');
            } else {
                renderCompilacaoTabela(dados);
                // Atualizar resumo financeiro
                atualizarResumoFinanceiro(dados);
            }
        })
        .catch(() => {
            loader.classList.add('hidden');
            erro.textContent = 'Erro ao buscar dados do caixa.';
            erro.classList.remove('hidden');
        });
}

// --- Resumo Financeiro ---
function atualizarResumoFinanceiro(dados) {
    const valorInicial = dados.caixa?.valor_inicial || 0;
    const totalEntradas = dados.total_entradas || 0;
    const totalSaidas = dados.total_saidas || 0;
    const saldoAtual = dados.saldo_final || (valorInicial + totalEntradas - totalSaidas);

    document.getElementById('valor-inicial').textContent = `R$ ${Number(valorInicial).toLocaleString('pt-BR', {minimumFractionDigits:2})}`;
    document.getElementById('total-entradas').textContent = `R$ ${Number(totalEntradas).toLocaleString('pt-BR', {minimumFractionDigits:2})}`;
    document.getElementById('total-saidas').textContent = `R$ ${Number(totalSaidas).toLocaleString('pt-BR', {minimumFractionDigits:2})}`;
    document.getElementById('saldo-atual').textContent = `R$ ${Number(saldoAtual).toLocaleString('pt-BR', {minimumFractionDigits:2})}`;
}

// --- Status do Caixa ---
function carregarStatusCaixa() {
    fetch(`api/caixas/get_caixa_info.php?id=${window.CAIXA_ID}`)
        .then(r => r.json())
        .then(dados => {
            if (dados.success && dados.caixa) {
                const caixa = dados.caixa;
                document.getElementById('operador-caixa').textContent = caixa.operador_nome || '-';
                document.getElementById('data-abertura').textContent = caixa.data_abertura ? new Date(caixa.data_abertura).toLocaleString('pt-BR') : '-';
                
                // Atualizar status
                const statusElement = document.getElementById('status-caixa');
                if (caixa.status === 'Fechado') {
                    statusElement.textContent = 'FECHADO';
                    statusElement.className = 'status-badge status-fechado';
                    
                    // Desabilitar botão de encerrar e mostrar botão de voltar
                    const btnEncerrar = document.getElementById('btn-encerrar-caixa');
                    if (btnEncerrar) {
                        btnEncerrar.disabled = true;
                        btnEncerrar.textContent = 'Caixa Encerrado';
                        btnEncerrar.style.opacity = '0.6';
                    }
                    mostrarBotaoVoltar();
                } else {
                    statusElement.textContent = 'ABERTO';
                    statusElement.className = 'status-badge status-aberto';
                }
                
                // Calcular tempo aberto
                if (caixa.data_abertura) {
                    const abertura = new Date(caixa.data_abertura);
                    const agora = new Date();
                    const diff = agora - abertura;
                    const horas = Math.floor(diff / (1000 * 60 * 60));
                    const minutos = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                    document.getElementById('tempo-aberto').textContent = `${horas}h ${minutos}min`;
                }
            }
        })
        .catch(() => {
            console.error('Erro ao carregar status do caixa');
        });
}

// --- Encerrar Caixa ---
function encerrarCaixa() {
    if (!confirm('Tem certeza que deseja encerrar este caixa? Esta ação não pode ser desfeita.')) {
        return;
    }
    
    const btnEncerrar = document.getElementById('btn-encerrar-caixa');
    const textoOriginal = btnEncerrar.textContent;
    btnEncerrar.disabled = true;
    btnEncerrar.textContent = 'Encerrando...';
    
    fetch('api/caixas/encerrar_caixa.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: window.CAIXA_ID })
    })
    .then(r => r.json())
    .then(result => {
        if (result.success) {
            showNotification('Sucesso!', 'Caixa encerrado com sucesso!', 'success');
            // Atualizar status
            document.getElementById('status-caixa').textContent = 'FECHADO';
            document.getElementById('status-caixa').className = 'status-badge status-fechado';
            // Desabilitar botão
            btnEncerrar.disabled = true;
            btnEncerrar.textContent = 'Caixa Encerrado';
            btnEncerrar.style.opacity = '0.6';
            
            // Mostrar botão para voltar ao dashboard
            mostrarBotaoVoltar();
        } else {
            showNotification('Erro!', result.message || 'Erro ao encerrar caixa.', 'error');
            btnEncerrar.disabled = false;
            btnEncerrar.textContent = textoOriginal;
        }
    })
    .catch(() => {
        showNotification('Erro!', 'Erro de conexão ao encerrar caixa.', 'error');
        btnEncerrar.disabled = false;
        btnEncerrar.textContent = textoOriginal;
    });
}

// --- Mostrar Botão Voltar ---
function mostrarBotaoVoltar() {
    const acoesSection = document.getElementById('acoes-fechamento-section');
    if (acoesSection) {
        const botaoVoltar = document.createElement('div');
        botaoVoltar.className = 'acao-card';
        botaoVoltar.innerHTML = `
            <h4>Caixa Encerrado</h4>
            <p>O caixa foi encerrado com sucesso. Você pode voltar ao dashboard principal.</p>
            <button onclick="window.location.href='abrir-caixa.php'" class="button button--primary">Voltar ao Dashboard</button>
        `;
        acoesSection.querySelector('.acoes-fechamento-grid').appendChild(botaoVoltar);
    }
}

// --- Feedback de Exportação ---
function showExportFeedback(tipo, status, mensagem) {
    const feedback = document.createElement('div');
    feedback.className = `export-feedback ${status}`;
    feedback.textContent = `${tipo} ${status === 'success' ? 'gerado' : 'erro'} ${mensagem}`;
    document.body.appendChild(feedback);
    
    setTimeout(() => feedback.classList.add('show'), 100);
    setTimeout(() => {
        feedback.classList.remove('show');
        setTimeout(() => document.body.removeChild(feedback), 300);
    }, 3000);
}

function bloquearExportacao(bloquear) {
    const btnPdf = document.getElementById('btn-exportar-pdf');
    const btnExcel = document.getElementById('btn-exportar-excel');
    
    if (bloquear) {
        btnPdf.disabled = true;
        btnExcel.disabled = true;
        btnPdf.textContent = 'Gerando...';
        btnExcel.textContent = 'Gerando...';
    } else {
        btnPdf.disabled = false;
        btnExcel.disabled = false;
        btnPdf.textContent = 'PDF';
        btnExcel.textContent = 'Excel';
    }
}

// --- Notificações ---
function showNotification(titulo, mensagem, tipo) {
    const notification = document.createElement('div');
    notification.className = `export-feedback ${tipo}`;
    notification.innerHTML = `<strong>${titulo}</strong><br>${mensagem}`;
    document.body.appendChild(notification);
    
    setTimeout(() => notification.classList.add('show'), 100);
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 4000);
}

// --- Carregar Dados de Fechamento ---
function carregarDadosFechamento() {
    const tabFechamento = document.getElementById('tab-content-fechamento');
    if (tabFechamento && tabFechamento.classList.contains('active')) {
        carregarCompilacaoCaixa();
        carregarStatusCaixa();
    }
}

// --- Event Listeners ---
document.addEventListener('DOMContentLoaded', function() {
    // Listener para encerrar caixa
    const btnEncerrar = document.getElementById('btn-encerrar-caixa');
    if (btnEncerrar) {
        btnEncerrar.addEventListener('click', encerrarCaixa);
    }
    
    // Listener para atualizar dados
    const btnAtualizar = document.getElementById('btn-atualizar-dados');
    if (btnAtualizar) {
        btnAtualizar.addEventListener('click', carregarCompilacaoCaixa);
    }
    
    // Listeners para exportação
    const btnPdf = document.getElementById('btn-exportar-pdf');
    if (btnPdf) {
        btnPdf.onclick = function(e) {
            e.preventDefault();
            bloquearExportacao(true);
            showExportFeedback('PDF', 'sucesso', '');
            window.open(`api/caixas/relatorio_pdf.php?caixa_id=${window.CAIXA_ID}`, '_blank');
            setTimeout(() => bloquearExportacao(false), 2000);
        };
    }
    
    const btnExcel = document.getElementById('btn-exportar-excel');
    if (btnExcel) {
        btnExcel.onclick = function(e) {
            e.preventDefault();
            bloquearExportacao(true);
            showExportFeedback('Excel', 'sucesso', '');
            window.open(`api/caixas/relatorio_excel.php?caixa_id=${window.CAIXA_ID}`, '_blank');
            setTimeout(() => bloquearExportacao(false), 2000);
        };
    }
    
    // Carregar dados iniciais
    carregarDadosFechamento();
});

// Listener para troca de abas
document.querySelectorAll('.caixa-dashboard-menu .tab-btn').forEach(btn => {
    btn.addEventListener('click', carregarDadosFechamento);
});

// Listener para navegação mobile
document.querySelectorAll('#side-menu .menu-link').forEach(link => {
    link.addEventListener('click', function() {
        setTimeout(carregarDadosFechamento, 100);
    });
});

// Atualizar tempo aberto a cada minuto
setInterval(() => {
    const tabFechamento = document.getElementById('tab-content-fechamento');
    if (tabFechamento && tabFechamento.classList.contains('active')) {
        carregarStatusCaixa();
    }
}, 60000); // Atualiza a cada minuto 