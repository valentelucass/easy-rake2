<?php
// Script simples para gerar hash de senha
if (isset($_GET['senha'])) {
    $senha = $_GET['senha'];
    $hash = password_hash($senha, PASSWORD_DEFAULT);
    echo "<b>Senha:</b> $senha<br><b>Hash:</b> $hash";
} else {
    echo '<form method="get"><input name="senha" placeholder="Digite a senha"><button type="submit">Gerar hash</button></form>';
} 