<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
echo 'INÍCIO<br>';
include 'includes/novo-header.php';
echo '<br>INCLUIU HEADER<br>';
?>
<div style="margin-top:100px; text-align:center;">
    <h1>Teste do Novo Header/Menu</h1>
    <p>Se você está vendo este texto, o include funcionou.</p>
</div>
<?php
echo '<br>ANTES DO FOOTER<br>';
include 'includes/novo-footer.php';
echo '<br>FIM<br>';
?> 