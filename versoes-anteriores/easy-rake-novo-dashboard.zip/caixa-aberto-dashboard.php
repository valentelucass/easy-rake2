<?php
session_start();
$id_caixa = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$id_caixa) {
    echo '<h2>Caixa não encontrado.</h2>';
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard do Caixa #<?php echo $id_caixa; ?> | EASY RAKE</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/components/_header.css">
    <link rel="stylesheet" href="css/pages/_dashboard.css">
    <link rel="stylesheet" href="css/components/_buttons.css">
    <style>
        .caixa-dashboard-header {
            margin-bottom: 2rem;
        }
        .caixa-dashboard-id {
            color: var(--accent-color);
            font-weight: 700;
            font-size: 1.1rem;
            margin-left: 1rem;
        }
        .caixa-dashboard-menu {
            display: flex;
            gap: 1.2rem;
            justify-content: center;
            align-items: center;
            background: var(--surface-color);
            border-radius: 10px;
            margin-bottom: 2.2rem;
            padding: 0.7rem 0.5rem;
        }
        .caixa-dashboard-menu .tab-btn {
            background: none;
            border: none;
            color: var(--secondary-text-color);
            font-size: 1.08rem;
            font-weight: 600;
            padding: 0.7rem 1.3rem;
            border-radius: 7px;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
        }
        .caixa-dashboard-menu .tab-btn.active, .caixa-dashboard-menu .tab-btn:hover {
            background: var(--accent-gradient);
            color: #fff;
        }
        @media (max-width: 768px) {
            .caixa-dashboard-menu {
                display: none;
            }
            #caixa-dashboard-mobile-menu {
                display: flex !important;
            }
        }
        @media (min-width: 769px) {
            #caixa-dashboard-mobile-menu {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Header Mobile Fixo -->
        <header id="mobile-header">
            <button id="hamburger-btn" aria-label="Abrir menu">
                <span class="hamburger-bar"></span>
                <span class="hamburger-bar"></span>
                <span class="hamburger-bar"></span>
            </button>
            <span class="mobile-title">EASY RAKE</span>
            <button id="logout-btn-mobile" aria-label="Sair" onclick="logout()">Sair</button>
        </header>

        <!-- Menu Lateral Deslizante -->
        <nav id="side-menu">
            <ul>
                <li><a class="menu-link" href="?id=<?php echo $id_caixa; ?>&tab=fechamento">Fechamento</a></li>
                <li><a class="menu-link" href="?id=<?php echo $id_caixa; ?>&tab=rake">Rake</a></li>
                <li><a class="menu-link" href="?id=<?php echo $id_caixa; ?>&tab=fichas">Fichas</a></li>
                <li><a class="menu-link" href="?id=<?php echo $id_caixa; ?>&tab=caixinhas">Caixinhas</a></li>
                <li><a class="menu-link" href="?id=<?php echo $id_caixa; ?>&tab=gastos">Gastos</a></li>
                <li><a class="menu-link" href="?id=<?php echo $id_caixa; ?>&tab=jogadores">Jogadores</a></li>
                <li><a class="menu-link" href="?id=<?php echo $id_caixa; ?>&tab=inventario">Inventário</a></li>
            </ul>
        </nav>
        <div id="menu-overlay"></div>

        <!-- Header Desktop (oculto em mobile) -->
        <header class="app-header caixa-dashboard-header">
            <div class="app-header-row">
                <a href="abrir-caixa.php" class="back-arrow" title="Voltar">
                    <svg class="back-arrow-svg" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true">
                        <polyline points="16 4 8 12 16 20" fill="none" stroke="var(--accent-color)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </a>
                <div class="user-info">
                    <h1 class="company-title">EASY RAKE</h1>
                    <span class="caixa-dashboard-id">Caixa #<?php echo $id_caixa; ?></span>
                </div>
                <button class="button button--secondary" onclick="logout()">Sair</button>
            </div>
        </header>

        <!-- Menu superior desktop (oculto em mobile) -->
        <nav class="caixa-dashboard-menu" id="caixa-dashboard-menu">
            <button class="tab-btn active" data-tab="fechamento">FECHAMENTO</button>
            <button class="tab-btn" data-tab="rake">RAKE</button>
            <button class="tab-btn" data-tab="fichas">FICHAS</button>
            <button class="tab-btn" data-tab="caixinhas">CAIXINHAS</button>
            <button class="tab-btn" data-tab="gastos">GASTOS</button>
            <button class="tab-btn" data-tab="jogadores">JOGADORES</button>
            <button class="tab-btn" data-tab="inventario">INVENTÁRIO</button>
        </nav>

        <main id="main-content" class="dashboard-main">
            <div class="content-container">
                <?php
                $tab = isset($_GET['tab']) ? $_GET['tab'] : 'fechamento';
                if ($tab === 'fechamento') {
                ?>
                <div id="tab-content-fechamento" class="tab-content active">
                    <h2>Fechamento do Caixa</h2>
                    <p>Conteúdo do fechamento do caixa #<?php echo $id_caixa; ?>.</p>
                </div>
                <?php } else if ($tab === 'rake') { ?>
                <div id="tab-content-rake" class="tab-content active">
                    <h2>Rake</h2>
                    <p>Conteúdo de rake do caixa #<?php echo $id_caixa; ?>.</p>
                </div>
                <?php } else if ($tab === 'fichas') { ?>
                <div id="tab-content-fichas" class="tab-content active">
                    <h2>Fichas</h2>
                    <p>Conteúdo de fichas do caixa #<?php echo $id_caixa; ?>.</p>
                </div>
                <?php } else if ($tab === 'caixinhas') { ?>
                <div id="tab-content-caixinhas" class="tab-content active">
                    <h2>Caixinhas</h2>
                    <p>Conteúdo de caixinhas do caixa #<?php echo $id_caixa; ?>.</p>
                </div>
                <?php } else if ($tab === 'gastos') { ?>
                <div id="tab-content-gastos" class="tab-content active">
                    <h2>Gastos</h2>
                    <p>Conteúdo de gastos do caixa #<?php echo $id_caixa; ?>.</p>
                </div>
                <?php } else if ($tab === 'jogadores') { ?>
                <div id="tab-content-jogadores" class="tab-content active">
                    <h2>Jogadores</h2>
                    <p>Conteúdo de jogadores do caixa #<?php echo $id_caixa; ?>.</p>
                </div>
                <?php } else if ($tab === 'inventario') { ?>
                <div id="tab-content-inventario" class="tab-content active">
                    <h2>Inventário</h2>
                    <p>Conteúdo de inventário do caixa #<?php echo $id_caixa; ?>.</p>
                </div>
                <?php } ?>
            </div>
        </main>
    </div>

    <script>
    window.CAIXA_ID = <?php echo $id_caixa; ?>;
    </script>
    <script src="js/features/caixa-dashboard/caixa-aberto-dashboard.js"></script>
</body>
</html> 