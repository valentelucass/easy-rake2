<?php
// Definições do Banco de Dados
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', '36140888'); // Sua senha
define('DB_NAME', 'easy_rake');    // Sugestão de nome para o banco, crie-o no phpMyAdmin
define('DB_PORT', 3307);           // Sua porta

// Criar a conexão mysqli
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME, DB_PORT);

// Checar a conexão
if ($conn->connect_error) {
    // Em produção, você pode querer logar o erro em vez de exibi-lo
    die("Conexão falhou: " . $conn->connect_error);
}

// Define o charset para UTF-8 para evitar problemas com acentos
$conn->set_charset("utf8mb4");