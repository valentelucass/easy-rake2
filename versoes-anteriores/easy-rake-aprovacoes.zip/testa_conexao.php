<?php
require_once 'api/db_connect.php';
echo "=== TESTE DE CONEXÃO COM BANCO DE DADOS ===\n";
if ($conn->connect_error) {
    echo "Erro de conexão: " . $conn->connect_error . "\n";
    exit(1);
}
if ($conn->ping()) {
    echo "Conexão OK!\n";
} else {
    echo "Falha na conexão!\n";
}
$conn->close();
?> 